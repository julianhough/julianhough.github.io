/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import qmul.ds.action.Grammar;
import qmul.ds.action.LexicalAction;
import qmul.ds.action.Lexicon;
import qmul.ds.gui.GeneratorGUI;
import qmul.ds.gui.ParserPanel;
import qmul.ds.tree.Tree;
import qmul.ds.tree.label.FormulaLabel;
import qmul.ds.formula.*;

/**
 * A generic generator (surface realiser)
 * 
 * @author mpurver
 */
public abstract class Generator<T extends ParserTuple> {

	private static Logger logger = Logger.getLogger(Generator.class);

	protected GenerationState<T> state;
	protected Parser<T> parser;
	private ParserPanel gui;
	private GeneratorGUI genGui;
	public HashMap<String, Collection<LexicalAction>> subLexicon = new HashMap<String, Collection<LexicalAction>>();
	public boolean match = false;
	public Vector<GenerationState<T>> stateHistory;
	
	public Generator()
	{
		//dummy constructor
	}

	public Generator(Parser<T> parser) {
		state = new GenerationState<T>();
		state.add(new GeneratorTuple<T>(parser.getState()));
		stateHistory = new Vector<GenerationState<T>>();
		this.parser = parser;
	}

	public Generator(Lexicon lexicon, Grammar grammar) {
		state = new GenerationState<T>();
		parser = getParser(lexicon, grammar);
	}

	/**
	 * @param resourceDir
	 *            the dir containing computational-actions.txt, lexical-actions.txt, lexicon.txt
	 */
	public Generator(File resourceDir) {
		this(new Lexicon(resourceDir), new Grammar(resourceDir));
	}

	/**
	 * @param resourceDirNameOrURL
	 *            the dir containing computational-actions.txt, lexical-actions.txt, lexicon.txt
	 */
	public Generator(String resourceDirNameOrURL) {
		this(new Lexicon(resourceDirNameOrURL), new Grammar(resourceDirNameOrURL));
	}

	/**
	 * @param gui
	 *            the gui to set
	 */
	public void setGui(ParserPanel gui) {
		this.gui = gui;
	}
	
	/**
	 * @param genGui
	 *            the GeneratorGUI to set
	 */
	public void setGenGui(GeneratorGUI gui) {
		this.genGui = gui;
	}
	

	/**
	 * Reset the generator state to the initial (axiom) state
	 */
	public void init() {
		state.clear();
		stateHistory.clear();
		parser.init();
		state.add(new GeneratorTuple<T>(parser.getState()));
	}

	/**
	 * @param lexicon
	 * @param grammar
	 * @return a {@link Parser} suitable for this implementation
	 */
	public abstract Parser<T> getParser(Lexicon lexicon, Grammar grammar);

	/**
	 * @return a shallow copy of the current state
	 */
	public GenerationState<T> getState() {
		if (state == null) {
			return null;
		}
		return state.clone();
	}

	/**
	 * print the current state
	 */
	public void printState() {
		logger.info("\nNew state (" + state.size() + "):");
		for (GeneratorTuple<T> tuple : state) {
			logger.info(tuple);
		}
		logger.info("");
	}

	//essentially a breadth-first algorithm with incremental semantic filter, returns a generator state with all possible trees, not just the best
	private GenerationState<T> generateNextWord() {
		GenerationState<T> oldState = state.clone();
		if (oldState!=null){stateHistory.add(oldState);}// adds a copy of the state before generating this word
		state.clear();
		// each tuple is a candidate partial string with its state
		for (GeneratorTuple<T> tuple : oldState) {
			logger.debug("Checking tuple " + tuple);
			//for (String word : parser.getLexicon().keySet()) {
		    for (String word : subLexicon.keySet()) { //for iterating through sublexicon
		    	
				ParseState<T> oldPState = tuple.getParseState().clone();
				logger.debug("Extending tuple with word " + word + " = " + oldPState.size());
				//logger.info("LEXICON" + parser.getLexicon());
				parser.parseWord(oldPState, word);
				logger.debug("Extension with word " + word + " = " + oldPState.size());
				//ParseState<T> newPState = oldPState.subsumes(state.getGoalTree());
				ParseState<T> newPState = oldPState.subsumes(state.getGoalTTR());  //using goal TTR concept instead
				logger.debug("Subsumption with word " + word + " = " + newPState.size());
				if (!newPState.isEmpty()) {
					logger.debug("Extended tuple with word " + word);
					ArrayList<String> newString = new ArrayList<String>(tuple.getString());
					newString.add(word);
					state.add(new GeneratorTuple<T>(newString, newPState));
					logger.debug("Added new tuple " + newString + " " + newPState.size());
					JOptionPane.showMessageDialog(null, word);
					if (gui != null) {
						gui.addGeneratorOutput(newString.toString());
						
					}
					try {
					if(genGui!=null) {
						genGui.addGeneratorOutput(" \" " + word +" \" ");
						genGui.addGeneratorOutput(newString.toString() + " \" " + word +" \" ");
						float l = 50 / newString.size();
						String s = "";
						for (int x = 0; x<(int)l; x++) {
							s = s + "    ";
						}
						//genGui.addGeneratorOutput(s);
						//genGui.update();
					}} catch (Exception e) {}
					if (newPState.matched()) {
				
						logger.info("\n\n MATCH! :" + newString.toString() + System.currentTimeMillis());
						//JOptionPane.showMessageDialog(null, "MATCH!" + newString.toString());
						
						setMatch(true);
						newPState.setMatched(false);
						//state.clear();
						//break;
						
					}
				} else {
					logger.debug("Failed to extend tuple with word " + word);
					
				}
			}
		}
		genGui.addGeneratorOutput("\n");
		return state;
	}

	/**
	 * Generate a sentence for a given goal tree
	 * 
	 * @param tree
	 * @return true if successful
	 */
	public boolean generate(Tree tree) {
		state.setGoalTree(tree);
		logger.info("Starting generation with goal tree:");
		logger.info(tree);
		
		int i = 1;
		
		success : while (successful()) {
			//while (successful() && !state.hasCompleteTuple()) {
			logger.info("\n\n" + "word number " + i + "--------------------");
			logger.info("Gen next word");
			
			generateNextWord();
			//parses.add();
			i++;
		}
		
		logger.info("Finished generation.");
		return successful();
	}

	/**
	 * Generate a sentence for a given goal tree
	 * 
	 * @param tree
	 * @return true if successful
	 */
	public boolean generate(TTRFormula ttr) {
		state.setGoalTTR(ttr);
		logger.info("Starting generation with goal TTR:");
		logger.info(ttr);
		//logger.info("TIME BEFORE sublexicalise: " + System.currentTimeMillis());
		subLexicon();
		
		
		//Vector<ParseState<T>> parses = new Vector<ParseState<T>>();
		int i = 1;
		while (successful()&&!matched()) {
			//while (successful() && !state.hasCompleteTuple()) {
			//logger.info("\n\n" + "word number " + i + "--------------------");
			//logger.info("Gen next word");
			logger.info("TIME BEFORE WORD " + i  + ": " + System.currentTimeMillis());
			generateNextWord();
			if (!successful()) {
				//logger.info("stateHistory = ");
				//for (GenerationState<T> genstate : stateHistory) {
				//	logger.info(genstate.toString());
					
				//}
				genGui.addGeneratorOutput("\"uhh\" \n");
				//JOptionPane.showMessageDialog(null, "uhh");
				repair();
			}
			logger.info("TIME AFTER WORD " + i + ": " + System.currentTimeMillis());
			i++;
			
			
		}
		logger.info("Finished generation.");
		setMatch(false);
		
		return successful();
	}
	
	
	//getting sublexicon
	public void subLexicon() {
		
		    logger.info("TIME BEFORE sublexicalise: " + System.currentTimeMillis());
		    Iterator it = this.parser.getLexicon().entrySet().iterator();
		    HashMap sublex = new HashMap<String, Collection<LexicalAction>>();
		    while (it.hasNext()) {
		        Map.Entry pairs = (Map.Entry)it.next();
		        
		        for (LexicalAction ac : (Collection<LexicalAction>) pairs.getValue())
		        {
		        	//System.out.println("sublex candidate " + pairs.getKey() + " = " + ac.getSemantics());
		        	
		        	if (state.getGoalTTR().isSubtypeOf(ac.getSemantics())) {
		        		HashSet<LexicalAction> collec = new HashSet<LexicalAction>();
		        		collec.add(ac);
		        		sublex.put(pairs.getKey(), collec); //need to iterate through all different lexical actions associated with each word
		        		
		        	}
		        }
		        	
		       // it.remove(); // avoids a ConcurrentModificationException
		        
		    }
		    logger.info("SIZE SUBLEX = " + sublex.size() + "SUBLEX = " + sublex);
		    this.subLexicon = sublex;
	}
		

		
	/**
	 * @return true if the current state is non-null and non-empty
	 */
	protected boolean successful() {
		return ((state != null) && !state.isEmpty());
	}
	
	public void setMatch(boolean match) {
		this.match = match;
	}
	
	public boolean matched() {
		return this.match;
	}
	
	/**
	 * Backtracks by one parse state in the stateHistory at a time until 
	 * a departure point for a successful parse path is found
	 * (i.e. one in which the top tree's TTR subsumes the current goal TTR concept)
	 * 
	 */
	public void repair() {
	
		int i = stateHistory.size();
		TTRFormula goal = state.getGoalTTR();
		logger.info("repairing , attempting to generate with " + goal);
		while (!successful()&&i>0) {
			GenerationState<T> previous = stateHistory.get(i-1);
			previous.setGoalTTR(goal);
			state = previous;
			state.setGoalTTR(goal);
			//subLexicon(); //will now need to get new sublexicon
			generateNextWord();
			i--;
		}
		
		
	}

	/**
	 * @return the "best" tree in the current state (where "best" is defined by the natural ordering of the {@link Tree}
	 *         implementation used), or null if the state is empty
	 */
	public List<String> getBestString() {
		if (!successful()) {
			return null;
		}
		return state.first().getString();
	}

}

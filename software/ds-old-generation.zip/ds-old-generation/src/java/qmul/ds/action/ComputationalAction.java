/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.action;

import java.util.Collection;
import java.util.List;

import qmul.ds.ParseState;
import qmul.ds.ParserTuple;
import qmul.ds.action.atomic.Effect;
import qmul.ds.action.atomic.EffectFactory;
import qmul.ds.action.atomic.IfThenElse;
import qmul.ds.tree.Tree;

/**
 * A generally available computational {@link Action}
 * 
 * @author mpurver
 */
public class ComputationalAction extends Action implements Comparable<ComputationalAction> {

	private boolean alwaysGood = false;
	private boolean backtrackEvenOnSuccess = false;

	public ComputationalAction(String name, Effect action) {
		super(name, action);
	}

	/**
	 * @param name
	 *            the name of this action
	 * @param lines
	 *            a {@link String} representation as used in lexicon specs
	 */
	public ComputationalAction(String name, List<String> lines) {
		super(name, EffectFactory.create(lines));
	}

	/**
	 * @return true if this {@link ComputationalAction} should always be applied if it can be, i.e. on application,
	 *         remove the previous {@link Tree} from the {@link ParseState}
	 */
	public boolean isAlwaysGood() {
		return alwaysGood;
	}

	/**
	 * 
	 * @return true if this action is to be repeatedly applied until we cannot backtrack with a successful result
	 */
	public boolean backtrackOnSuccess() {
		return this.backtrackEvenOnSuccess;
	}

	/**
	 * @param alwaysGood
	 *            true if this {@link ComputationalAction} should always be applied if it can be, i.e. on application,
	 *            remove the previous {@link Tree} from the {@link ParseState}
	 */
	public void setAlwaysGood(boolean alwaysGood) {
		this.alwaysGood = alwaysGood;
	}

	/**
	 * 
	 */

	public void setBacktrackOnSuccess(boolean a) {
		this.backtrackEvenOnSuccess = a;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ComputationalAction arg0) {
		// ensure alwaysGood actions are returned first by iterators
		if (alwaysGood && !arg0.alwaysGood)
			return -1;
		if (!alwaysGood && arg0.alwaysGood)
			return 1;
		return hashCode() - arg0.hashCode();
	}

	public Action instantiate() {
		if (action instanceof IfThenElse) {
			IfThenElse ite = (IfThenElse) action;
			return new ComputationalAction(super.getName(), ite.instantiate());
		} else
			return this;
	}

	public <T extends Tree> Collection<T> execExhaustively(T tree, ParserTuple context) {
		IfThenElse ite = (IfThenElse) action;
		return ite.execExhaustively(tree, context);
	}
}

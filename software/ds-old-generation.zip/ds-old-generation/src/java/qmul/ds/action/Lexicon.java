/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.action;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import qmul.ds.action.atomic.EffectFactory;
import qmul.ds.formula.TTRFormula;
import qmul.ds.formula.TTRLabel;

/**
 * A map from words to {@link LexicalAction}s
 * 
 * @author mpurver
 */
public class Lexicon extends HashMap<String, Collection<LexicalAction>> {

	private static Logger logger = Logger.getLogger(Lexicon.class);
	public int lexiconsize = 0;

	/**
	 * A template for creating lexical actions for a particular syntactic class
	 * 
	 * @author mpurver
	 */
	protected class LexicalTemplate {

		private String name;
		private List<String> metavars;
		private List<String> lines;

		/**
		 * @param name
		 */
		protected LexicalTemplate(String name, List<String> metavars, List<String> lines) {
			this.name = name;
			this.metavars = new ArrayList<String>(metavars);
			this.lines = new ArrayList<String>(lines);
		}

		/**
		 * @param word
		 * @param metavals
		 * @return a new {@link LexicalAction} instantiation for this word and metavariable values
		 */
		protected LexicalAction create(String word, List<String> metavals) { //TODO should work for all versions
			ArrayList<String> lines = new ArrayList<String>();
			logger.trace("metavars for word : " + word + " of type " + name);
			//This populates a TTR formula for the action's semantics
			TTRFormula ttr = new TTRFormula();  
			String pred = metavars.contains("NAME") ? "x" : "p";
			for (int i = 0; i < metavars.size(); i++) {
				logger.trace(metavars.get(i) + " : " + metavals.get(i));
				if (metavars.get(i).contains("PRED")) {
					if (name.startsWith("v")||name.startsWith("prep")) {
						ttr.add(new TTRFormula("e", "null"));
						ttr.add(new TTRFormula("x", "null"));
						if (name.contains("intran")||name.startsWith("prep")) {
					    
						ttr.add(new TTRFormula("p", metavals.get(i) + "(e,x)"));
						} else if (name.contains("tran")) {
						ttr.add(new TTRFormula("p", metavals.get(i) + "(e,x,x1)"));	
						ttr.add(new TTRFormula("x1", "null"));
						}
					}
				}else if (metavars.get(i).contains("NAME")) {
						ttr.add(new TTRFormula("x", metavals.get(i)));
					}
				else if (metavars.get(i).contains("TENSE")) {
				//	ttr.add(new TTRFormula("e", "null"));
				//	ttr.add(new TTRFormula("r", "null"));
				//	ttr.add(new TTRFormula("p1", metavals.get(i) + "(r,es)"));
					
				} 
				//leave other stuff out for now, to be added in when lexical actions adjusted
			//	else if (metavars.get(i).contains("PERSON")) {   
					//ttr.add(new TTRFormula("p1", "null"));
			//		ttr.add(new TTRFormula("p1", metavals.get(i) + "(" + pred + ")"));					
			//	} else if (metavars.get(i).contains("CLASS")) {
			//		//ttr.add(new TTRFormula("p1", "null"));
			//		ttr.add(new TTRFormula("p1", metavals.get(i) + "(" + pred + ")"));
			//	}
				
			}
			for (String line : this.lines) {
				for (int i = 0; i < metavars.size(); i++) {
					line = line.replaceAll(metavars.get(i), metavals.get(i));
				}
				lines.add(line);
			}
			
			logger.info(word + ":" + ttr);
			lexiconsize++;
			logger.info("lexicon size = " + lexiconsize);
			return new LexicalAction(word, lines, ttr);
		}

	}

	private static final long serialVersionUID = -470754367073236462L;

	public static final String WORD_FILE_NAME = "lexicon.txt";
	public static final String ACTION_FILE_NAME = "lexical-actions.txt";
	public static final String MACRO_FILE_NAME = "lexical-macros.txt";

	public static final String LINE_COMMENT = "//";
	public static final String BEGIN_COMMENT = "//*"; // can't use /* as it can
	// occur in e.g. <\/*>
	public static final String END_COMMENT = "*//";

	public static final Pattern TEMPLATE_SPEC_PATTERN = Pattern.compile("(.+?)\\((.+)\\)");
	public static final Pattern MACRO_SPEC_PATTERN = Pattern.compile("(.+?)(\\(.*\\))*");

	private HashMap<String, LexicalTemplate> actionTemplates = new HashMap<String, LexicalTemplate>();

	/**
	 * Read a set of {@link LexicalAction}s from file
	 * 
	 * @param dir
	 *            containing at least the lexical-actions.txt and lexicon.txt files
	 */
	public Lexicon(File dir) {
		File file = new File(dir, MACRO_FILE_NAME);
		try {
			BufferedReader reader1 = null;
			if (!file.exists()) {
				logger.debug("no lexical-macro file. expecting no macro calls in lexical action file");

			} else {
				reader1 = new BufferedReader(new FileReader(file));
			}

			initMacroTemplates(reader1);
			file = new File(dir, ACTION_FILE_NAME);

			BufferedReader macroReader = new BufferedReader(new FileReader(file));
			initMacroTemplates(macroReader);
			file = new File(dir, WORD_FILE_NAME);
			BufferedReader reader2 = new BufferedReader(new FileReader(file));
			readWords(reader2);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.error("Error reading lexical actions file " + file.getAbsolutePath());
		}
	}

	/**
	 * Read a set of {@link LexicalAction}s from file
	 * 
	 * @param dirNameOrURL
	 *            containing at least the lexical-actions.txt and lexicon.txt files
	 */
	public Lexicon(String dirNameOrURL) {
		BufferedReader reader;
		try {
			if (dirNameOrURL.matches("(https?|file):.*")) {
				reader = new BufferedReader(new InputStreamReader(new URL(dirNameOrURL.replaceAll("/?$", "/")
						+ MACRO_FILE_NAME).openStream()));
			} else {
				File macroFile = new File(dirNameOrURL, MACRO_FILE_NAME);
				if (!macroFile.exists()) {
					logger.debug("no lexical-macro file. expecting no macro calls in lexical action file");
					reader = null;
				} else
					reader = new BufferedReader(new FileReader(macroFile));
			}
			initMacroTemplates(reader);
			if (dirNameOrURL.matches("(https?|file):.*")) {
				reader = new BufferedReader(new InputStreamReader(new URL(dirNameOrURL.replaceAll("/?$", "/")
						+ ACTION_FILE_NAME).openStream()));
			} else {
				reader = new BufferedReader(new FileReader(new File(dirNameOrURL, ACTION_FILE_NAME)));
			}
			initLexicalTemplates(reader);

			if (dirNameOrURL.matches("(https?|file):.*")) {
				reader = new BufferedReader(new InputStreamReader(new URL(dirNameOrURL.replaceAll("/?$", "/")
						+ WORD_FILE_NAME).openStream()));
			} else {
				reader = new BufferedReader(new FileReader(new File(dirNameOrURL, WORD_FILE_NAME)));
			}
			readWords(reader);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error reading lexical actions file " + dirNameOrURL);
		}
	}

	/**
	 * Read a set of {@link LexicalAction} templates from file
	 * 
	 * @param reader
	 *            containing the lexical-actions.txt file
	 */
	private void initLexicalTemplates(BufferedReader reader) {
		try {
			String line;
			String name = null;
			List<String> metavars = new ArrayList<String>();
			List<String> lines = new ArrayList<String>();
			while ((line = reader.readLine()) != null) {
				line = comment(line.trim());
				if ((line == null) || (line.isEmpty() && lines.isEmpty())) {
					continue;
				}
				if (line.isEmpty() && !lines.isEmpty()) {
					actionTemplates.put(name, new LexicalTemplate(name, metavars, lines));
					logger.info("Added template for " + name);
					lines.clear();
					name = null;
					metavars.clear();
				} else if (name == null) {
					Matcher m = TEMPLATE_SPEC_PATTERN.matcher(line);
					if (m.matches()) {
						name = m.group(1);
						for (String s : m.group(2).split(",")) {
							metavars.add(s);
						}
					} else {
						throw new IllegalArgumentException("unrecognised template spec " + line);
					}
					logger.info("New lexical template: " + name);
				} else {
					lines.add(line);
				}
			}
			if (!lines.isEmpty()) {
				actionTemplates.put(name, new LexicalTemplate(name, metavars, lines));
				logger.debug("Added Lexical Template for " + name);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("Error reading templates from stream " + reader);
		}
		logger.info("Read " + actionTemplates.size() + " lexical action templates");
	}

	private void initMacroTemplates(BufferedReader reader) {
		if (reader == null)
			EffectFactory.clearMacroTemplates();
		else
			EffectFactory.initMacroTemplates(reader);

	}

	/**
	 * Read a set of {@link LexicalAction}s from file
	 * 
	 * @param reader
	 *            containing the lexicon.txt file
	 */
	private void readWords(BufferedReader reader) {
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				line = comment(line.trim());
				if ((line == null) || line.isEmpty()) {
					continue;
				}
				List<String> fields = Arrays.asList(line.split("\\s+"));
				String word = fields.get(0);
				String template = fields.get(1);
				if (actionTemplates.get(template) == null) {
					logger.debug("No template " + template + ", skipping word " + word);
				} else {

					logger.debug("Using template " + template + " for word " + word);
					try {
						LexicalAction action = actionTemplates.get(template).create(word,
								fields.subList(2, fields.size()));
						if (!containsKey(word)) {
							put(word, new HashSet<LexicalAction>());
						}
						get(word).add(action);
						logger.debug("Added lexical action " + action);

					} catch (IllegalArgumentException e) {
						logger.error(e);
						logger.error("Macros used in lexical template could not be instatiated. \nTemplate:" + template
								+ "\nWord:" + word + " Skipping this");

						continue;
					}
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
			logger.error("Error reading lexical entries from " + reader);
		}
		logger.info("Read lexicon with " + size() + " words.");
		logger.trace(this);
	}

	private static boolean commented = false;

	/**
	 * @param line
	 * @return null if the line is entirely commented out, all uncommented parts (including empty line) otherwise
	 */
	public static String comment(String line) {
		// return empty lines unchanged
		if (line.isEmpty()) {
			return line;
		}
		// remove all /*stuff*/ within line
		line = line.replaceAll(Pattern.quote(BEGIN_COMMENT) + ".*?" + Pattern.quote(END_COMMENT), "");
		// if already in a comment, drop everything until after */
		if (commented) {
			if (line.contains(END_COMMENT)) {
				commented = false;
				line = line.substring(line.indexOf(END_COMMENT) + END_COMMENT.length());
			} else {
				return null;
			}
		}
		// drop everything after lonely /* and remember we're in a comment
		if (line.contains(BEGIN_COMMENT)) {
			commented = true;
			line = line.substring(0, line.indexOf(BEGIN_COMMENT));
		}
		// drop everything after //
		if (line.contains(LINE_COMMENT)) {
			line = line.substring(0, line.indexOf(LINE_COMMENT));
		}
		if (line.isEmpty()) {
			return null;
		}
		return line;
	}

}

/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.action;

import org.apache.log4j.Logger;

import qmul.ds.ParserTuple;
import qmul.ds.action.atomic.Effect;
import qmul.ds.tree.Tree;

/**
 * An IF-THEN-ELSE action template
 * 
 * @author mpurver
 */
public abstract class Action {

	protected static Logger logger = Logger.getLogger(Action.class);

	protected String name;
	protected Effect action;

	public Action() {

	}

	public Action(String name, Effect action) {
		this.name = name;
		this.action = action;
	}

	public Action(Action a) {
		this(a.getName(), a.getEffect());
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	public Effect getEffect() {
		return this.action;
	}

	/**
	 * Apply a lexical/computational action to a {@link Tree} (optionally given a context {@link ParserTuple})
	 * 
	 * @param tree
	 * @param context
	 *            (can be null)
	 * @return a new {@link Tree} if successful, null otherwise
	 */
	public <T extends Tree> T exec(T tree, ParserTuple context) {
		return action.exec(tree, context);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return name + ":\n" + action;
	}

	public abstract Action instantiate();

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		logger.debug("using this");
		if (this == o)
			return true;
		if (o == null)
			return false;
		else if (this.getClass() != o.getClass())
			return false;
		else {
			// by default (and for computational actions), name is unique
			Action a = (Action) o;
			return a.getName().equals(getName());
		}
	}

}

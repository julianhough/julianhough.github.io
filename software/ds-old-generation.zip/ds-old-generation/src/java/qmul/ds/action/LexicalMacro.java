/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.action;

import java.util.ArrayList;
import java.util.List;

import qmul.ds.ParserTuple;
import qmul.ds.action.atomic.Effect;
import qmul.ds.action.atomic.EffectFactory;
import qmul.ds.tree.Tree;

public class LexicalMacro extends Effect {

	String name;
	ArrayList<Effect> actions;

	// lines here have been instantiated
	public LexicalMacro(String name, List<String> lines) {
		actions = new ArrayList<Effect>();
		// logger.debug("creating lexical macro from:"+lines);
		this.name = name;
		for (String line : lines) {
			actions.add(EffectFactory.create(line.trim()));

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.action.atomic.Effect#exec(qmul.ds.tree.Tree, qmul.ds.ParserTuple)
	 */
	@Override
	public <T extends Tree> T exec(T tree, ParserTuple context) {

		for (Effect e : actions) {
			e.exec(tree, context);
			if (tree == null) {
				logger.debug("Action in macro call" + name + " failed:" + e);
			} else {
				logger.debug("result: " + tree);
			}
		}
		return tree;
	}

	public String toString() {
		return name;
	}

	public ArrayList<Effect> getActions() {
		return actions;
	}

}

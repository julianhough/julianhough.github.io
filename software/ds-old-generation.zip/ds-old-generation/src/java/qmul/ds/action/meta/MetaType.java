/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.action.meta;

import java.util.ArrayList;

import qmul.ds.type.Type;

/**
 * A {@link Type} metavariable as used in rule specs e.g. X, Y
 * 
 * @author mpurver
 */
public class MetaType extends Type {

	private MetaElement<Type> meta;

	/**
	 * @param meta
	 */
	protected MetaType(MetaElement<Type> meta) {
		this.meta = meta;
	}

	/**
	 * @return the value
	 */
	public Type getValue() {
		return meta.getValue();
	}

	/**
	 * @return the meta-element
	 */
	public MetaElement<Type> getMeta() {
		return meta;
	}

	/**
	 * @return the meta-elements
	 */
	public ArrayList<MetaElement<?>> getMetas() {
		ArrayList<MetaElement<?>> metas = new ArrayList<MetaElement<?>>();
		metas.add(meta);
		return metas;
	}

	/**
	 * @param name
	 * @return the existing metavariable of this name (with its value), a new one otherwise
	 */
	public static MetaType get(String name) {
		return new MetaType(MetaElement.get(name, Type.class));
		/*
		 * if (!pool.containsKey(name)) { pool.put(name, new MetaType(MetaElement.get(name, Type.class))); } return
		 * pool.get(name);
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.type.Type#instantiate()
	 */
	@Override
	public Type instantiate() {
		if (getValue() == null) {
			return this;
		}
		return getValue().instantiate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Type))
			return false;
		// SIDE-EFFECT: checking equality sets metavariable value! (no hashCode)
		if (obj instanceof MetaType) {
			return meta.equals(((MetaType) obj).meta.getValue());
		} else {
			return meta.equals(obj);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return meta.toString();
	}

}

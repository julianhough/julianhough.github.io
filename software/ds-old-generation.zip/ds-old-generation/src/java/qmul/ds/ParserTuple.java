/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds;

import java.util.ArrayList;
import java.util.Collection;

import qmul.ds.action.Action;
import qmul.ds.action.ComputationalAction;
import qmul.ds.tree.Tree;

/**
 * A parser tuple (member of a {@link ParseState}). At its simplest, just a {@link Tree}, but more complex
 * {@link Parser}s may add context information, probabilities etc
 * 
 * @author mpurver
 */
public class ParserTuple implements Comparable<ParserTuple>, Cloneable {

	protected Tree tree;

	/**
	 * A new tuple containing an AXIOM tree
	 */
	public ParserTuple() {
		tree = new Tree();
	}

	/**
	 * A new tuple containing a cloned copy of the given tree
	 * 
	 * @param tree
	 */
	public ParserTuple(Tree tree) {
		this.tree = new Tree(tree);
	}

	/**
	 * A new tuple containing a cloned copy of the given tree
	 * 
	 * @param tree
	 */
	public ParserTuple(ParserTuple tuple) {
		this.tree = new Tree(tuple.tree);
	}

	/**
	 * @return the tree
	 */
	public Tree getTree() {
		return tree;
	}

	public void setTree(Tree newtree){
		tree = newtree;
	}
	/**
	 * @param action
	 * @param word
	 * @return the result of applying action to a copy of this tuple; this will be null if the action aborts. Word may
	 *         be null if this is a non-lexical action
	 */
	public ParserTuple execAction(Action action, String word) {
		Tree result = action.exec(tree.clone(), this);
		if (result == null) {
			return null;
		}
		return new ParserTuple(result);
	}

	public Collection<? extends ParserTuple> execExhaustively(Action action, String word) {
		ComputationalAction ca;
		if (action instanceof ComputationalAction)
			ca = (ComputationalAction) action;
		else
			throw new IllegalArgumentException("Only computational actions can apply exhaustively");

		Collection<Tree> trees = ca.execExhaustively(tree, this);

		if (trees == null)
			return null;
		if (trees.isEmpty())
			return null;
		Collection<ParserTuple> result = new ArrayList<ParserTuple>();
		for (Tree t : trees)
			result.add(new ParserTuple(t));

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
		return new ParserTuple(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ParserTuple other) {

		if (this.tree.isComplete()) {
			if (other.tree.isComplete()) {
				return (other.hashCode() - this.hashCode());
			} else {
				return -1;
			}
		} else {
			if (other.tree.isComplete()) {
				return 1;
			} else {
				int r = this.tree.numRequirements() - other.tree.numRequirements();
				if (r == 0) {
					return (other.hashCode() - this.hashCode());
				}
				return r;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		// logger.debug("using hashcode in ParserTuple");
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tree == null) ? 0 : tree.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// logger.debug("using equals in parsertuple");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParserTuple other = (ParserTuple) obj;
		if (tree == null) {
			if (other.tree != null)
				return false;
		} else if (!tree.equals(other.tree))
			return false;
		return true;
	}
	
	public boolean isComplete()
	{
		return this.tree.isComplete();
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return tree.toString();
	}

}

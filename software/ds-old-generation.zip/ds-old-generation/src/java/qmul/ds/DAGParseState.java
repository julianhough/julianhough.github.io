package qmul.ds;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Logger;

import qmul.ds.action.Action;

public class DAGParseState extends ParseState<DAGParserTuple> implements Cloneable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(DAGParseState.class);
	
	private DAGParserTuple cur;
	private Stack<String> wordStack;
	private int depth;
	private boolean exhausted=false;
	private DAGParserTuple firstTupleAfterLastWord;
	public DAGParseState()
	{
		super();
		cur=new DAGParserTuple();
		add(new DAGParserTuple(cur.tree));
		wordStack=new Stack<String>();
		depth=1;
		thisIsFirstTupleAfterLastWord();
	}
	
	@SuppressWarnings("unchecked")
	public DAGParseState(DAGParseState dagParseState) {
		for(ParserTuple t:dagParseState)
		{
			add(new DAGParserTuple(t.tree));
		}
		this.cur=new DAGParserTuple(dagParseState.cur);
		this.depth=dagParseState.depth;
		this.wordStack=(Stack<String>)dagParseState.wordStack.clone();
		this.firstTupleAfterLastWord=dagParseState.firstTupleAfterLastWord;
	}
	
	public void resetToFirstTupleAfterLastWord()
	{
		if (firstTupleAfterLastWord!=null)
		{
			clear();
			this.cur=firstTupleAfterLastWord;
			add(new DAGParserTuple(firstTupleAfterLastWord.tree));
			exhausted=false;
			this.wordStack().clear();
		}
	}

	public void thisIsFirstTupleAfterLastWord()
	{
		this.firstTupleAfterLastWord=this.cur;
	}
	
	public void setExhausted(boolean a)
	{
		this.exhausted=a;
	}

	public void setCurrentTuple(DAGParserTuple result) {
		this.cur=result;
		
	}
	public DAGParserTuple getCurrentTuple()
	{
		return cur;
	}
	
	//this will return null if action returns null or if it's already been tried and failed.
	public DAGParserTuple execAction(Action a, String word)
	{
		DAGParserTuple result=this.getCurrentTuple().execAction(a, word);
		if (result==null) return null;
		this.setCurrentTuple(result);
		return cur;
		
	}

	public Action getParentAction() {
		
		return this.cur.actionLeadingToThis;
	}
	
	public boolean atRoot()
	{
		return this.cur.parent==null;
	}
	
	public void attachTuple(DAGParserTuple tuple)
	{
		tuple.parent=cur;
		cur=tuple;
	}
	
	/**
	 * Moves pointer to first child. If the action edge is lexical pops the corresponding word off the remaining words
	 * stack.
	 * @return
	 */

	public DAGParserTuple goFirst() {
		if (this.cur.children==null || this.cur.children.isEmpty()) return null;
		
		depth++;
		
		for(DAGParserTuple child: this.cur.children.keySet())
		{
			if (!this.cur.children.get(child))
			{
				System.out.println("Going forward (first) along "+child.actionLeadingToThis.getName());
				this.cur=child;
				if (child.word!=null) 
					this.wordStack.pop();
				return this.cur;
			}
		}
			
		return null;
		
	}
	
	public DAGParserTuple goUpOnce()
	{
		if (atRoot())
		{
			System.out.println("Can't go up");
			return null;
		}
		depth--;
		System.out.println("going back along: "+this.cur.actionLeadingToThis.getName());
		this.cur=this.cur.parent;
		return this.cur;
	}
	
	public Stack<String> wordStack()
	{
		return this.wordStack;
	}
	
	public Object Clone()
	{
		return new DAGParseState(this);
		
	}
		
	public boolean isComplete()
	{
		return this.cur.isComplete();
	}
	
	public List<Action> getActionSequence()
	{
		DAGParserTuple current=this.cur;
		List<Action> result=new ArrayList<Action>();
		while(current.actionLeadingToThis!=null)
		{		
			result.add(0, current.actionLeadingToThis);
			current=current.parent;
		}
		return result;
	}

	public int getDepth() {
		return this.depth;
	}
	
	public void init()
	{
		clear();
		cur=new DAGParserTuple();
		add(new DAGParserTuple(cur.tree));
		wordStack=new Stack<String>();
		exhausted=false;
		this.firstTupleAfterLastWord=cur;
		depth=1;
	}

	public boolean isExhausted() {
		return this.exhausted;
		
	}

}

	
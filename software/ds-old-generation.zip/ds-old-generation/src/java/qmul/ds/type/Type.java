/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.type;

import java.util.regex.Pattern;

import qmul.ds.action.boundvariable.BoundTypeVariable;
import qmul.ds.action.meta.MetaType;
import qmul.ds.tree.label.LabelFactory;
import edu.stanford.nlp.util.Pair;

public class Type {

	public final static String TYPE_LEFT = "(";
	public final static String TYPE_RIGHT = ")";
	public final static String TYPE_SEP = ">";
	public final static String UNICODE_TYPE_SEP = "\u2192"; // short right arrow

	public final static Type e = new BasicType("e");
	public final static Type t = new BasicType("t");
	public final static Type cn = new BasicType("cn");
	public final static Type es = new BasicType("es");

	public final static Type et = new ConstructedType(e, t);
	public final static Type eet = new ConstructedType(e, et);

	/**
	 * @param type
	 *            the basic type string e.g. "e", "t"
	 * @return a new basic type e.g. e, t
	 */
	public static BasicType create(String type) {
		return new BasicType(type.trim());
	}

	/**
	 * @param from
	 * @param to
	 * @return a new constructed type from>to e.g. e>t, (e>t)>t
	 */
	public static ConstructedType create(Type from, Type to) {
		return new ConstructedType(from, to);
	}

	/**
	 * @param string
	 *            a {@link String} representation e.g. "e", "e>t", "e>(e>t)" as used in lexicon specs
	 * @return a new type
	 */
	public static Type parse(String string) {
		string = string.trim();
		if (string.contains(TYPE_SEP)) {
			Pair<String, String> fromTo = split(string);
			if (fromTo.second().isEmpty()) {
				return new BasicType(fromTo.first());
			}
			return new ConstructedType(parse(fromTo.first()), parse(fromTo.second()));
		} else {
			// upper-case single letter - type metavariable
			if (string.matches("^" + LabelFactory.METAVARIABLE_PATTERN + "$")) {
				return MetaType.get(string);
			} else if (string.matches("^" + LabelFactory.VAR_PATTERN + "$")) {
				return new BoundTypeVariable(string);
			}
			// could do more error-checking here ...
			return new BasicType(string);
		}
	}

	/**
	 * @param string
	 *            "X,Y" where X and/or Y may be complex e.g. "(e>t)>(e>(e>t))"
	 * @return a {@link Pair} of X and Y
	 */
	private static Pair<String, String> split(String string) {
		int n = 0;
		for (int i = 0; i < string.length(); i++) {
			String remaining = string.substring(i);
			if (remaining.startsWith(TYPE_LEFT)) {
				n++;
			} else if (remaining.startsWith(TYPE_RIGHT)) {
				n--;
			} else if (remaining.startsWith(TYPE_SEP) && (n == 0)) {
				return new Pair<String, String>(string.substring(0, i), remaining.substring(TYPE_SEP.length()));
			}
		}
		// didn't find TYPE_SEP? check for entire thing enclosed in brackets
		// e.g. "(e>t)"
		if (string.startsWith(TYPE_LEFT) && string.endsWith(TYPE_RIGHT)) {
			return split(string.substring(TYPE_LEFT.length(), string.length() - TYPE_RIGHT.length()));
		}
		// still didn't find it? give up
		return new Pair<String, String>(string, "");
	}

	/**
	 * @return an instantiated version of this {@link Type}, with all meta-elements replaced by their values. By
	 *         default, just return this {@link Type} unchanged. This will be overridden by {@link MetaType}s and the
	 *         like
	 */
	public Type instantiate() {
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	// public int hashCode() {
	// // we need to have one hashCode for all Types, to allow metavariable
	// matching ...
	// // (it's that or use TreeMaps for Nodes)
	// return 7;
	// }

	/**
	 * @return replacing TYPE_SEP with its Unicode version
	 */
	public String toUnicodeString() {
		return toString().replaceAll(Pattern.quote(TYPE_SEP), UNICODE_TYPE_SEP);
	}

	public int hashCode() {
		return toString().hashCode();
	}
	/*
	 * public boolean equals(Object o) {
	 * 
	 * }
	 */

}

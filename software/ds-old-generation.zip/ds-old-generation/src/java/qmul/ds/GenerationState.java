/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds;

import java.util.Collection;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import qmul.ds.formula.TTRFormula;
import qmul.ds.tree.Tree;

/**
 * A generation state: a goal {@link Tree} and a set of {@link GeneratorTuple}s. Members should be ordered (by their
 * natural ordering) best-first
 * 
 * @author mpurver
 * 
 * @param <T>
 */
@SuppressWarnings("serial")
public class GenerationState<T extends ParserTuple> extends TreeSet<GeneratorTuple<T>> implements Cloneable {

	private static Logger logger = Logger.getLogger(GenerationState.class);

	public Tree goalTree;
	public TTRFormula goalTTR;

	public GenerationState() {
		super();
	}

	public GenerationState(Collection<GeneratorTuple<T>> c) {
		super(c);
	}

	public GenerationState(Tree goalTree) {
		super();
		this.goalTree = goalTree;
	}

	public GenerationState(Tree goalTree, Collection<GeneratorTuple<T>> c) {
		super(c);
		this.goalTree = goalTree;
	}

	/**
	 * @return the goalTree
	 */
	public Tree getGoalTree() {
		return goalTree;
	}
	
	/**
	 * @param goalTree
	 *            the goalTree to set
	 */
	public void setGoalTree(Tree goalTree) {
		this.goalTree = goalTree;
	}
	
	public GenerationState(TTRFormula goalTTR) {
		super();
		this.goalTTR = goalTTR;
	}

	public GenerationState(TTRFormula goalTTR, Collection<GeneratorTuple<T>> c) {
		super(c);
		this.goalTTR = goalTTR;
	}
	/**
	 * @return the goalTTR
	 */
	public TTRFormula getGoalTTR() {
		return goalTTR;
	}
	
	/**
	 * @param goalTTR
	 *            the goalTTR to set
	 */
	public void setGoalTTR(TTRFormula goalTTR) {
		this.goalTTR = goalTTR;
	}

	
	
	

	/**
	 * @return true if this state contains at least one complete {@link GeneratorTuple}
	 */
	public boolean hasCompleteTuple() {
		for (GeneratorTuple<T> tuple : this) {
			if (tuple.hasCompleteTree()) {
				return true;
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.HashSet#clone()
	 */
	public GenerationState<T> clone() {
		return new GenerationState<T>(goalTree, this);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.HashSet#clone()
	 */
	public GenerationState<T> cloneTTR() {
		return new GenerationState<T>(goalTTR, this);
	}

}

package qmul.ds.tree;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import qmul.ds.formula.Formula;
import qmul.ds.formula.LambdaAbstract;
import qmul.ds.formula.TTRFormula;
import qmul.ds.formula.TTRFormulaMatcher;
import qmul.ds.formula.TTRLabel;
import qmul.ds.formula.Variable;
import qmul.ds.tree.label.FormulaLabel;
import qmul.ds.tree.label.Label;
import qmul.ds.tree.label.Requirement;
import qmul.ds.tree.label.TypeLabel;
import qmul.ds.type.Type;
import edu.stanford.nlp.trees.LabeledScoredTreeFactory;
import edu.stanford.nlp.trees.TreeFactory;

/**
 * A DS tree
 * 
 * @author mpurver
 */
public class Tree extends TreeMap<NodeAddress, Node> implements Cloneable {

	private static final String ENTITY_VARIABLE_ROOT = "x";
	private static final String EVENT_VARIABLE_ROOT = "e";
	private static final String PROPOSITION_VARIABLE_ROOT = "p";

	private static Logger logger = Logger.getLogger(Tree.class);

	private static final long serialVersionUID = 7042021136833923864L;

	private NodeAddress pointer;

	private static final String UNICODE_POINTER = "\u25C6"; // black diamond;
	// also white
	// diamond 25CA

	private int numRequirements = 1; // only a rough count for sorting, use

	// isComplete() for reliable check

	/**
	 * A new AXIOM tree
	 */
	public Tree() {
		super();
		pointer = new NodeAddress();
		Node node = new Node(pointer);
		node.addLabel(new Requirement(TypeLabel.t, null));
		put(pointer, node);
	}

	/**
	 * A new copy of tree, with (shallow) cloned {@link Node}s
	 * 
	 * @param tree
	 */
	public Tree(Tree tree) {
		super();
		for (NodeAddress key : tree.keySet()) {
			put(key, tree.get(key).clone());
		}
		setPointer(tree.pointer);
		numRequirements = tree.numRequirements;
		this.entityPool = tree.entityPool;
		this.eventPool = tree.eventPool;
		this.propositionPool = tree.propositionPool;
	}

	private ArrayList<Variable> entityPool = new ArrayList<Variable>();
	private ArrayList<Variable> eventPool = new ArrayList<Variable>();
	private ArrayList<Variable> propositionPool = new ArrayList<Variable>();

	/**
	 * A fresh entity variable x1, x2 etc
	 */
	public Variable getFreshEntityVariable() {
		Variable v = new Variable(ENTITY_VARIABLE_ROOT + (entityPool.size() + 1));
		entityPool.add(v);
		return v;
	}

	/**
	 * A fresh event variable e1, e2 etc
	 */
	public Variable getFreshEventVariable() {
		Variable v = new Variable(EVENT_VARIABLE_ROOT + (eventPool.size() + 1));
		eventPool.add(v);
		return v;
	}

	/**
	 * A fresh proposition variable p1, p2 etc
	 */
	public Variable getFreshPropositionVariable() {
		Variable v = new Variable(PROPOSITION_VARIABLE_ROOT + (propositionPool.size() + 1));
		propositionPool.add(v);
		return v;
	}

	/**
	 * @return the root node
	 */
	public Node getRootNode() {
		return get(new NodeAddress());
	}

	/**
	 * @return the pointer
	 */
	public NodeAddress getPointer() {
		return pointer;
	}

	/**
	 * search for node labelled with the set of labels passed as argument
	 * 
	 * @param Treeset
	 *            of labels the pointer to set
	 * @return Node the node containing all the labels
	 */
	public Node getNodeLabelledWith(TreeSet<Label> labelSet) {
		Node: for (NodeAddress na : this.keySet()) {
			Node cur = this.get(na);
			for (Label l : labelSet) {
				if (!cur.hasLabel(l))
					continue Node;
			}
			return cur;
		}
		return null;
	}

	/**
	 * search for node labelled with all the labels passed as argument
	 * 
	 * @param labels
	 *            labels to search for on each node
	 * @return boolean true if tree contains such a node; false otherwise
	 */
	public boolean hasNodeLabelledWith(Collection<Label> labels) {
		for (Node node : getNodes()) {
			if (node.hasLabels(labels)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param pointer
	 *            the pointer to set
	 */
	public void setPointer(NodeAddress pointer) {
		this.pointer = pointer;
	}

	/**
	 * @return the nodes
	 */
	public Collection<Node> getNodes() {
		return values();
	}

	/**
	 * @return the {@link Node} at the current pointer
	 */
	public Node getPointedNode() {
		return get(getPointer());
	}

	/**
	 * @param modality
	 * @return the {@link Node} we arrive at by going via modality, or null if none exists
	 */
	public Node getNode(Modality modality) {
		return get(getPointer().go(modality));
	}

	/**
	 * Move the pointer
	 * 
	 * @param modality
	 */
	public void go(Modality modality) {
		NodeAddress addr = getPointer().go(modality);
		if ((addr == null) || !containsKey(addr)) {
			throw new RuntimeException("Can't go to non-existent node " + addr);
		}
		setPointer(addr);
	}

	/**
	 * Make a new daughter node below the pointed node
	 * 
	 * @param op
	 */
	public void make(BasicOperator op) {

		if (!(op.isDown())) {
			throw new RuntimeException("Can't make non-daughter node " + op);
		}
		NodeAddress addr = getPointer().go(op);
		if (!containsKey(addr)) {
			put(addr, new Node(addr));
		}
		// logger.debug("Made node in tree" + this);
		// logger.debug("With op:" + op);
	}

	/**
	 * Merge the node at modality with the pointed node, and remove it
	 * 
	 * @param node
	 */
	public void merge(Modality modality) {
		Node node = getNode(modality);
		// move daughters from merged node
		moveDaughters(getDaughters(node), node.getAddress(), pointer);
		// merge labels
		getPointedNode().merge(node);
		// remove merged node
		remove(node.getAddress());
	}

	/**
	 * Move daughters (and their daughters) from from to to
	 * 
	 * @param dtrs
	 * @param from
	 * @param to
	 */
	private void moveDaughters(ArrayList<Node> dtrs, NodeAddress from, NodeAddress to) {
		for (Node dtr : dtrs) {
			moveDaughters(getDaughters(dtr), from, to);
			NodeAddress newAddr = new NodeAddress(dtr.getAddress().getAddress().replaceFirst(
					Pattern.quote(from.getAddress()), to.getAddress()));
			Node newDtr = new Node(newAddr);
			newDtr.addAll(dtr);
			put(newAddr, newDtr);
			remove(dtr.getAddress());
		}
	}

	/**
	 * Add a label at the pointed node
	 * 
	 * @param label
	 */
	public void put(Label label) {
		boolean added = getPointedNode().addLabel(label);
		if (added && (label instanceof Requirement)) {
			numRequirements++;
		}
	}

	/**
	 * Delete a label at the pointed node
	 * 
	 * @param label
	 */
	public void delete(Label label) {
		boolean removed = getPointedNode().removeLabel(label);
		if (!removed)
			logger.error("Failed to delete:" + label);
		if (removed && (label instanceof Requirement)) {
			numRequirements--;
		}
	}

	/**
	 * @param node
	 * @return all existing daughter nodes in order 0,1,LINK,*
	 */
	public ArrayList<Node> getDaughters(Node node) {
		ArrayList<Node> dtrs = new ArrayList<Node>();
		Node d0 = get(node.getAddress().down0());
		if (d0 != null) {
			dtrs.add(d0);
		}
		Node d1 = get(node.getAddress().down1());
		if (d1 != null) {
			dtrs.add(d1);
		}
		Node dL = get(node.getAddress().downLink());
		if (dL != null) {
			dtrs.add(dL);
		}
		Node dU = get(node.getAddress().downStar());
		if (dU != null) {
			dtrs.add(dU);
		}
		Node dLU = get(node.getAddress().downLocalUnfixed());
		if (dLU != null) {
			dtrs.add(dLU);
		}
		return dtrs;
	}
	
	
	
	public ArrayList<Node> getDaughters(Node node, String order)
	{
		ArrayList<Node> dtrs = new ArrayList<Node>();
		for (NodeAddress address : possibleDaughters(node, order)) {
			Node d = get(address);
			if (d != null) {
				dtrs.add(d);
			}
		}
		return dtrs;
	}
	

	public ArrayList<NodeAddress> possibleDaughters(Node node, String order) {
		ArrayList<NodeAddress> addresses = new ArrayList<NodeAddress>();
		for(int i=0;i<order.length();i++)
		{
			addresses.add(node.getAddress().down(order.substring(i, i+1)));
		
		}
		return addresses;
	}

	/**
	 * @return true if this tree is complete i.e. no outstanding requirements at any node AND pointer at root node
	 */
	public boolean isComplete() {
		if (!pointer.isRoot()) {
			return false;
		}
		for (Node node : values()) {
			if (!node.isComplete()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return the number of unsatisfied {@link Requirement}s. NOT A RELIABLE COUNT - just for tree ordering in
	 *         displays. Use isComplete() for a reliable check.
	 */
	public int numRequirements() {
		return numRequirements;
	}

	/**
	 * @param other
	 * @return true if this {@link Tree} subsumes other i.e. each {@link Node} in this {@link Tree} subsumes some
	 *         {@link Node} in other
	 */
	public boolean subsumes(Tree other) {
		node: for (Node thisNode : values()) {
			for (Node otherNode : other.values()) {
				if (thisNode.subsumes(otherNode)) {
					logger.debug("susbume pass for node" + thisNode.getAddress());
					continue node;
				}else {logger.debug("susbume fail for node" + thisNode.getAddress());}
			}
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.TreeMap#clone()
	 */
	@Override
	public Tree clone() {
		return new Tree(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((pointer == null) ? 0 : pointer.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		Tree other = (Tree) obj;
		if (pointer == null) {
			if (other.pointer != null)
				return false;
		} else if (!pointer.equals(other.pointer))
			return false;
		if (!super.equals(other)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String partiality = (isComplete() ? "(C)" : "(P)");
		return "Tree " + partiality + " " + pointer + ":" + values() + "]";
	}

	public edu.stanford.nlp.trees.Tree toStanfordTree() {
		return toStanfordTree(new LabeledScoredTreeFactory(), getRootNode());
	}

	private edu.stanford.nlp.trees.Tree toStanfordTree(TreeFactory tf, Node node) {
		List<edu.stanford.nlp.trees.Tree> kids = new ArrayList<edu.stanford.nlp.trees.Tree>();
		String label = node.toUnicodeString();
		// label = label.replaceAll(Pattern.quote(BasicOperator.ARROW_DOWN),
		// "\u2193");
		// label = label.replaceAll(Pattern.quote(BasicOperator.ARROW_UP),
		// "\u2191");
		// label = label.replaceAll(Pattern.quote(Modality.EXIST_LEFT),
		// "\u27E8"); // 27E8, 2329
		// label = label.replaceAll(Pattern.quote(Modality.EXIST_RIGHT),
		// "\u3009"); // 27E9, 232A
		if (node.getAddress().equals(pointer)) {
			label = label.replaceAll("(" + Pattern.quote(node.getAddress() + Node.ADDRESS_SEPARATOR) + ")",
					UNICODE_POINTER + "$1");
		}
		edu.stanford.nlp.trees.Tree t = tf.newTreeNode(label, kids);
		for (Node n : getDaughters(node)) {
			t.addChild(toStanfordTree(tf, n));
		}
		return t;
	}
	
	/**
	 * returns the node that is the root of this tree, that may not neccessarily be the matrix tree (i.e. could be linked tree)
	 *TODO only assumes linked trees have complex structure, in line with DS theory
	 *
	 * 
	 * @param node
	 * @return
	 */
	public Node getLocalRoot(Node node) {
		String root = "0";
		if (node.getAddress().toString().contains("L"))
		{ String linkModality = node.getAddress().toString().substring(0,node.getAddress().toString().lastIndexOf('L')+1);
			root = linkModality;
			
		}
		logger.debug("local root is " + root);
		return get(new NodeAddress(root));
	}
	
	//TODO make this generalizable for both TTR and normal DS epsilon/lambda calculus trees, using underspecified method and beta compile
	/*
	 * Converts tree into one in which a maximal semantic representation at the top node. This is done by a two step process:
	 * 1. Decorate all leaves with underspecified values
	 * 2. Carry out Beta-reduction from all functors to all leaves. (leaves including those on the end of linked and upper st.)
	 * 
	 */
	public void compileMaximalSemantics(){
		
		
		TTRdecorateNode: for (Node thisNode : values()) {
			
			logger.debug("THIS NODE ADDRESS = " + thisNode.getAddress());
			Type fulltype = thisNode.getType();
			if (!(fulltype == null))
			{logger.debug("COMPLETE TYPE OF NODE = " + fulltype.toString());}
			else if (!(thisNode.getRequiredType()==null)){
				logger.debug("INCOMPLETE TYPE OF NODE = " + thisNode.getRequiredType());
			} else {continue TTRdecorateNode;} //other wise keep going
			
			if (getDaughters(thisNode).isEmpty()&&(thisNode.getFormula()==null))  //if there are no daughters then put dummy TTRValue in place
			{
				
				//new method Formula.underspecified(Type type) should work for TTR and lambda/epsilon calculus
				//for epsilonCalculus Formulae
				//TODO
				//thisNode.add(new FormulaLabel(Formula.underspecified(thisNode.getRequiredType())), true);
				String type = thisNode.getRequiredType().toString();
				
				TTRFormula dummy = new TTRFormula();
				
				logger.debug("putting in dummy value for type " + type);
				
				if (type.equals("es>t"))
				{
			    	dummy = new TTRFormula("p", "null(X)");
			    	thisNode.add(new FormulaLabel(new LambdaAbstract("X", dummy)));
			    	
				} else if (type.endsWith(">(es>t)")) {  //for e>(es>t) //
					
					dummy = new TTRFormula("p", "null(X,Y)");
			    	thisNode.add(new FormulaLabel(new LambdaAbstract("Y", new LambdaAbstract("X", dummy))));
					
				} else if (type.endsWith("e>(es>t))")) {  //for e>(e>(es>t)) and t>(e>(es>t))
						
				   dummy = new TTRFormula("p", "null(X,Y,Z)");
				   thisNode.add(new FormulaLabel(new LambdaAbstract("Z", new LambdaAbstract("Y", new LambdaAbstract("X", dummy)))));
				   
				}else if (type.equals("cn>es")) {  //for the epsilon binder, this should have a formula automatically
					
					dummy = new TTRFormula("e", "eps(X)");
					thisNode.add(new FormulaLabel(new LambdaAbstract("X", dummy)));
					
				} else if (type.endsWith(">(es>cn)")) {  //for the event restrictor
					
					dummy = new TTRFormula("p", "null(X,Y)");
			    	thisNode.add(new FormulaLabel(new LambdaAbstract("X", new LambdaAbstract("Y", dummy))));
				   	
			    	//NOW FOR ARGUMENT NODES!:
				} else if (type.equals("es")){
					
					dummy = new TTRFormula("r", "null");	//nodes with the 'es' type requirement at the event variable node should have formula values
					thisNode.add(new FormulaLabel(dummy));
					
				} else if (type.equals("e")){
					
					dummy = new TTRFormula("x", "null");
					thisNode.add(new FormulaLabel(dummy));
				}
							
			}	
				
		}
	
	logger.debug("SUCCESSFULLY REPLACED NODES before betareduce");
	
    
    //list of nodes in reverse order for bottom up algorithm?? need to check this, still need to make compiling algorithm robust
    Vector<Node> allNodes = new Vector<Node>(values().size());
    //LIFO
    for (Node node : values()) {
    	allNodes.add(0, node);
    }
    
    logger.debug("nodes in checking order are: ");
    for (Node node : allNodes) {
    	logger.debug(node.getAddress());
    }
    
    
    //node cannot be removed until it 1. has beta reduced its daughters, if it has them
    //2. it has performed link and (local) star evaluation on things linked and (locally) starred to it 
    //(i.e. compiled the formula at the root of the link or the single unfixed node to this node's local root)
    //however it cannot do this evaluation 1. obvs, if the linked formula has no formula yet (hasn't betareduced)
    //which will force the 'tree compile pointer' downwards- nb. or 2. beta reduction of a daughter cannot happen
    //if that daughter has a down link/down unfixed node attached to it that doesnot have a compiled formula on it yet..
	
	while (!allNodes.isEmpty()){
			
	nodes : for (Node thisNode : values()){
			  
			  if(!allNodes.contains(thisNode))
			  {continue nodes;}  //already checked off
			  
			  //even if it has formula without recourse to BETA reduce still needs to check both its daughters...    
   	    	  if (getDaughters(thisNode)!=null)  //assuming binary daughters...
   	    	  {
   	    	    for (Node daughter : getDaughters(thisNode))
   	    	    {
   	    	    	if (allNodes.contains(daughter)) {
   	    	    		continue nodes;
   	    	    	}
   	    	    }
   	    		  
   	    	  }
			  
		      logger.debug("Daughters checked, checking for formula or performing BETA on node " + thisNode.getAddress());
	   	      
			  if (thisNode.getFormula()==(null))
	   	      {	logger.debug("this node has no formula, try beta reduce /also check whether axiom"); 

		   	      if(getDaughters(thisNode).size()<=1) {  //root, and no immediate daughters and no formula... must be axiom
		       		  if (thisNode.isRoot()) {
		   	    	  logger.debug("no need to beta reduce");
		       		  thisNode.add(new FormulaLabel(new TTRFormula("p", "??"))); //should this happen i.e. won't be done in first part?
		       		  }
		       		  //allNodes.remove(thisNode);}
		       		  //break nodes;
		       	  }  else if (!(getDaughters(thisNode).get(0).getFormula()==null)&&!(getDaughters(thisNode).get(1).getFormula()==null)
		   	    		   &&!allNodes.contains(getDaughters(thisNode).get(1))&&!allNodes.contains(getDaughters(thisNode).get(0))) //the functor daughter has a label	  
		   	        { 	  logger.debug("the functor and argument daughter have formula labels and have been checked, proceed with beta reduce");
			   	    	 
			   	    	  //TODO could be lambda abstracts
			   	    	   TTRFormula argument = (TTRFormula) getDaughters(thisNode).get(0).getFormula();
				    	  Formula betaReduced = ((LambdaAbstract) getDaughters(thisNode).get(1).getFormula()).betaReduce(argument);
		  
				    	  thisNode.add(new FormulaLabel(betaReduced));
				    	  
			         } else {logger.debug("Functor and argument labels not all there or checked, carry on"); continue nodes;}
	       	  
	   	      
	   	      } 
	   	   
	   	    	  
	
	  			  
				  logger.debug("this node " + thisNode + " now has formula "+ thisNode.getFormula() + "check for link/star/unfixed daughters now.."); 
		   	      //could still have a link... and/or unfixed... and/or locally unfixed node
		   	      
				  Vector<Node> linkedRoots = new Vector<Node>();  //vector of linked/starred/unfixed nodes
				  
		   	      if (get(thisNode.getAddress().downLink())!=null) //it has a link
		   	      {   logger.debug("this node has a link! checking its downlinked node to check if compiled and checked off");
		   	    	  linkedRoots.add(get(thisNode.getAddress().downLink()));
		   	      } 
		   	      if (get(thisNode.getAddress().downStar())!=null)
		   	      {logger.debug("this node has a star-adjoined node! Checking that it's been checked off");
	   	          linkedRoots.add(get(thisNode.getAddress().downStar()));} 
		   	      if (get(thisNode.getAddress().downLocalUnfixed())!=null)
		   	      { logger.debug("this node has an unfixed adjoined node! Checking that it's been checked off");
	   	    	  linkedRoots.add(get(thisNode.getAddress().downLocalUnfixed()));}
		   	      	      
		   	      if (!linkedRoots.isEmpty())
		   	      { for (Node linkRoot : linkedRoots)
		   	      	{  if (allNodes.contains(linkRoot)) {  //unpassed linky daughter
		   	    		  continue nodes; 
		   	    	  }else {
		   	    		  logger.debug("downlink node passed, compile at thisNode's local root if not already linked/compiled"); 
		   	    		  logger.debug("LOCAL ROOT was = " + this.getLocalRoot(thisNode).getFormula());
		   	    		  if (this.getLocalRoot(thisNode).getFormula()!=null) {
		   	    			TTRFormulaMatcher matcher = new TTRFormulaMatcher((TTRFormula) linkRoot.getFormula(), (TTRFormula) getLocalRoot(thisNode).getFormula());
		   	    			  //subtype check not reliable because of relabelling; TTRFormulaMatcher matcher = new TTRFormulaMatcher((TTRFormula) linkRoot.getFormula(), (TTRFormula) getLocalRoot(thisNode).getFormula());
		   	    			  Boolean linkedAlready = false;
		   	    			  for (Label label : this.getLocalRoot(thisNode))
		   	    			  {
		   	    				  if (label.toString()!=null&&label.toString().equalsIgnoreCase("+linked"))
		   	    				  {
		   	    					  linkedAlready = true;
		   	    				  }
		   	    			  }
		   	    			  if (!linkedAlready) {
		   	    		      Formula formula = this.getLocalRoot(thisNode).getFormula().conjoin(linkRoot.getFormula());
		   	    		      //remove the formulae in place
		   	    		      
		   	    		      Label removeL = null;
		   	    		      for (Label label : this.getLocalRoot(thisNode))
		   	    		      {
		   	    		    	  if (label instanceof FormulaLabel) //assuming only one formula label per node!
		   	    		    	  {	  
		   	    		    	  removeL = label;
		   	    		    	  logger.debug("root to be removed = " + removeL);
		   	    		    	  }  
		   	    		      }
		   	    		      this.getLocalRoot(thisNode).remove(removeL);
		   	    			  this.getLocalRoot(thisNode).add(new FormulaLabel(formula));
		   	    			  
		   	    			  
		   	    			  }
		   	    			  else {logger.debug("no need to merge, already link evaluated/merged!");}
		   	    	      }
		   	    		  else {this.getLocalRoot(thisNode).add(new FormulaLabel(linkRoot.getFormula()));}
		   	    		  logger.debug("LOCAL ROOT NOW = " + this.getLocalRoot(thisNode).getFormula());
		   	    	  }  
		   	    	}
		   	      }
		   	      //if we've got this far the node has passed
		   	   	  allNodes.remove(thisNode);
		   	      logger.debug(thisNode.getAddress() + " checked!");		   	       
			}
		
		}
	}
	
}

/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.tree;

import java.util.Collection;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import qmul.ds.ContextParser;
import qmul.ds.action.meta.MetaElement;
import qmul.ds.formula.Formula;
import qmul.ds.formula.LambdaAbstract;
import qmul.ds.formula.TTRFormula;
import qmul.ds.tree.label.ExistentialLabelConjunction;
import qmul.ds.tree.label.FormulaLabel;
import qmul.ds.tree.label.Label;
import qmul.ds.tree.label.LabelFactory;
import qmul.ds.tree.label.Requirement;
import qmul.ds.tree.label.TypeLabel;
import qmul.ds.type.Type;

/**
 * A DS {@link Tree} node
 * 
 * @author mpurver
 */
@SuppressWarnings("serial")
public class Node extends TreeSet<Label> {

	private static Logger logger = Logger.getLogger(Node.class);

	public static final String ADDRESS_SEPARATOR = ":";

	private NodeAddress address;

	public Node(NodeAddress address) {
		super();
		this.address = address;
	}

	public Node(Node node) {
		super(node);
		this.address = node.address;
	}

	/**
	 * @return the address
	 */
	public NodeAddress getAddress() {
		return address;
	}

	/**
	 * @param label
	 * @return true if this {@link Node} is labelled with this {@link Label} (allowing {@link MetaElement} matching)
	 */
	public boolean hasLabel(Label label) {

		return contains(label);

	}

	public boolean contains(Object label) {

		for (Label l : this) {

			if (label.equals(l) || l.equals(label)) {
				return true;
			}

		}
		return false;

	}

	/**
	 * @param labels
	 * @return true if this {@link Node} is labelled with every {@link Label} (allowing {@link MetaElement} matching)
	 */
	public boolean hasLabels(Collection<Label> labels) {
		for (Label l : labels) {
			if (!hasLabel(l)) {
				return false;
			}
		}
		return true;
	}

	public boolean hasRequirement(Label label) {
		return contains(LabelFactory.getRequirement(label));
	}

	public boolean hasType(Type type) {
		return contains(LabelFactory.get(type));
	}

	public boolean hasRequirement(Type type) {
		return contains(LabelFactory.getRequirement(type));
	}

	/**
	 * @param label
	 * @return false if the label was already present
	 */
	public boolean addLabel(Label label) {

		return add(label);
	}

	/**
	 * Overriding TreeMap add(Label). The label to be added needs to be compared with every element in the set via
	 * equals() as this is what instantiates Labels involving meta variables.
	 * 
	 * @param label
	 * @return false if the label was already present
	 */
	@Override
	public boolean add(Label label) {
		for (Label l : this) {
			if (l.equals(label) || label.equals(l))
				return false;
		}
		super.add(label);
		return true;
	}

	/**
	 * @param label
	 * @return false if the label was not already present
	 */
	public boolean removeLabel(Label label) {

		return remove(label);
	}

	public boolean remove(Label label) {
		for (Label l : this) {
			if (l.equals(label) || label.equals(l))
				return super.remove(l);
		}
		return false;
	}

	/**
	 * @param label
	 * @return false if the requirement was not already present
	 */
	public boolean removeRequirement(Label label) {
		return remove(LabelFactory.getRequirement(label));
	}

	/**
	 * Add a new type requirement label
	 * 
	 * @param type
	 * @return false if the {@link Requirement} was already present, true otherwise
	 */
	public boolean addRequirement(Type type) {
		return add(LabelFactory.getRequirement(type));
	}

	/**
	 * Remove the requirement for this type
	 * 
	 * @param type
	 * @return false if the requirement was not already present
	 */
	public boolean removeRequirement(Type type) {
		return remove(LabelFactory.getRequirement(type));
	}

	/**
	 * @param other
	 * @param modality
	 * @return can we get from this node to other via modality?
	 */
	/*
	 * public boolean to(Node other, Modality modality) { return getAddress().to(other.getAddress(), modality); }
	 */
	/**
	 * @return the type of this node if specified, null otherwise
	 */
	public Type getType() {
		for (Label l : this) {
			if (l instanceof TypeLabel) {
				return ((TypeLabel) l).getType();
			}
		}
		return null;
	}

	/**
	 * @return the type requirement for this node if specified, null otherwise
	 */
	public Type getRequiredType() {
		for (Label l : this) {
			if (l instanceof Requirement) {
				Requirement r = (Requirement) l;
				if (r.getLabel() instanceof TypeLabel) {
					return ((TypeLabel) r.getLabel()).getType();
				}
			}
		}
		return null;
	}

	/**
	 * @return the formula of this node if specified, null otherwise
	 */
	public Formula getFormula() {
		for (Label l : this) {

			if (l instanceof FormulaLabel) {
				return ((FormulaLabel) l).getFormula();
			}
		}
		return null;
	}

	/**
	 * @return the formula requirement for this node if specified, null otherwise
	 */
	public Formula getRequiredFormula() {
		for (Label l : this) {
			if (l instanceof Requirement) {
				Requirement r = (Requirement) l;
				if (r.getLabel() instanceof FormulaLabel) {
					return ((FormulaLabel) r.getLabel()).getFormula();
				}
			}
		}
		return null;
	}

	/**
	 * @return true if this node is complete i.e. no outstanding requirements
	 */
	public boolean isComplete() {
		for (Label l : this) {
			if (l instanceof Requirement) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this node is fixed i.e. has no Kleene star in its {@link NodeAddress}
	 */
	public boolean isFixed() {
		return address.isFixed();
	}

	/**
	 * @return true if this is the root node
	 */
	public boolean isRoot() {
		return address.isRoot();
	}

	/**
	 * @param other
	 * @return true if this node subsumes other i.e. nodeaddress subsumes other's address and each {@link Label}
	 *         subsumes some label in other
	 */
	public boolean subsumes(Node other) {
		if (other==null) {
			logger.error("other node is null when checking node subsumption");
		}
		if (!address.subsumes(other.address)) {
			
			return false;
		}
		label: for (Label thisLabel : this) {
			
			for (Label otherLabel : other) {
				//
				
				if (thisLabel.subsumes(otherLabel)) {
					continue label;
				}
			}
			//if this label is an existential requirement, then it subsumes no particular label on other, but
			//this node will subsume other if the existential requirement is actually satisfied on the other (node) and
			//all the rest of the labels here subsume some label on the other node.
			if (thisLabel instanceof Requirement)
			{
				Requirement require=(Requirement)thisLabel;
				if (require.getLabel() instanceof ExistentialLabelConjunction)
				{
					ExistentialLabelConjunction exLabel=(ExistentialLabelConjunction) require.getLabel();
					if (exLabel.check(other))
					{
						//System.out.println("Label "+exLabel+" true on "+other);
						continue label;
					}
				}					
			}
			logger.trace("subsumption fail at " + address + " for label " + thisLabel + " vs " + other);
			return false;
		}
		return true;
	}

	/**
	 * @param other
	 * @return true if this node is unifiable with other i.e. the addresses are compatible, and there are no
	 *         incompatible {@link Type} or {@link Formula} labels TODO add semantic feature checks too
	 */
	public boolean isUnifiable(Node other) {
		if (!other.address.subsumes(address) && !address.subsumes(other.address)) {
			logger.debug("unification failed due to address subsumption");
			return false;
		}
		Type t = getType();
		if (t == null)
			t = getRequiredType();
		if (t != null) {
			Type ot = other.getType();
			if (ot == null)
				ot = other.getRequiredType();
			if ((ot != null) && !t.equals(ot)) {
				return false;
			}
		}
		Formula f = getFormula();
		if (f == null)
			f = getRequiredFormula();
		if (f != null) {
			Formula of = other.getFormula();
			if (of == null)
				of = other.getRequiredFormula();
			if ((of != null) && !f.equals(of)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Merge this node with other, i.e. add all its labels
	 * 
	 * @param other
	 */
	public void merge(Node other) {
		addAll(other);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Node clone() {
		return new Node(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Node other = (Node) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return address + ADDRESS_SEPARATOR + super.toString();
	}

	/**
	 * @return a prettier string for use in GUIs
	 */
	public String toUnicodeString() {
		String prefix = ""; // for TTR formulae, we'll put them first so they
		// can be displayed separately
		String str = "{";
		for (Label l : this) {
			if ((l instanceof FormulaLabel)
					&& ((((FormulaLabel) l).getFormula() instanceof TTRFormula) || ((((FormulaLabel) l).getFormula() instanceof LambdaAbstract) && (((LambdaAbstract) ((FormulaLabel) l)
							.getFormula()).getCore() instanceof TTRFormula)))) {
				prefix = ((FormulaLabel) l).getFormula().toUnicodeString() + TTRFormula.TTR_LINE_BREAK;
			} else {
				str += (str.length() > 1 ? ", " : "") + l.toUnicodeString();
			}
		}
		str += "}";
		return prefix + address + ADDRESS_SEPARATOR + str;
	}
	
	
}

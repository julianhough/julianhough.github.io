/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.tree.label;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import qmul.ds.ParserTuple;
import qmul.ds.action.atomic.IfThenElse;
import qmul.ds.action.meta.MetaElement;
import qmul.ds.tree.Node;
import qmul.ds.tree.Tree;

/**
 * A label which embeds a group of labels to be checked together somewhere, e.g. a modal label <X>(L1, L2, L3, . . )
 * 
 * @author arash
 */

public abstract class EmbeddedLabelGroup extends Label {

	protected List<Label> labels;

	public static final Pattern LABEL_GROUP_PATTERN = Pattern.compile("\\((.+)\\)");

	protected EmbeddedLabelGroup(IfThenElse ite) {
		super(ite);
		labels = new ArrayList<Label>();
	}

	/**
	 * @param label
	 */
	protected EmbeddedLabelGroup(ArrayList<Label> labels) {
		this(labels, null);
	}

	protected EmbeddedLabelGroup(ArrayList<Label> labels, IfThenElse ite) {
		super(ite);
		this.labels = labels;
	}

	/**
	 * @return the label
	 */
	public List<Label> getLabels() {
		return labels;
	}

	/**
	 * @param label
	 *            the label to set
	 */
	protected void setLabel(List<Label> labels) {
		this.labels = labels;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.tree.label.Label#getMetas()
	 */
	@Override
	public ArrayList<MetaElement<?>> getMetas() {
		ArrayList<MetaElement<?>> metas = super.getMetas();
		for (Label l : labels)
			metas.addAll(l.getMetas());

		return metas;
	}

	@Override
	public ArrayList<MetaElement<?>> getBoundMetas() {
		ArrayList<MetaElement<?>> metas = super.getBoundMetas();
		for (Label l : labels)
			metas.addAll(l.getBoundMetas());

		return metas;
	}

	/**
	 * @param node
	 * @return true if the node is decorated with all the labels in this group
	 */
	protected boolean checkAllLabels(Node node) {

		ArrayList<MetaElement<?>> uninstantiatedBeforeCheck = getUninstantiatedMetas();

		for (Label l : labels) {
			logger.debug("checking label " + l + " on node " + node);
			if (!l.check(node)) {
				partialResetMetas(uninstantiatedBeforeCheck);
				return false;
			}
		}
		return true;
	}

	protected boolean checkAll(Tree t, ParserTuple context) {
		ArrayList<MetaElement<?>> uninstantiatedBeforeCheck = getUninstantiatedMetas();

		for (Label l : labels) {
			if (!l.check(t, context)) {
				partialResetMetas(uninstantiatedBeforeCheck);
				return false;
			}
		}
		return true;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.tree.label.Label#instantiate()
	 */
	@Override
	public abstract Label instantiate();

	public String toString() {
		String result = "(";
		for (Label l : labels)
			result += l.toString() + "& ";

		result = result.substring(0, result.length() - 2) + ")";
		return result;
	}

	public String toUnicodeString() {
		String result = "(";
		for (Label l : labels)
			result += l.toUnicodeString() + "& ";

		result = result.substring(0, result.length() - 2) + ")";
		return result;
	}

}

package qmul.ds;

import java.io.File;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;

import qmul.ds.action.Action;
import qmul.ds.action.ComputationalAction;
import qmul.ds.action.Grammar;
import qmul.ds.action.LexicalAction;
import qmul.ds.action.Lexicon;
import edu.stanford.nlp.ling.HasWord;

public class DAGDepthFirstParser extends Parser<DAGParserTuple> implements edu.stanford.nlp.parser.Parser  {
	
	
	private static Logger logger = Logger.getLogger(DAGDepthFirstParser.class);
	
	protected DAGParseState state;
	protected Grammar nonoptionalGrammar;//as determined by the prefix * in action spec files.
	protected Grammar optionalGrammar;

	public DAGDepthFirstParser(Lexicon lexicon, Grammar grammar) {
		super(lexicon, grammar);
		super.state=null;
		this.state = new DAGParseState();
		separateGrammars();
	}
	
	private void separateGrammars()
	{
		this.nonoptionalGrammar=new Grammar();
		this.optionalGrammar=new Grammar();
		for(ComputationalAction a: grammar)
		{
			if (a.isAlwaysGood()) this.nonoptionalGrammar.add(a);
			else this.optionalGrammar.add(a);
		}
	}
	
	/**
	 * @param resourceDir
	 *            the dir containing computational-actions.txt, lexical-actions.txt, lexicon.txt
	 */
	public DAGDepthFirstParser(File resourceDir) {
		super(new Lexicon(resourceDir), new Grammar(resourceDir));
		super.state=null;
		this.state = new DAGParseState();
		separateGrammars();
	}
	
	public DAGParseState getState()
	{
		
		return this.state;
	}

	/**
	 * @param resourceDirNameOrURL
	 *            the dir containing computational-actions.txt, lexical-actions.txt, lexicon.txt
	 */
	public DAGDepthFirstParser(String resourceDirNameOrURL) {
		super(new Lexicon(resourceDirNameOrURL), new Grammar(resourceDirNameOrURL));
		super.state=null;
		this.state = new DAGParseState();
		separateGrammars();
	}
	
	
	protected DAGParserTuple getAxiom() {
		
		return new DAGParserTuple();
	}

	public void init()
	{
		addAxiom();
	}
	
	/**
	 * Add a new AXIOM {@link ParserTuple} to the state, by default ensuring that the state is empty. Subclasses may
	 * override this to e.g. move the current state to the context
	 */
	protected void addAxiom() {
		logger.trace("Running addAxiom in Parser.");
		state.init();
	}
	/**
	 * Tell the parser we're beginning a new sentence. By default, this just resets to the initial (axiom) state
	 * 
	 * @see init()
	 */
	public void newSentence() {
		//TODO: currently just resetting, i.e. no context.
		addAxiom();

	}

	public DAGParseState stepThrough()
	{
		DAGParseState state=new DAGParseState(this.state);
		return stepThrough(state);
	}
	
	public DAGParseState stepThrough(DAGParseState state)
	{
		
		int initiallyOnStack=state.wordStack().size();
		DAGParserTuple result = applyAllActions();
		do
		{			
			result=state.goFirst();
			if (result!=null)
			{
				if (state.wordStack().size()>initiallyOnStack)
				{
					applyAllActions(state);
					continue;
				}
				break;
			}
			
		} while(attemptBacktrack(state));
		if (result==null) return null;
		return state;
	}
	
	public DAGParserTuple adjustOnce()
	{
		DAGParserTuple result = applyAllActions();
		do
		{			
			result=state.goFirst();
			if (result!=null) break;
			
			
		} while(attemptBacktrack());
		
		return result;
		
	}
	
	
	public ParseState<DAGParserTuple> parseWord(String word)
	{
		state.resetToFirstTupleAfterLastWord();
		Collection<LexicalAction> actions= this.lexicon.get(word);
		if (actions==null || actions.isEmpty())
		{
			logger.error("Word not in Lexicon: "+word);
			return null;
		}		
		
		state.wordStack().push(word);
		state.clear();
		if (!parse())
		{
			System.out.println("ParseWord returning null");
			return null;
		}
		this.state.thisIsFirstTupleAfterLastWord();
		
		return this.state;		
	}
	
	
	
	public boolean parse()
	{
		if (state.isExhausted())
		{
			System.out.println("state exhausted");
			return false;
		}
		DAGParserTuple cur=null;
		do
		{
			cur=adjustOnce();
			if (cur==null)
			{
				state.setExhausted(true);			
				return false;
			}
			
			
		}while(!state.wordStack().isEmpty());
		state.add(new DAGParserTuple(cur.tree));
		return true;
	}
	
	
	/**
	 * applies all available actions, i.e. computational and the lexical actions associated with the top of
	 * the words stack, to the current tuple. Returns the current tuple without moving the pointer. 
	 * 
	 * @return
	 */
	public DAGParserTuple applyAllActions()
	{
		state.getCurrentTuple().children.clear();
		if (!state.wordStack().isEmpty())
		{	
			
			for(LexicalAction la: lexicon.get(state.wordStack().peek()))
			{
				this.state.getCurrentTuple().execAction(la, la.getWord());			
			}
			
		}
		
		for(ComputationalAction a: this.nonoptionalGrammar)
		{
			//if a non-optional action can be carried out, it has to be, with no other computational possibilities 
			//on this node
			
			DAGParserTuple tuple=this.state.getCurrentTuple().execAction(a, null);
			if (tuple!=null) return this.state.getCurrentTuple();
		}
		
		for(ComputationalAction a: this.optionalGrammar)
		{
			this.state.getCurrentTuple().execAction(a, null);
		}
		
		return this.state.getCurrentTuple();
		
	}
	/**
	 * 
	 * @return true if successful, false if we're at root without any more exploration possibilities
	 */
	public boolean attemptBacktrack()
	{
			
		while(!state.getCurrentTuple().hasMoreChildren())
		{
			if (this.state.atRoot()) return false;
			Action backAlong=state.getParentAction();
			if (backAlong instanceof LexicalAction)
			{
				
				state.wordStack().push(((LexicalAction)backAlong).getWord());
				System.out.println("adding word to stack, now:"+state.wordStack());
			}
			DAGParserTuple current=state.getCurrentTuple();
			this.state.goUpOnce();
			//mark failed child that we're back from as seen (already explored)...
			this.state.getCurrentTuple().markChildAsSeen(current);
			
		}
		System.out.println("Backtrack succeeded");
		
		return true;
	}
	
	
	/**
	 * applies all available actions, i.e. computational and the lexical actions associated with the top of
	 * the words stack, to the current tuple. Returns the current tuple without moving the pointer. 
	 * 
	 * @return
	 */
	public void applyAllActions(DAGParseState state)
	{
		state.getCurrentTuple().children.clear();
		if (!state.wordStack().isEmpty())
		{	
			for(LexicalAction la: this.lexicon.get(state.wordStack().peek()))
			{
				state.getCurrentTuple().execAction(la, la.getWord());			
			}
			
		}
		
		for(ComputationalAction a: this.nonoptionalGrammar)
		{
			//if a non-optional action can be carried out, it has to be, with no other computational possibilities 
			//on this node
			
			DAGParserTuple tuple=state.getCurrentTuple().execAction(a, null);
			if (tuple!=null) return;
		}
		
		for(ComputationalAction a: this.optionalGrammar)
		{
			state.getCurrentTuple().execAction(a, null);
		}
		
	}
	
	/**
	 * 
	 * @return true if successful, false if we're at root without any more exploration possibilities
	 */
	public boolean attemptBacktrack(DAGParseState state)
	{
			
		while(!state.getCurrentTuple().hasMoreChildren())
		{
			if (state.atRoot()) return false;
			Action backAlong=state.getParentAction();
			if (backAlong instanceof LexicalAction)				
				state.wordStack().push(((LexicalAction)backAlong).getWord());
			DAGParserTuple current=state.getCurrentTuple();
			state.goUpOnce();
			//mark failed child that we're back from as seen...
			state.getCurrentTuple().markChildAsSeen(current);
			
		}
		System.out.println("Backtrack succeeded");
		
		return true;
	}
	
	public boolean completeOnce()
	{
		do
		{
			if(!parse()) return false;
			
		}while(!state.isComplete());
		
		return true;
	}
	
	public ParseState<DAGParserTuple> complete()
	{
		ParseState<DAGParserTuple> complete=new ParseState<DAGParserTuple>();
		do{
			if (state.getCurrentTuple().getTree().isComplete())
			{
				complete.add(state.getCurrentTuple());
			}
			
		}while(parse());
		state.resetToFirstTupleAfterLastWord();
		return complete;
	}
	
	@Override
	public boolean parse(List<? extends HasWord> words) {
		
		for (int i=0;i<words.size();i++)
		{
			ParseState<DAGParserTuple> state=parseWord(words.get(i).word());
			if (state==null) return false;
			
		}
		
		return true;
	}
	
	public boolean parse(String[] words)
	{
		for (int i=0;i<words.length;i++)
		{
			ParseState<DAGParserTuple> state=parseWord(words[i]);
			if (state==null) return false;
		}
		
		return true;
		
	}

	@Override
	public boolean parse(List<? extends HasWord> arg0, String arg1) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public Generator<DAGParserTuple> getGenerator() {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	protected Collection<DAGParserTuple> execExhaustively(DAGParserTuple tuple, Action action, String word) {
		// TODO Auto-generated method stub
		return null;
	}
	
	




	@Override
	protected DAGParserTuple execAction(DAGParserTuple tuple, Action action, String word) {
		
		return tuple.execAction(action, word);
	}
	
	public static void main(String args[])
	{
		DAGDepthFirstParser p=new DAGDepthFirstParser("resource/2010-aux-VP-Ellipsis");
		String[] sent={"john"};
		p.parse(sent);
		p.exhaust();
		for(ParserTuple t: p.getState())
			System.out.println(t);
		//p.completeOnce();
		//System.out.println("First Complete:"+p.state.getCurrentTuple());
		/*
		do{
			DAGParserTuple tuple=p.state.getCurrentTuple();
			System.out.println("DAG Depth = " + p.state.getDepth());
			
			System.out.println(tuple);
			
			System.out.println("press enter to continue");
			
			try{
				System.in.read();
			}
			catch(Exception e)
			{
				System.out.println("Console read exception:\n"+e);
			
			}		
			
		}while(p.parse());*/
		
		
	}

	public void exhaust() {
		while(parse());
		
	}
	
	
	
	
	
	
	

}

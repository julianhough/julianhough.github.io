package qmul.ds.learn;

import java.util.HashMap;

import qmul.ds.tree.Tree;

public class Corpus extends HashMap<String, Tree>{
	
	
	public Corpus()
	{
		super();
	}

}

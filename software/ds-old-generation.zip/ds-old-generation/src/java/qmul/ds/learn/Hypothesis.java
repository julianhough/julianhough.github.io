package qmul.ds.learn;

import java.util.List;

import qmul.ds.ParserTuple;
import qmul.ds.action.atomic.Effect;
import qmul.ds.tree.Tree;

public class Hypothesis {
	
	ParserTuple context;
	List<Effect> effects;
	Tree goal;
	
	public Hypothesis(ParserTuple context, List<Effect> effects, Tree g)
	{
		this.context=context;
		this.effects=effects;
		this.goal=g;
	}
	
	
	public String toString()
	{
		String result="";
		result+="Context: "+context+"\n";
		result+="Hypothesised Effects: "+effects+"\n";
		result+="Goal tree was: "+goal+"\n_____________\n";
		return result;
	}
	
	

}

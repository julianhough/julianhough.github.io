package qmul.ds.learn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import qmul.ds.ContextParser;
import qmul.ds.ContextParserTuple;
import qmul.ds.ParseState;
import qmul.ds.Parser;
import qmul.ds.ParserTuple;
import qmul.ds.action.Lexicon;

public class RandomCorpusGenerator<T extends ParserTuple> {
	
	private static Logger logger = Logger.getLogger(RandomCorpusGenerator.class);
	private Parser<T> parser;
	
	public RandomCorpusGenerator(Parser<T> parser)
	{
		this.parser=parser;
		
	}
	
	
	Corpus corpus=new Corpus();
	int howMany=5;
	/**
	 * Remember to adjust the state upon first call, i.e. state should not be empty initially.
	 * @param <T>
	 * @param soFar
	 * @param state
	 * @param maxLength
	 */
	
	
	public void generate(String soFar, int maxLength)
	{
		System.out.println("generate called");
		pause();
		
		
		if (soFar.split("\\s+").length==maxLength) return;
	
		ParseState<T> prevState=parser.getState().clone();
		
		Lexicon lexicon=parser.getLexicon();
		List<String> keyList=new ArrayList<String>(lexicon.keySet());
		Collections.shuffle(keyList);
		int n=1;
		for(String word: keyList)
		{
			System.out.print(n+": ");
			parser.parseWord(word);
			if (parser.getState()!=null && !parser.getState().isEmpty())
			{
				ParseState<T> complete=parser.getState().complete();
				if (!complete.isEmpty())
				{
					String completeSent=soFar+" "+word;
					corpus.put(completeSent, complete.first().getTree());
					System.out.println("Found Complete Sentence: "+completeSent+"\n Content: "+corpus.get(completeSent));
					pause();
				}
				else
				{
					System.out.println("So far: "+soFar+" "+word);
					System.out.println("Best Tree: "+parser.getState().first());
					generate(soFar+" "+word, maxLength);
				}
				
			}
			System.out.println("prevState:"+prevState);
			parser.setState(prevState);
			prevState=parser.getState().clone();
			n++;
			
			
			
		}
		
		
	}
	
	public void generate()
	{
		init();
		generate("", 10);
	}
	
	
	public void init()
	{
		this.parser.init();
	}
	
	private void pause()
	{
		System.out.println("Press enter to continue...");
		try{
			System.in.read();
		}catch(Exception e){}
		
	}
	
	public static void main(String args[])
	{
		Parser<ContextParserTuple> p=new ContextParser("resource/2010-aux-VP-Ellipsis");
		RandomCorpusGenerator<ContextParserTuple> gen=new RandomCorpusGenerator<ContextParserTuple>(p);
		gen.generate();
		for(String sent: gen.corpus.keySet())
		{
			System.out.println(sent);
		}
		
		/*
		p.init();
		ParseState<ContextParserTuple> state=p.getState();
		ParseState<ContextParserTuple> clone=state.clone();
		p.parseWord("likes");
		System.out.println(state);*/
	}

}

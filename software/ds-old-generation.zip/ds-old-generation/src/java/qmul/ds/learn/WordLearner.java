package qmul.ds.learn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import qmul.ds.ContextParser;
import qmul.ds.ContextParserTuple;
import qmul.ds.ParseState;
import qmul.ds.ParserTuple;
import qmul.ds.action.Action;
import qmul.ds.action.LexicalAction;
import qmul.ds.action.atomic.Abort;
import qmul.ds.action.atomic.Effect;
import qmul.ds.action.atomic.EffectFactory;
import qmul.ds.action.atomic.Go;
import qmul.ds.action.atomic.IfThenElse;
import qmul.ds.action.atomic.Make;
import qmul.ds.action.atomic.Put;
import qmul.ds.tree.BasicOperator;
import qmul.ds.tree.Node;
import qmul.ds.tree.NodeAddress;
import qmul.ds.tree.Tree;
import qmul.ds.tree.label.FormulaLabel;
import qmul.ds.tree.label.Label;
import qmul.ds.tree.label.LabelFactory;
import qmul.ds.tree.label.Requirement;
import qmul.ds.tree.label.TypeLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.Word;

/**
 * Inducing individual lexical entries
 * 
 * @author mpurver
 */
public class WordLearner {

	private ContextParser parser;

	private Tree tree;
	private ArrayList<ArrayList<HasWord>> sentences;
	private HashMap<String, ArrayList<Action>> actions;

	/**
	 * A class to learn lexical entries from sentences paired with semantic {@link Tree}s. Uses full grammar to parse
	 * sentence to produce tree, then "forgets" lexical entry and re-learns
	 * 
	 * @param resourceDir
	 *            the grammar to use for existing definitions
	 */
	public WordLearner(String resourceDir) {
		parser = new ContextParser(resourceDir);
		actions = new HashMap<String, ArrayList<Action>>();
	}
		/*
		// the corpus
		sentences = new ArrayList<ArrayList<HasWord>>();
		sentences.add(new ArrayList<HasWord>());
		sentences.get(0).add(new Word("john"));
		sentences.get(0).add(new Word("likes"));
		sentences.get(0).add(new Word("mary"));
		//sentences.add(new ArrayList<HasWord>());
		//sentences.get(1).add(new Word("mary"));
		//sentences.get(1).add(new Word("likes"));
		//sentences.get(1).add(new Word("john"));

		// the words to REMOVE from the lexicon and induce
		 ArrayList<String> unknownWords = new ArrayList<String>(Arrays.asList(new String[] { "john" }));
//		 ArrayList<String> unknownWords = new ArrayList<String>(Arrays.asList(new String[] { "mary" }));
//		 ArrayList<String> unknownWords = new ArrayList<String>(Arrays.asList(new String[] { "john", "mary" }));
//		ArrayList<String> unknownWords = new ArrayList<String>(Arrays.asList(new String[] { "likes" }));
		for (ArrayList<HasWord> sentence : sentences) {
			parser.init();
			parser.parse(sentence);
			System.out.println(parser.getBestParse());
			tree = parser.getBestParse();
			parser.init();
			learn(sentence, tree, unknownWords);
		}
		System.out.println("===");
		for (String word : actions.keySet()) {
			System.out.println("Possible solutions for " + word + " = " + actions.get(word));
		}
	}/*

	/**
	 * @return a manually created Tree for testing
	 * @deprecated not used - use the grammar to parse sentences into trees instead
	 */
	@Deprecated
	private Tree makeTree() {
		Tree tree = new Tree();
		NodeAddress root = tree.getPointer();
		Node node0 = new Node(root);
		node0.add(LabelFactory.create("ty(t)"));
		node0.add(LabelFactory.create("fo(like(john,mary))"));
		node0.add(LabelFactory.create("+pres"));
		tree.put(root, node0);
		tree = effects(tree, Arrays.asList("make(\\/0)", "go(\\/0)", "put(ty(e))", "put(fo(john))", "put(+s3)",
				"put(+male)", "put(!)", "go(/\\)"));
		tree = effects(tree, Arrays.asList("make(\\/1)", "go(\\/1)", "put(ty(e>t))", "put(fo(X^like(X,mary)))"));
		tree = effects(tree, Arrays.asList("make(\\/0)", "go(\\/0)", "put(ty(e))", "put(fo(mary))", "put(+s3)",
				"put(+female)", "put(!)", "go(/\\)"));
		tree = effects(tree, Arrays.asList("make(\\/1)", "go(\\/1)", "put(ty(e>e>t))", "put(+s3)",
				"put(fo(Y^X^like(X,Y)))", "put(!)"));
		tree.setPointer(root);
		System.out.println(tree);
		return tree;
	}

	/**
	 * @deprecated not used - only in makeTree()
	 * @param tree
	 * @param strings
	 * @return the {@link Tree} extended from the input tree by the application of the {@link Effect}s specified as
	 *         strings
	 */
	@Deprecated
	private Tree effects(Tree tree, List<String> strings) {
		for (String s : strings) {
			Effect e = EffectFactory.create(s);
			tree = e.exec(tree, null);
		}
		return tree;
	}

	/**
	 * @param sentence
	 *            a sentence
	 * @param tree
	 *            the complete tree for the sentence
	 * @param unknownWords
	 *            the words for which to induce {@link LexicalAction}s
	 * @return true
	 */
	private boolean learn(List<? extends HasWord> sentence, Tree tree, List<String> unknownWords) {
		ParseState<ContextParserTuple> state = parser.getState();
		for (HasWord w : sentence) {
			if (unknownWords.contains(w.word())) {
				int i = 0;
				int n = state.size();
				//why are we not clearing the parse state before trying the actions induced for w:
				//ParseState<ContextParserTuple> oldState=state.clone();
				//state.clear();
				for (ContextParserTuple oldTuple : state.clone()) {
					System.out.println("OLD TUPLE " + ++i + " OF " + n + " " + oldTuple);
					ArrayList<Action> possibleActions = actions.get(w.word());
					if (possibleActions == null) {
						possibleActions = possibleActions(w.word(), oldTuple.getTree(), tree);
						// actions.put(w.word(), possibleActions);
					}
					if (possibleActions != null) {
						System.out.println("POSS ACTIONS " + possibleActions.size());
						int ia = 0;
						int na = possibleActions.size();
						//
						for (Action action : possibleActions) {
							System.out.println("ACTION " + ++ia + " OF " + na); // + " = " + action);
							ContextParserTuple newTuple = parser.tmpExecAction(oldTuple, action, w.word());
							if ((newTuple != null) && (newTuple.getTree().subsumes(tree))) {
								state.add(newTuple);
								System.out.println("Applied LA " + action.getName() + " to " + oldTuple);
								System.out.println(action);
								System.out.println("New tuple " + newTuple);
							}
						}
					}
					System.out.println("After old tuple state " + state.size());
				}
				//adjust isn't terminating. . . . 
				parser.adjust(state);
				System.out.println("After word " + w + " state " + state.size() + " " + state.complete().size());
			} else {
				parser.parseWord(state, w.word());
				System.out.println("After word " + w + " state " + state.size() + " " + state.complete().size());
			}
		}
		
		for (String word : unknownWords) {
			if (actions.get(word) == null) {
				actions.put(word, new ArrayList<Action>());
			}
			actions.get(word).clear();
		}
		for (ContextParserTuple tuple : state.complete()) {
			System.out.println("Complete tree: " + tuple.getTree());
			if (tuple.getTree().equals(tree)) {
				ArrayList<Action> myActions = tuple.getActions();
				for (Action action : myActions) {
					if (action instanceof LexicalAction) {
						LexicalAction la = (LexicalAction) action;
						if (unknownWords.contains(la.getWord())) {
							System.out.println("Possible solution for " + sentence + ": " + action);
							if (!actions.get(la.getWord()).contains(la)) {
								actions.get(la.getWord()).add(la);
							}
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * @param word
	 *            a word for which to induce an action
	 * @param tree
	 *            the partial tree so far
	 * @param goal
	 *            the goal tree, subsumed by tree
	 * @return the possible set of if-then-else {@link LexicalAction}s
	 */
	private ArrayList<Action> possibleActions(String word, Tree tree, Tree goal) {
		ArrayList<Action> actions = new ArrayList<Action>();
		if (!tree.subsumes(goal)) {
			System.out.println("bad start, no subsumption:\n" + tree + "\n" + goal);
			return null;
		}
		Node pointed = tree.getPointedNode();
		Label[] IF = typeRequirement(pointed);
		if (IF == null) {
			return actions;
		}
		Effect[] ELSE = new Effect[] { new Abort() };
		Set<List<Effect>> guesses = guess(tree, goal, tree.getPointer());
		for (List<Effect> guess : guesses) {
			Effect[] THEN = guess.toArray(new Effect[guess.size()]);
			IfThenElse ite = new IfThenElse(IF, THEN, ELSE);
			actions.add(new LexicalAction(word, ite));
		}
		return actions;
	}

	/**
	 * @param tree
	 * @param goal
	 *            a goal tree which is subsumed by tree
	 * @param address
	 *            the node under consideration (to start with, this should be the pointed node in tree)
	 * @return the set of possible {@link Effect} sequences which can be applied to tree so that it still subsumes goal
	 */

	//this is recursive, creating guesses out of subguesses associated with daughters of the cur node.
	//actions which result will not change anything above the pointed node, or indeed anywhere else on the tree
	//except subtree whose root is the pointed node.
	//An exception I can think of is verbs in Ronnie's system. . . . they add things to 
	//the event subtree, and then come back . . . .
	private Set<List<Effect>> guess(Tree tree, Tree goal, NodeAddress address) 
	{
		//System.out.println("guessing , pointed node address is:"+address);
		HashSet<List<Effect>> guesses = new HashSet<List<Effect>>();
		for (Set<Effect> subset : possibleSubsets(possibleEffects(tree.containsKey(address) ? tree.get(address)
				: new Node(address), goal.get(address)))) {
			guesses.add(new ArrayList<Effect>(subset));
			for (Node dtr : goal.getDaughters(goal.get(address))) {
				ArrayList<Effect> list = new ArrayList<Effect>(subset);
				if (!tree.containsValue(dtr)) {
					list.add(EffectFactory.create(Make.FUNCTOR + "(" + BasicOperator.ARROW_DOWN
							+ dtr.getAddress().toString().charAt(dtr.getAddress().toString().length() - 1) + ")"));
				}
				list.add(EffectFactory.create(Go.FUNCTOR + "(" + BasicOperator.ARROW_DOWN
						+ dtr.getAddress().toString().charAt(dtr.getAddress().toString().length() - 1) + ")"));
				for (List<Effect> subguesses : guess(tree, goal, dtr.getAddress())) {
					// System.out.println("after make " + list + " add " + subguesses);
					ArrayList<Effect> sublist = new ArrayList<Effect>(list);
					sublist.addAll(subguesses);
					guesses.add(sublist);
					// System.out.println("guesses now " + guesses);
				}
			}
		}
		return guesses;
	}
	
	/** Based on the guess method, but:
	 *  Constraints on hypothesised actions:
	 * 	(1) construct actions which unify trees bottom up rather than top down, and functor (right) daughters first
	 *  (2) no formula or type decorations on non-terminal nodes (filtering done by possibleEffects)
	 *  
	 *  Moreover, there seems to have been a mistake in guess, in not concatenating lists created for one daughter
	 *  with those created for another. Verbs will not be covered this way . . . 
	 * @param context
	 * @param goal
	 * @param startAddress
	 * @return
	 */
	
	
	private Set<List<Effect>> hypothesise(Tree tree, Tree goal, NodeAddress address)
	{
		//Tree tree=context.getTree();
		HashSet<List<Effect>> guesses = new HashSet<List<Effect>>();
		HashSet<List<Effect>> localGuesses = new HashSet<List<Effect>>();
		HashSet<List<Effect>> llGuesses=new HashSet<List<Effect>>();
		//first get set of actions for development of current node
		Set<Effect> possibleLocalEffects=possibleEffects(tree, goal, address);
		Set<Set<Effect>> possibleSubsets=possibleSubsets(possibleLocalEffects);
		//System.out.println(possibleSubsets);
		for (Set<Effect> subset : possibleSubsets) {
			localGuesses.add(new ArrayList<Effect>(subset));
			guesses.add(new ArrayList<Effect>(subset));
		}
		
		//then for each daughter subtree get set of actions for their respective further developments 
		//recursively, calling the same method.
		
		ArrayList<Set<List<Effect>>> allDtrsActions=new ArrayList<Set<List<Effect>>>();
		
		ArrayList<Node> dtrs=goal.getDaughters(goal.get(address), "10L*U");
		
		for (Node dtr : dtrs) {
			Set<List<Effect>> curDtrRes=new HashSet<List<Effect>>();
			curDtrRes=hypothesise(tree, goal, dtr.getAddress());			
			allDtrsActions.add(curDtrRes);
			
		}
		//Now combine these in all possible ways into single lists
		int i=0;
		for (Set<List<Effect>> curDtrActions: allDtrsActions)
		{
			
			Node dtr=dtrs.get(i);
			i++;
			llGuesses.addAll(localGuesses);
			localGuesses.clear();
			for (List<Effect> current: llGuesses)
			{				
				for (List<Effect> curDtrAction: curDtrActions)
				{
					
					List<Effect> curList=new ArrayList<Effect>(current);
					if (!tree.containsValue(dtr)) {
						curList.add(EffectFactory.create(Make.FUNCTOR + "(" + BasicOperator.ARROW_DOWN
								+ dtr.getAddress().toString().charAt(dtr.getAddress().toString().length() - 1) + ")"));
					}
					curList.add(EffectFactory.create(Go.FUNCTOR + "(" + BasicOperator.ARROW_DOWN
							+ dtr.getAddress().toString().charAt(dtr.getAddress().toString().length() - 1) + ")"));
					curList.addAll(curDtrAction);
					curList.add(EffectFactory.create(Go.FUNCTOR+"("+BasicOperator.UP+")"));
					guesses.add(curList);
					localGuesses.add(curList);
				}
			}
			
		}
		return guesses;
		
		
	}
	
	
	
	
	
	
	
	
	/**
	 * @param node
	 * @return the type requirement label at the node if it exists, null otherwise
	 */
	private Label[] typeRequirement(Node node) {
		for (Label label : node) {
			if (label instanceof Requirement) {
				if (((Requirement) label).getLabel() instanceof TypeLabel) {
					return new Label[] { label };
				}
			}
		}
		return null;
	}
	
	
	/*lots of uninformed hypotheses:
	 * 
	 * (1) formulas on mother but not daughters
	 * (2) types requirements . . . 
	 * 
	 * principled way of ruling out hypotheses . . . should check tree dynamics . . . .
	 * 
	 * 
	 */
	
	/**
	 * @param effects
	 *            a set of {@link Effect}s
	 * @return the set of all possible subsets of the input set (including the empty set and the full input set)
	 */
	private Set<Set<Effect>> possibleSubsets(Set<Effect> effects) {
		HashSet<Set<Effect>> subsets = new HashSet<Set<Effect>>();
		subsets.add(new HashSet<Effect>());
		boolean succeeded = true;
		while (succeeded) {
			succeeded = addSubset(effects, subsets);
		}
		return subsets;
	}

	/**
	 * A VERY INEFFICIENT way of adding a new subset
	 * TODO SHOULD IMPROVE. ALGO BELOW, but need to integrate.
	 * @param effects
	 * @param subsets
	 * @return true if adding some member of effects to some member of subsets resulted in a set which was not already a
	 *         member of subsets (in which case it gets added); false otherwise
	 */
	private boolean addSubset(Set<Effect> effects, Set<Set<Effect>> subsets) {
		for (Effect effect : effects) {
			for (Set<Effect> subset : subsets) {
				HashSet<Effect> s = new HashSet<Effect>(subset);
				if (sensibleAddition(effect, s)) {
					s.add(effect);
					if (!subsets.contains(s)) {
						subsets.add(s);
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * @param e
	 * @param s
	 * @return false if the {@link Effect} e makes no sense when combined with the set s, true otherwise
	 */
	private boolean sensibleAddition(Effect e, Set<Effect> s) {
		if (s.contains(e)) {
			return false;
		}
		if (e instanceof Put) {
			Label eL = ((Put) e).getLabel();
			// put(fo(F)) is not sensible if not accompanied by put(ty(T))
			if (eL instanceof FormulaLabel) {
				boolean foundType = false;
				for (Effect e1 : s) {
					if ((e1 instanceof Put) && (((Put) e1).getLabel() instanceof TypeLabel)) {
						foundType = true;
					}
				}
				if (!foundType) {
					return false;
				}
			}
			// put(ty(_)) or put(?ty(_)) is not sensible if accompanied by another put(ty(_)) or put(?ty(_))
			if ((eL instanceof TypeLabel)
					|| ((eL instanceof Requirement) && (((Requirement) eL).getLabel() instanceof TypeLabel))) {
				for (Effect e1 : s) {
					if (e1 instanceof Put) {
						Label e1L = ((Put) e1).getLabel();
						if ((e1L instanceof TypeLabel)
								|| ((e1L instanceof Requirement) && (((Requirement) e1L).getLabel() instanceof TypeLabel))) {
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * 
	 * @param node
	 * @param goalNode
	 *            a {@link Node} subsumed by node
	 * @return the set of possible {@link Effect}s which could be applied to node so that it still subsumes goal. This
	 *         will include put(x) for each label x in goal which is not already in node; and put(?ty(x)) for each ty(x)
	 *         label in goal which is not already in node
	 */
	
	private Set<Effect> possibleEffects(Node node, Node goal) {
		
		HashSet<Effect> effects = new HashSet<Effect>();
		if (!node.subsumes(goal)) {
			System.out.println("bad start, no subsumption: " + node + " " + goal);
			return null;
		}
		for (Label label : goal) {
			if (!node.contains(label)) {
				effects.add(EffectFactory.create(Put.FUNCTOR + "(" + label + ")"));
				if (label instanceof TypeLabel) {
					Requirement req = new Requirement(label);
					if (!node.contains(req)) {
						effects.add(EffectFactory.create(Put.FUNCTOR + "(" + req + ")"));
					}
				}
			}
		}
		return effects;
	}
	/**
	 * This is based on possibleEffects as before, but now constrained such that there aren't any formula or type decorations on non-terminal nodes 
	 * and only on functor node if argument sister exists
	 * @param tree
	 * @param goal
	 * @param whichNode
	 * @return
	 */
	private Set<Effect> possibleEffects(Tree tree, Tree goal, NodeAddress whichNode) {
		Node node=tree.containsKey(whichNode) ? tree.get(whichNode)	: new Node(whichNode);
		Node goalNode=goal.get(whichNode);
		//System.out.println(node);
		//System.out.println(goalNode);
		HashSet<Effect> effects = new HashSet<Effect>();
		if (!node.subsumes(goalNode)) {
			System.out.println("bad start, no subsumption: " + node + " " + goalNode);
			return null;
		}
		for (Label label : goalNode) {
			
			if (!node.contains(label)) {
				
					
				if (label instanceof TypeLabel) {
					Requirement req = new Requirement(label);
					if (!node.contains(req)) {
						effects.add(EffectFactory.create(Put.FUNCTOR + "(" + req + ")"));
					}
					//if the node is terminal, ok to add type decoration
					if (!(goal.containsKey(whichNode.down0())||goal.containsKey(whichNode.down1())))
					{
						effects.add(EffectFactory.create(Put.FUNCTOR + "(" + label + ")"));
					}
				}
				else if (label instanceof FormulaLabel)
				{
					//if node is terminal, ok to add formula decoration
					if (!(goal.containsKey(whichNode.down0())||goal.containsKey(whichNode.down1())))
					{
						effects.add(EffectFactory.create(Put.FUNCTOR + "(" + label + ")"));
					}
				}
				else
				{			
					effects.add(EffectFactory.create(Put.FUNCTOR + "(" + label + ")"));
				}
			}
		}
		return effects;
	}
	
	public static <X extends Object> Set<X> subtract(Set<X> set1, Set<X> set2)
	{
		Iterator<X> i=set1.iterator();
		Set<X> result=new HashSet<X>();
		while(i.hasNext())
		{
			X next=i.next();
			if(!set2.contains(next)) result.add(next);
		}
		return result;
	}
	/**
	 * Constructs subsets of set, of size <size. This is recursively defined, in particular, subsets of size n, are
	 * constructed from subsets of size n-1. Subsets of size 1 (the base case), are just the enumeration of the members of set. 
	 * @param <X>
	 * @param set
	 * @param size
	 * @return
	 */
	public static <X extends Object> Set<Set<X>> subsetsOfSize(Set<X> set, int size)
	{
		if (size==1)
		{
			Set<Set<X>> result=new HashSet<Set<X>>();
			Iterator<X> i=set.iterator();
			while(i.hasNext())
			{
				X next=i.next();
				Set<X> cur=new HashSet<X>();
				cur.add(next);
				result.add(cur);
				
			}
			result.add(new HashSet());//empty set
			return result;
			
		}
		else
		{

			Set<Set<X>> result=new HashSet<Set<X>>();
			Set<Set<X>> resultNMinus=subsetsOfSize(set, size-1);
			
			
			Iterator<Set<X>> i=resultNMinus.iterator();
				
			while(i.hasNext())
			{
				Set<X> nextSet=i.next();
				Set<X> subtracted=subtract(set, nextSet);
				Iterator<X> j=subtracted.iterator();
				while(j.hasNext())
				{
					X next=j.next();
					Set<X> newNext=new HashSet<X>(nextSet);
					newNext.add(next);
					result.add(newNext);
					
				}
			}
			result.addAll(resultNMinus);
			return result;
	
			
		}
		
	}
	/**uses the subsetsOfSize method to construct all subsets of set . . . 
	 * 
	 * @param <X>
	 * @param set
	 * @return set of all subsets of set
	 */
	public static <X extends Object> Set<Set<X>> subsets(Set<X> set)
	{
		return subsetsOfSize(set, set.size());
		
	}
	
	public static void main(String[] args) {
		
		WordLearner wl=new WordLearner("resource/2009-english-test-induction");
		wl.parser.init();
		String[] sent1 = "john likes mary".split("\\s+");
		String[] sent2 = "john".split("\\s+");
		wl.parser.parseWords(Arrays.asList(sent1));
		Tree complete=wl.parser.getBestParse();
		wl.parser.init();
		wl.parser.parseWords(Arrays.asList(sent2));
		Tree incomplete=wl.parser.getBestParse();
		//System.out.println(wl.possibleEffects(incomplete, complete, incomplete.getPointer()));
		System.out.println("To Tree: "+complete);
		System.out.println("From Tree: "+incomplete);
		Set<List<Effect>> hyp=wl.hypothesise(incomplete, complete, incomplete.getPointer());
		
		
		System.out.println("Number of hypotheses:"+hyp.size());
		int i=0;
		for(List<Effect> cur:hyp)
		{
			String s=++i+" ";
			System.out.println(s + cur);
		}
		System.out.println("John likes Mary: "+complete);
		System.out.println("John: "+incomplete);
		
	}

}

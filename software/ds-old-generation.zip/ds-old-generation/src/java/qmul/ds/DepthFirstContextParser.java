package qmul.ds;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import qmul.ds.action.Action;

/**
 * 
 * @author arash
 *
 */

public class DepthFirstContextParser extends DepthFirstRecursiveParser<ContextParserTuple>{
	
	public DepthFirstContextParser(File resourceDir) {
		super(resourceDir);
		
	}
	public DepthFirstContextParser(String resourceDir) {
		super(resourceDir);
		
	}

	@Override
	protected ContextParserTuple execAction(ContextParserTuple tuple, Action action, String word) {
		return tuple.execAction(action, word);
		
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.Parser#getAxiom()
	 */
	@Override
	protected ContextParserTuple getAxiom() {
		return new ContextParserTuple();
	}
	
	public static void main(String a[])
	{
		DepthFirstContextParser p=new DepthFirstContextParser("resource/2009-english");
		
		String sent="john likes mary who arrested bill .";
		String[] sentW=sent.split("\\s");
		List<String> sentL=Arrays.asList(sentW);
		
		ContextParserTuple result=p.bestParse(sentL);
		System.out.println(result);
		
	}
}
package qmul.ds;

import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import qmul.ds.action.Action;
import qmul.ds.tree.Tree;

public class DAGParserTuple extends ParserTuple {
	
	private static Logger logger = Logger.getLogger(DAGParserTuple.class);
	
	protected String word;//will be null if action is computational
	protected Action actionLeadingToThis;//null if no parent
	protected DAGParserTuple parent;
	//protected TreeSet<DAGParserTuple> children;
	protected TreeMap<DAGParserTuple, Boolean> children; //keeps track of children and whether they've been explored
	
	public DAGParserTuple(Tree t)
	{
		super(t);
		this.actionLeadingToThis=null;		
		this.parent=null;
		this.children=new TreeMap<DAGParserTuple, Boolean>();
		
	}
	
	public DAGParserTuple(DAGParserTuple t)
	{
		this.tree=new Tree(t.tree);
		this.actionLeadingToThis=t.actionLeadingToThis;
		if (t.parent!=null) this.parent=new DAGParserTuple(t.parent);
		this.children=new TreeMap<DAGParserTuple, Boolean>();
		for(DAGParserTuple child: t.children.keySet())
		{
			this.children.put(new DAGParserTuple(child), t.children.get(child));
		}
		
	}
	
	public DAGParserTuple(Tree t, DAGParserTuple parent, Action action)
	{
		super(t);
		this.parent=parent;
		this.actionLeadingToThis=action;
		this.children=new TreeMap<DAGParserTuple, Boolean>();
	}
	
	public DAGParserTuple(Tree t, DAGParserTuple parent, Action action, String word)
	{
		super(t);
		this.parent=parent;
		this.actionLeadingToThis=action;
		this.word=word;
		this.children=new TreeMap<DAGParserTuple, Boolean>();
		
		
	}
	
	public DAGParserTuple()
	{
		super();
		this.actionLeadingToThis=null;
		this.parent=null;
		this.children=new TreeMap<DAGParserTuple, Boolean>();
	}
	
	
	public DAGParserTuple getParent()
	{
		return this.parent;
	}
	
	public DAGParserTuple execAction(Action action, String word) {
		
		Tree result = action.exec(tree.clone(), this);
		if (result == null) return null; 
		
		DAGParserTuple child=new DAGParserTuple(result, this, action, word);
		this.children.put(child, false);
		return child;
	}
	/**
	 * marks seenChild as seen, and marks every child (sister) following seenChild as unseen.
	 * Normally this doesn't need to be done since all the following children will be unseen 
	 * anyway, but when we've previously explored these other following children, but have 
	 * reset the parser to its last state, we need to do this.
	 * 
	 * @param seenChild
	 */
	public void markChildAsSeen(DAGParserTuple seenChild)
	{
		boolean done=false;
		for(DAGParserTuple child:this.children.keySet())
		{
			if (done)
			{
				this.children.put(child, false);
				continue;
			}
			if (child==seenChild)
			{
			
				this.children.put(child, true);
				done=true;
			}
			
		}
		
	}
	/*
	public void removeFirstChild()
	{
		this.children.remove(children.first());
	}
	*/
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
		return new DAGParserTuple(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ParserTuple other) {
		//Lexical Tuples - output of lexical actions - take precedence (in search) so are 'less than' Computational tuples. 
		if (other instanceof DAGParserTuple)
		{
			DAGParserTuple DAGOther=(DAGParserTuple)other;
			if (DAGOther.word==null)
			{
				if (word!=null) return -1;
			}
			else if (word==null) return 1;
		}
		return super.compareTo(other);
		

		
	}

	

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// logger.debug("using equals in parsertuple");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DAGParserTuple other = (DAGParserTuple) obj;
		if (tree == null) {
			if (other.tree != null)
				return false;
		} else if (!tree.equals(other.tree))
			return false;
		
		
		return parent==other.parent && actionLeadingToThis==other.actionLeadingToThis;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return tree.toString();
	}

	public boolean hasMoreChildren() {
		for(DAGParserTuple child:this.children.keySet())
		{
			if (!children.get(child)) return true; 
		}
		return false;
	}
	

	
	
	
	

}

/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import qmul.ds.action.Grammar;
import qmul.ds.action.Lexicon;
import qmul.ds.formula.TTRFormula;
import qmul.ds.gui.GeneratorGUI;
import qmul.ds.tree.Tree;

/**
 * A simple {@link Generator} with plain vanilla {@link ParserTuple}s
 * 
 * @author mpurver
 */
public class SimpleGenerator extends Generator<ParserTuple> {

	private static Logger logger = Logger.getLogger(SimpleGenerator.class);

	public SimpleGenerator(Parser<ParserTuple> parser) {
		super(parser);
	}

	public SimpleGenerator(Lexicon lexicon, Grammar grammar) {
		super(lexicon, grammar);
	}

	public SimpleGenerator(File resourceDir) {
		super(resourceDir);
	}

	public SimpleGenerator(String resourceDirNameOrURL) {
		super(resourceDirNameOrURL);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see qmul.ds.Generator#getParser(qmul.ds.action.Lexicon, qmul.ds.action.Grammar)
	 */
	@Override
	public Parser<ParserTuple> getParser(Lexicon lexicon, Grammar grammar) {
		return new SimpleParser(lexicon, grammar);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		
		String resource = "resource/2010-jindigo";
		SimpleParser sp = new SimpleParser(resource);
		//DepthFirstContextParser sp = new DepthFirstContextParser(resource);
		sp.init();
		// String[] sent = "john".split("\\s+");
		String[] sent = "i".split("\\s+");
		sp.parseWords(Arrays.asList(sent));
		Tree t = sp.getBestParse();
		t.compileMaximalSemantics();
		if (t.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		
		TTRFormula goalttr1 = (TTRFormula) t.getRootNode().getFormula();
		sp.init();
		String[] sent2 = "i go".split("\\s+");
		sp.parseWords(Arrays.asList(sent2));
		Tree t2 = sp.getBestParse();
		t2.compileMaximalSemantics();
		if (t2.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr2 = (TTRFormula) t2.getRootNode().getFormula();
	

		sp.init();
		String[] sent3 = "i go to".split("\\s+");
		sp.parseWords(Arrays.asList(sent3));
		Tree t3 = sp.getBestParse();
		//if (t3.getRootNode().getFormula()==null) {  //should really check every time.. still need to do this
		t3.compileMaximalSemantics();
		//}
		if (t3.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr3 = (TTRFormula) t3.getRootNode().getFormula();
		
		
		sp.init();
		String[] sent4 = "i like Paris".split("\\s+");
		sp.parseWords(Arrays.asList(sent4));
		Tree t4 = sp.getBestParse();
		if (t4.getRootNode().getFormula()==null) {  //should really check every time.. still need to do this
		t4.compileMaximalSemantics();}
		if (t4.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr4 = (TTRFormula) t4.getRootNode().getFormula();
		
		
		sp.init();
		String[] sent5 = "i go to London".split("\\s+");
		sp.parseWords(Arrays.asList(sent5));
		Tree t5 = sp.getBestParse();
		if (t5.getRootNode().getFormula()==null) {  //should really check every time.. still need to do this
		t5.compileMaximalSemantics();}
		if (t5.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr5 = (TTRFormula) t5.getRootNode().getFormula();
		
		sp.init();
		String[] sent6 = "i go to Paris from".split("\\s+");
		sp.parseWords(Arrays.asList(sent6));
		Tree t6 = sp.getBestParse();
		//if (t6.getRootNode().getFormula()==null) {  //should really check every time.. still need to do this
		t6.compileMaximalSemantics();
		//}
		if (t6.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr6 = (TTRFormula) t6.getRootNode().getFormula();
		
		sp.init();
		String[] sent7 = "i go to Paris from London".split("\\s+");
		sp.parseWords(Arrays.asList(sent7));
		Tree t7 = sp.getBestParse();
		if (t7.getRootNode().getFormula()==null) {  //should really check every time.. still need to do this
		t7.compileMaximalSemantics();}
		if (t7.getRootNode().getFormula() instanceof TTRFormula) {
			
		}else {
			logger.error("NOT TTR FORMULA!");
			System.exit(0);
		}
		TTRFormula goalttr7 = (TTRFormula) t7.getRootNode().getFormula();
		
		
		
		SimpleGenerator sg = new SimpleGenerator(sp);
		sg.init();
		
		ArrayList<TTRFormula> goals = new ArrayList<TTRFormula>();
		goals.add(goalttr1);
		goals.add(goalttr2);
		goals.add(goalttr3);
		goals.add(goalttr4);
		goals.add(goalttr5);
		goals.add(goalttr6);
		goals.add(goalttr7);
		
		sg.setGenGui(new GeneratorGUI(sg,goals));
		
		
		/*boolean r = sg.generate(goalttr);
		if (r) {
			logger.info("best string: " + cg.getBestString());
		}*/
		//boolean r = cg.generate(tree)
		
		
		
		/*File resource = new File(args[0]);
		SimpleParser sp = new SimpleParser(resource);
		sp.init();
		// String[] sent = "john".split("\\s+");
		String[] sent = "john likes mary".split("\\s+");
		sp.parseWords(Arrays.asList(sent));
		Tree t = sp.getBestParse();
		SimpleGenerator sg = new SimpleGenerator(sp);
		sg.init();
		boolean r = sg.generate(t);
		if (r) {
			logger.info("best string: " + sg.getBestString());
		}*/
	}

}

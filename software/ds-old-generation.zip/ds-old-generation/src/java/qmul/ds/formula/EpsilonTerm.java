/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.formula;

public class EpsilonTerm extends Formula {

	private Formula orderedPair;
	private String functor;

	public EpsilonTerm(String functor, Formula pair) {
		this.orderedPair = pair;
		this.functor = functor;
	}

	public String toString() {
		return functor + ", " + orderedPair;
	}

	public Formula conjoin(Formula f) {
		if (!(f instanceof EpsilonTerm))
			throw new IllegalArgumentException("Cannot conjoin Epsilon term with formula of another type.");

		EpsilonTerm ef = (EpsilonTerm) f;
		if (!ef.functor.equals(functor))
			throw new IllegalArgumentException("Cannot conjoin Epsilon term with one with a different functor.");

		return new EpsilonTerm(functor, this.orderedPair.conjoin(ef.orderedPair));
	}

}

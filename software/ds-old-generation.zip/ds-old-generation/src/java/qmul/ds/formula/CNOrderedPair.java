/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.formula;

public class CNOrderedPair extends Formula {

	private Variable variable;

	private Formula f;

	public Variable getVariable() {
		return this.variable;
	}

	public CNOrderedPair(Variable v, Formula f) {

		this.variable = v;
		this.f = f;
	}

	public String toString() {
		return this.variable + ", " + f;
	}

	public Formula conjoin(Formula fo) {
		if (fo instanceof CNOrderedPair) {
			// throw new
			// IllegalArgumentException("Cannot conjoin a cn ordered pair with another formula type\n"+fo+":"+fo.getClass()+"\nwith\n"+this+":"+this.getClass());
			CNOrderedPair cnop = (CNOrderedPair) fo;
			CNOrderedPair foR = cnop.renameVariable(this.variable);
			return new CNOrderedPair(this.variable, this.f.conjoin(foR.f));
		} else {
			return new CNOrderedPair(this.variable, this.f.conjoin(fo));
		}

	}

	public CNOrderedPair renameVariable(Variable v) {
		Formula fo = Formula.create(f.toString().replaceAll(variable.toString(), v.toString()));
		return new CNOrderedPair(v, fo);
	}

	public CNOrderedPair renameVariable(String v) {
		Formula fo = Formula.create(f.toString().replaceAll(variable.toString(), v));
		return new CNOrderedPair(new Variable(v), fo);
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((f == null) ? 0 : f.hashCode());
		result = prime * result + ((variable == null) ? 0 : variable.hashCode());
		return result;
	}

}

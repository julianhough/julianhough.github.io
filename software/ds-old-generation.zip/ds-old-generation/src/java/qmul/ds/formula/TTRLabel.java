package qmul.ds.formula;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A label in a TTR record type, as implemented in {@link TTRFormula}
 * 
 * @author mpurver
 */
public class TTRLabel extends BasicFormula {

	public final static Pattern LABEL_PATTERN = Pattern.compile("(\\w+?)(\\d*)");

	public TTRLabel(String formula) {
		super(formula);
	}

	/**
	 * @return the next label with the same basic root e.g. x -> x1, x42 -> x43 etc
	 */
	public TTRLabel next() {
		Matcher m = LABEL_PATTERN.matcher(toString());
		if (!m.matches()) {
			throw new RuntimeException("strange TTRLabel " + this);
		}
		int myNum = (m.group(2).isEmpty() ? 0 : Integer.parseInt(m.group(2)));
		return new TTRLabel(m.group(1) + ++myNum);
	}
	
	public boolean TTRtypeMatch(TTRLabel otherLabel){
			
		Matcher m = LABEL_PATTERN.matcher(toString());
		if (!m.matches()) {
			throw new RuntimeException("strange TTRLabel " + this);
		}
		
		Matcher m1 = LABEL_PATTERN.matcher(otherLabel.toString());
		if (!m1.matches()) {
			throw new RuntimeException("strange TTRLabel " + otherLabel);
		}
		
		return (m.group(1).equals(m1.group(1)) ? true : false);
		
	}
	
	public static void main(String args[]) {
		
		TTRLabel thisone = new TTRLabel("eps1");
		TTRLabel otherone = new TTRLabel("eps2");
		
		System.out.println(thisone.TTRtypeMatch(otherone));
		
		
	}

}

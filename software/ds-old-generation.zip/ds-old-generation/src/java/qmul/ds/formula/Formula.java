/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.formula;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import qmul.ds.action.boundvariable.BoundFormulaVariable;
import qmul.ds.action.meta.MetaFormula;
import qmul.ds.tree.label.LabelFactory;
import qmul.ds.type.BasicType;
import qmul.ds.type.ConstructedType;
import qmul.ds.type.Type;

/**
 * Just a placeholder for now
 * 
 * @author mpurver
 */
public class Formula {

	protected static Logger logger = Logger.getLogger(Formula.class);

	private static final String EPSILON_FUNCTOR = "eps";
	private static final String UNICODE_EPSILON_FUNCTOR = "\u03B5"; // epsilon;
	// also
	// 03F5,
	// 025B,
	// 1D6C6
	private static final String TAU_FUNCTOR = "tau";
	private static final String UNICODE_TAU_FUNCTOR = "\u03C4"; // tau; also
	// 1D6D5
	private static final String IOTA_FUNCTOR = "iota";
	private static final String UNICODE_IOTA_FUNCTOR = "\u0269"; // iota; also
	// 03B9,
	// 1D6CA
	private static final String ETA_FUNCTOR = "eta";
	private static final String UNICODE_ETA_FUNCTOR = "\u03B7"; // eta; also
	// 1D6C8
	private static final String EPSILON_FUNCTORS = "(eps|tau|iota)";
	public static final String CONJUNCTION_OPERATOR = "&";
	public static final String UNICODE_CONJUNCTION_OPERATOR = "\u2227"; // logica
	// and;
	// also
	// 22C0
	public static final String UNICODE_SUBSET_OPERATOR = "\u2286";
	public static final String UNICODE_OVERLAP_OPERATOR = "\u229D";
	public static final String OVERLAP_OPERATOR = "overlap";
	public static final String SUBSET_OPERATOR = "subset";

	private static final Pattern EPSILON_VARIABLE_PATTERN = Pattern.compile("[a-zA-Z][0-9]*");
	private static final Pattern LAMBDA_VARIABLE_PATTERN = Pattern.compile("[A-Z]");
	private static final Pattern METAVARIABLE_PATTERN = Pattern.compile("[A-C[R-R]]");
	private static final Pattern LAMBDA_ABSTRACT_PATTERN = Pattern.compile("(" + LAMBDA_VARIABLE_PATTERN + ")"
			+ Pattern.quote(LambdaAbstract.LAMBDA_FUNCTOR) + "(.*)");
	private static final Pattern TTR_PATTERN = Pattern.compile(Pattern.quote(TTRFormula.TTR_OPEN) + "(?:"
			+ Pattern.quote(TTRFormula.TTR_HEAD) + ")?(\\w+)\\s*" + Pattern.quote(TTRFormula.TTR_LABEL_SEPARATOR)
			+ "\\s*(.*)" + Pattern.quote(TTRFormula.TTR_CLOSE));
	private static final Pattern TTR_DUAL_PATTERN = Pattern.compile(Pattern.quote(TTRFormula.TTR_OPEN) + "(?:"
			+ Pattern.quote(TTRFormula.TTR_HEAD) + ")?(\\w+)\\s*" + Pattern.quote(TTRFormula.TTR_LABEL_SEPARATOR)
			+ "\\s*(.*)\\s*" + Pattern.quote(TTRFormula.TTR_FIELD_SEPARATOR) + "\\s*(?:"
			+ Pattern.quote(TTRFormula.TTR_HEAD) + ")?(\\w+)\\s*" + Pattern.quote(TTRFormula.TTR_LABEL_SEPARATOR)
			+ "\\s*(.*)" + Pattern.quote(TTRFormula.TTR_CLOSE));
	private static final Pattern FRESH_VARIABLE_PATTERN = Pattern.compile("VAR");
	private static final Pattern FRESH_EVENT_VARIABLE_PATTERN = Pattern.compile("EVENTVAR");
	private static final Pattern FRESH_PROPOSITION_VARIABLE_PATTERN = Pattern.compile("PROPVAR");
	private static final Pattern CN_ORDERED_PAIR_PATTERN = Pattern.compile("\\s*(" + EPSILON_VARIABLE_PATTERN
			+ ")\\s*,\\s*(.+)\\s*");
	protected static final Pattern EPSILON_TERM_PATTERN = Pattern.compile(EPSILON_FUNCTORS + "\\s*,(.+)");
	public static final Pattern VAR_PATTERN = Pattern.compile("[a-z][0-9]*");
	public final static String FRESHPUT_METAVARIABLE_PATTERN = "[S-U]";

	/**
	 * @param string
	 *            a formula spec as used in lexicon specs e.g. john, X^Y^like(X,Y)
	 * @return a {@link BasicFormula} for atomic strings, {@link LambdaAbstract} otherwise
	 */
	public static Formula create(String string) {
		// lexical/computational action rule metavariable (as in e.g. IF fo(X)
		// THEN ...)
		if (string.matches("^" + LabelFactory.METAVARIABLE_PATTERN + "$")) {
			return MetaFormula.get(string);
		}
		if (string.matches("^" + FRESHPUT_METAVARIABLE_PATTERN + "$")) {
			return MetaFormula.get(string);
		}
		// formula bound variable as used in e.g. existential labels, e.g.
		// Ex.fo(x)
		if (string.matches("^" + LabelFactory.VAR_PATTERN + "$")) {
			return new BoundFormulaVariable(string);
		}
		// formula metavariable (as in e.g. put(fo(A)))
		if (string.matches("^" + METAVARIABLE_PATTERN + "$")) {
			return FormulaMetavariable.get(string);
		}
		// fresh (bound) formula variable of type es
		if (string.matches("^" + FRESH_EVENT_VARIABLE_PATTERN + "$")) {
			return Variable.getFreshEventVariable();
		}
		// fresh (bound) formula variable of type e
		if (string.matches("^" + FRESH_VARIABLE_PATTERN + "$")) {
			return Variable.getFreshEntityVariable();
		}
		// fresh (bound) formula variable of type t
		if (string.matches("^" + FRESH_PROPOSITION_VARIABLE_PATTERN + "$")) {
			return Variable.getFreshPropositionVariable();
		}
		// TTR formula
		Matcher m = TTR_DUAL_PATTERN.matcher(string);
		logger.trace("ttr dual ch " + string + " = " + TTR_DUAL_PATTERN);
		if (m.matches()) {
			TTRFormula ttr = new TTRFormula(m.group(1), m.group(2));
			logger.trace("ttr dual 1 " + ttr);
			TTRFormula ttr2 = new TTRFormula(m.group(3), m.group(4));
			logger.trace("ttr dual 2 " + ttr2);
			ttr.setHead(ttr.add(ttr2));
			logger.trace("ttr dual " + ttr);
			return ttr;
		}
		m = TTR_PATTERN.matcher(string);
		if (m.matches()) {
			return new TTRFormula(m.group(1), m.group(2));
		}

		// otherwise a proper Formula
		m = LAMBDA_ABSTRACT_PATTERN.matcher(string);
		if (m.matches()) {
			return new LambdaAbstract(m.group(1), create(m.group(2)));
		} else {
			// epsilon term
			m = EPSILON_TERM_PATTERN.matcher(string);
			if (m.matches()) {
				return new EpsilonTerm(m.group(1), create(m.group(2)));
			}
			// cn ordered pair
			m = CN_ORDERED_PAIR_PATTERN.matcher(string);
			if (m.matches()) {
				return new CNOrderedPair(new Variable(m.group(1)), create(m.group(2)));
			}
			m = VAR_PATTERN.matcher(string);
			if (m.matches())
				return new Variable(string);

			return new BasicFormula(string);
		}
	}

	/**
	 * @param f1
	 * @param f2
	 * @return a new {@link Formula} resulting from substituting sub-formula f1 by f2 in this {@link Formula}. Currently
	 *         works by string replacement ...
	 */
	public Formula substitute(Formula f1, Formula f2) {
		return Formula.create(toString().replaceAll("\\b" + Pattern.quote(f1.toString()) + "\\b", f2.toString()));
	}

	/**
	 * @param f1
	 * @param f2
	 * @return a new {@link Formula} resulting from substituting sub-formula f1 by f2 in this {@link Formula}. Currently
	 *         works by string replacement ...
	 */
	public Formula substitute(String f1, Formula f2) {
		if (f1==null || f2==null)
		{
			logger.error("null string or formula when calling Formula substitution");
			logger.error("Formula "+ f2);
			logger.error("String" + f1);
		}
		return Formula.create(toString().replaceAll("\\b" + Pattern.quote(f1) + "\\b", f2.toString()));
	}

	public Formula substitute(String f1, String f2) {
		return Formula.create(toString().replaceAll("\\b" + Pattern.quote(f1) + "\\b", f2));
	}

	/**
	 * @param f
	 * @return a new {@link Formula} which is the conjunction of this {@link Formula} with f
	 */
	public Formula conjoin(Formula f) {
		if (f instanceof LambdaAbstract) {
			LambdaAbstract f1 = (LambdaAbstract) f;
			return f1.conjoin(this);

		}
		return Formula.create(toString() + CONJUNCTION_OPERATOR + f.toString());
	}

	/**
	 * @return the string with special characters replaced by Unicode versions
	 */
	public String toUnicodeString() {
		String s = toString();
		s = s.replaceAll(EPSILON_FUNCTOR, UNICODE_EPSILON_FUNCTOR);
		s = s.replaceAll(TAU_FUNCTOR, UNICODE_TAU_FUNCTOR);
		s = s.replaceAll(IOTA_FUNCTOR, UNICODE_IOTA_FUNCTOR);
		s = s.replaceAll(ETA_FUNCTOR, UNICODE_ETA_FUNCTOR);
		s = s.replaceAll(CONJUNCTION_OPERATOR, UNICODE_CONJUNCTION_OPERATOR);
		s = s.replaceAll(Formula.SUBSET_OPERATOR, UNICODE_SUBSET_OPERATOR);
		s = s.replaceAll(Formula.OVERLAP_OPERATOR, UNICODE_OVERLAP_OPERATOR);

		return s;
	}

	/**
	 * @return an instantiated version of this {@link Formula}, with all meta-elements replaced by their values. By
	 *         default, just return this {@link Formula} unchanged. This will be overridden by {@link MetaFormula}e and
	 *         the like
	 */
	public Formula instantiate() {
		return this;
	}
	
	/*
	 * @return a lambda term or underspecified formula for a given type
	 * should this be a separate method for TTR or not?
	 */
	public static Formula underspecified(Type type, boolean ttr) {
		Vector<String> variablePool = new Vector<String>(Arrays.asList("X", "Y" ,"Z", "W", "V"));
		
		Formula f = ttr ? new TTRFormula("LAMBDA", "null") : create("null");
			//if not basic type then needs to replace predicates 
			while (!(type instanceof BasicType)) {
					
					if (!ttr) {
						try {
						f = new LambdaAbstract(variablePool.get(0),create(f.toString()+"(" + variablePool.get(0) + ")"));
						variablePool.remove(0);}
						catch (Exception e) {
							f = new LambdaAbstract("U",create(f.toString()+"(" + "U" + ")"));
							logger.warn("EMPTY VARIABLE POOL!");
						}
						type = ((ConstructedType)type).getTo();
					} else {
						
						
						
					}
			
			}
		
		if (!ttr) {
			f.substitute("LAMBDA", "SOMETHING");
		} else {
			((TTRFormula) f).getRecord().remove("LAMBDA");
			
		}
		
		
		return f;
	}

	public static void main(String a[]) {
		//Formula f = Formula.create("Y^Y, (Y overlap R & R=now)");
		//Formula f1 = Formula.create("Y^Y, (Y overlap R & R=now)");
		//logger.debug(f + " Hashcode:" + f.hashCode());
		//logger.debug(f1 + " Hashcode:" + f.hashCode());
		Type e = Type.create("e");
		Type t = Type.create("t");
		Type et = Type.create(e,t);
		Type eet = Type.create(e,et);
		Type eeet = Type.create(e,eet);
		Formula f = underspecified(e, false);
		Formula f1 = underspecified(et, false);
		Formula f2 = underspecified(eet, false);
		Formula f3 = underspecified(eeet, false);
		logger.info(f + "," + f1 + ","+ f2 + "," + f3);
	}

	public int hashCode() {
		return toString().hashCode();
	}

}

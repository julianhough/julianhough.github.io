package qmul.ds.formula;

import java.util.HashMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TTRFormulaMatcher {
	
	protected static Logger logger = Logger.getLogger(TTRFormulaMatcher.class);
	
	public TTRFormula supertype;
	public boolean supertypeRelation = false;
	public boolean subtypeRelation = false;
	public TTRFormula subtype;
	
	public final static Pattern PROOFTYPE_PATTERN = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
	//public boolean[] checks = new boolean[supertype.getRecord().size()]; //array of booleans corresponding to which field has been okay'd
   	public HashMap<TTRLabel, TTRLabel> mapping = new HashMap<TTRLabel, TTRLabel>(); //hashmap mapping supertype variable/label to equivalent in subtype
	
	//constructor
   	/**
   	 * @param candidateSuperType
   	 * @param candidateSubType
   	 */
	public TTRFormulaMatcher(TTRFormula candidateSuperType, TTRFormula candidateSubType) {
		
		supertype = candidateSuperType;
		subtype = candidateSubType;
		
	}
	
	/**
	 * @param superTypeLabel
	 * @param subTypeLabel
	 * @return true iff superTypeLabel is an equivalent proof type to subTypeLabel
	 */
	public boolean proofTypeEquivalency(TTRLabel superTypeLabel, TTRLabel subTypeLabel) {
		
		 //create regex matchers (to extract predicate strings and argument strings from brackets)
		String superM =  supertype.get(superTypeLabel).toString();
		String subM = subtype.get(subTypeLabel).toString();
		logger.debug("super = " + superM);
		logger.debug("sub = " + subM);
		Matcher superMatcher = PROOFTYPE_PATTERN.matcher(superM); 
		if (!superMatcher.matches()) {
			logger.error("NOT PROOF TYPE " + superM + "\n");
			return false;
			}else {logger.debug(superM + "is proof type");
			/*for (int i=0; i<=superMatcher.groupCount(); i++)
				{if (superMatcher.group(i)!=null)
					{logger.debug("group " + i + "= " + superMatcher.group(i));}
				else {break;}
				}*/
			}
		
		Matcher subMatcher = PROOFTYPE_PATTERN.matcher(subM);
		if (!subMatcher.matches()) {
			logger.error("NOT PROOF TYPE " + subM + "\n");
			return false;
			}else {logger.debug(subM + "is proof type");
			/*for (int i=0; i<=subMatcher.groupCount(); i++)
				{if (subMatcher.group(i)!=null)
					{logger.debug("group " + i + "= " + subMatcher.group(i));}
				else {break;}
				}*/
			}
		 //get predicates, first group of matchers
		 String superPredicate = superMatcher.group(1);		 
		 String subPredicate = subMatcher.group(1);

		 //check that the names of the predicates are the same or unmanifest n.b. this may have to change to types...
		 if (superPredicate.equals(subPredicate)||superPredicate.contains("null"))
		 {logger.debug("predicate test ok, now for arguments");}
		 else {
			logger.debug("PROOF TYPE EQUIVALENCY FAILED : predicate name test failed");
			return false;
		 }
		
		 
		/* for (TTRLabel superArgumentLabel : candidateArgumentLabels.keySet())
		 {
			 logger.debug("superArgument label = " + superArgumentLabel + ", subArgumentLabel = " + candidateArgumentLabels.get(superArgumentLabel));
		 }*/
		 
		 
		//checking to see if every argument in the supertype predicate is in the subtype one, in the right order
		 //based on the assumption that predicate(x) is at the moment an equivalence to predicate(x,y) in the spirit of
		 //monotonically incremented DS... this needs to be thought about, and one-place predicates should be the case 
		 //in the spirit of the lambda calculus
		 HashMap<TTRLabel, TTRLabel> candidateArgumentLabels = new HashMap<TTRLabel, TTRLabel>(); 
		 //map from super to sub argument labels, in order 
		 for (int i =2; i<superMatcher.groupCount();i++) {
			 if (superMatcher.group(i)!=null)
		     {
				 if (subMatcher.group(i)!=null)
				 {candidateArgumentLabels.put(new TTRLabel(superMatcher.group(i)), new TTRLabel(subMatcher.group(i)));}
				 else {logger.debug("FAIL, superType pred" + superMatcher.group(0) + " has more args than subtype " + subMatcher.group(0)); 
				 return false;}
			}
			 else {break; //end of relevant strings
				}
		 }
		 
		arguments :  for (TTRLabel superArgumentLabel : candidateArgumentLabels.keySet()) {
				
				//get subArgumentLabel label in same position- this might not be the best way to do it... runs(john) should be equivalent to runs(mile,john) not runs(john,mile)
				TTRLabel subArgumentLabel = candidateArgumentLabels.get(superArgumentLabel);
				
				Formula superArgumentFormula = supertype.get(superArgumentLabel);
			    Formula subArgumentFormula = subtype.get(subArgumentLabel);
			    
				if (!supertype.getRecord().containsKey(superArgumentLabel))  //check to make sure it is there
				{logger.error("argument " + superArgumentLabel + " not present in record"); return false;}
				
			    /*if(mapping.containsKey(superArgumentLabel))  //not a good idea, confounds??
				{   //if the argument has already been passed then free to continue 
						logger.debug("argument " + superArgumentLabel + " already passed");
						continue arguments;
			    } */
				
						//now check the argument of the supertype's predicate against the one in the equivalent position in the subtype
						//they can be no additional bounding of the supertype argument that does not occur in the subtype
						if (superArgumentLabel.TTRtypeMatch(subArgumentLabel))
						{logger.debug("argument " + superArgumentLabel + " successfully type checks");
						//now check the formulae
						} else {
						logger.debug("PROOF TYPE EQUIVALENCY FAIL @ argument: " + superArgumentLabel + " does not type check"); return false;	
						}
						
						boolean prooftypecheck = true;
						if (supertype.isProofType(superArgumentLabel)&&(subtype.isProofType(subArgumentLabel)))
						{ //they are both proof types, do a similar kind of equivalency test (separate method needed?)..
							//recursion:
							if (!proofTypeEquivalency(superArgumentLabel,subArgumentLabel))
							{
								logger.debug("prooftype arguments are not equivalent!");
								prooftypecheck = false; return false;
							} else {
								logger.debug("prooftype arguments are equivalent!"); prooftypecheck = true;
							}
						}
						
						//if not prooftypes, check equivalency of atomic variables
						if (superArgumentFormula.toString().equals(subArgumentFormula.toString()))
					    {logger.debug("formulae match! = " + superArgumentFormula + " and " + subArgumentFormula);}	
						else if (!supertype.isManifestType(superArgumentLabel))
					    {logger.debug("formula is unmanifest so = " + superArgumentFormula + " is ok for sub: " + subArgumentFormula);}
						else {logger.debug("FAIL! " + superArgumentFormula + " and " + subArgumentFormula + " are NOT equivalent"); return false;}
							//pass in that they both have the same value or are unmanifest, if they're proof types the;ve passed (see above)
							//final binding check- nothing should be binding the supertype argument that isn't binding the subtype equivalent
							//an argument may be bound by more than one predicate, iterates through all:
							binder : for (TTRLabel superArgBinder : supertype.getBinder(superArgumentLabel))
						    {   Matcher superMatcher1 = PROOFTYPE_PATTERN.matcher(supertype.get(superArgBinder).toString());      //then checks itself all its arguments
             				 	
						    	//only checks if it's different to the the predicate currently being checked..
								if (superMatcher1.matches())
								{
									if(superMatcher1.group(0)==superMatcher.group(0))
									{
										logger.debug("IGNORE " + superMatcher1.group(0) + " is same as predicate under inspection");
										continue binder;
									}
									String superPredicate1 = superMatcher1.group(1);
	             				 	
									logger.debug("found another predicate binding this variable" + superPredicate1);
	             				 	boolean unwantedBinder = false;
									
								    for (TTRLabel subArgBinder : subtype.getBinder(subArgumentLabel))
									{   Matcher subMatcher1 = PROOFTYPE_PATTERN.matcher(subArgBinder.toString()); 
								    	
		                                //only checks if different to the subtype's argument already being checked
									       if (subMatcher1.matches())
									       {  
									    	if (subMatcher1.group(0)==subMatcher.group(0))
										     {logger.debug("IGNORE" + subMatcher1.group(0) + "is the same as predicate under inspection");
									    		continue;}
									       
	    								    String subPredicate1 = subMatcher1.group(1);
	    								    logger.debug("found another predicate binding this variable = " + subPredicate1);
	    								    //recursion
	    								   	if (proofTypeEquivalency(superArgBinder, subArgBinder))
	    								   	{
	    								   		logger.debug(superPredicate1 + " and " + subPredicate1 + " are equivalent!");
	    								   		unwantedBinder = false; break;
	    							    	}
	    							    	else {
	    							    	 
	    							    		unwantedBinder = true; continue;
	    							    	}	   
									       }else {logger.debug(subArgBinder.toString() + " is NOT a predicate");}
								    	
									}
								    
								    if (unwantedBinder)
								    {	
								    logger.debug("PROOFTYPE FAIL: unwanted binder of one of the arguments!!");
								  	return false;  }
								    
										
									}
								
								}
							
						    
					
						
					//}
 					
 		
		     }
 				
			 
			//if we got this far, they've all been checked?? - put appropriate break statements in 	
				logger.debug("checked all arguments: PROOF TYPE MATCH, adding to mapping"); 
				
				mapping.put(superTypeLabel, subTypeLabel); //add prooftype
				logger.debug("adding" + superTypeLabel);
			
				mapping.putAll(candidateArgumentLabels);  //and arguments
					logger.debug("adding" + candidateArgumentLabels);
					logger.debug("current mapping = " + mapping);
				
				return true; 
			
	}

	
	/**
	 * @param superTypeLabel
	 * @param subTypeLabel
	 * TODO
	 * @return true iff subTypeLabel COULD BE an equivalent proof type to superTypeLabel AFTER PERMISSIBLE OPERATIONS ON superTypeLabel
	 */
	public boolean futureProofTypeEquivalency(TTRLabel superTypeLabel, TTRLabel subTypeLabel) {
		
		 //create regex matchers (to extract predicate strings and argument strings from brackets)
		String superM =  supertype.get(superTypeLabel).toString();
		String subM = subtype.get(subTypeLabel).toString();
		logger.debug("super = " + superM);
		logger.debug("sub = " + subM);
		Matcher superMatcher = PROOFTYPE_PATTERN.matcher(superM); 
		if (!superMatcher.matches()) {
			logger.error("NOT PROOF TYPE " + superM + "\n");
			return false;
			}else {logger.debug(superM + "is proof type");
			for (int i=0; i<=superMatcher.groupCount(); i++)
				{if (superMatcher.group(i)!=null)
					{logger.debug("group " + i + "= " + superMatcher.group(i));}
				else {break;}
				}
			}
		
		Matcher subMatcher = PROOFTYPE_PATTERN.matcher(subM);
		if (!subMatcher.matches()) {
			logger.error("NOT PROOF TYPE " + subM + "\n");
			return false;
			}else {logger.debug(subM + "is proof type");
			for (int i=0; i<=subMatcher.groupCount(); i++)
				{if (subMatcher.group(i)!=null)
					{logger.debug("group " + i + "= " + subMatcher.group(i));}
				else {break;}
				}
			}
		 //get predicates, first group of matchers
		 String superPredicate = superMatcher.group(1);		 
		 String subPredicate = subMatcher.group(1);

		 //check that the names of the predicates are the same or unmanifest n.b. this may have to change to types...
		 if (superPredicate.equals(subPredicate)||subPredicate.contains("null"))  //different here as subPredicate can be underspecified...
		 {logger.debug("predicate test ok, now for arguments");}
		 else {
			logger.info("PROOF TYPE EQUIVALENCY FAILED : predicate name test failed for super-sub " + superMatcher.group(0) 
					+ subMatcher.group(0));
			return false;
		 }
		
		 
		/* for (TTRLabel superArgumentLabel : candidateArgumentLabels.keySet())
		 {
			 logger.debug("superArgument label = " + superArgumentLabel + ", subArgumentLabel = " + candidateArgumentLabels.get(superArgumentLabel));
		 }*/
		 
		 
		//checking to see if every argument in the FUTURE subtype candidate predicate is in the FUTURE supertype candidate one, in the right order
		 //based on the assumption that predicate(x) is at the moment an equivalence to predicate(x,y) in the spirit of
		 //monotonically incremented DS... this needs to be thought about, and one-place predicates should be the case 
		 //in the spirit of the lambda calculus
		 HashMap<TTRLabel, TTRLabel> candidateArgumentLabels = new HashMap<TTRLabel, TTRLabel>(); 
		 //map from super to sub argument labels, in order 
		 for (int i =2; i<subMatcher.groupCount();i++) {
			 if (superMatcher.group(i)!=null)
		     {
				 if (superMatcher.group(i)!=null)
				 {candidateArgumentLabels.put(new TTRLabel(superMatcher.group(i)), new TTRLabel(subMatcher.group(i)));}
				 else {
			     //logger.error("FAIL, superType has more fields than subtype!");    //TODO this doesn't matter here, only equivalence of position I think
				 //return false;
				 
				 }
			}
			 else {break; //end of relevant strings
				}
		 }
		 
		arguments :  for (TTRLabel superArgumentLabel : candidateArgumentLabels.keySet()) {
				
				//get subArgumentLabel label in same position- this might not be the best way to do it... runs(john) should be equivalent to runs(mile,john) not runs(john,mile)
				TTRLabel subArgumentLabel = candidateArgumentLabels.get(superArgumentLabel);
				
				Formula superArgumentFormula = supertype.get(superArgumentLabel);
			    Formula subArgumentFormula = subtype.get(subArgumentLabel);
			    
				if (!supertype.getRecord().containsKey(superArgumentLabel))  //check to make sure it is there
				{logger.error("argument " + superArgumentLabel + " not present in record"); return false;}
				
			    /*if(mapping.containsKey(superArgumentLabel))  //not a good idea, confounds??
				{   //if the argument has already been passed then free to continue 
						logger.debug("argument" + superArgumentLabel + " passed");
						continue arguments;
			    } else 
				{*/
						//now check the argument of the supertype's predicate against the one in the equivalent position in the subtype
						//they can be no additional bounding of the supertype argument that does not occur in the subtype
						if (superArgumentLabel.TTRtypeMatch(subArgumentLabel))
						{logger.debug("argument" + superArgumentLabel + " successfully type checks");
						//now check the formulae
						} else {
						logger.debug("PROOF TYPE EQUIVALENCY FAIL @ argument" + superArgumentLabel + " does not type check"); return false;	
						}
						
						boolean prooftypecheck = true;
						if (supertype.isProofType(superArgumentLabel)&&(subtype.isProofType(subArgumentLabel)))
						{ //they are both proof types, do a similar kind of equivalency test (separate method needed?)..
							//recursion:
							if (!proofTypeEquivalency(superArgumentLabel,subArgumentLabel))
							{
								logger.debug("prooftype arguments are not equivalent!");
								logger.debug("PROOF TYPE EQUIVALENCY FAILED : predicate name test failed for super-sub " + superMatcher.group(0) 
										+ subMatcher.group(0));
								prooftypecheck = false; return false;
							} else {
								logger.debug("prooftype arguments are equivalent!"); prooftypecheck = true;
							}
						}
						
						//if not prooftypes, check equivalency of atomic variables
						if (superArgumentFormula.toString().equals(subArgumentFormula.toString()))
					    {logger.debug("formulae match! = " + superArgumentFormula + " and " + subArgumentFormula);}	
						else if (!supertype.isManifestType(superArgumentLabel))
					    {logger.debug("formula is unmanifest so = " + superArgumentFormula + " is ok for sub: " + subArgumentFormula);}
						else {logger.debug("FAIL! " + superArgumentFormula + " and " + subArgumentFormula + " are NOT equivalent"); return false;}
							//pass in that they both have the same value or are unmanifest, if they're proof types the;ve passed (see above)
							//final binding check- nothing should be binding the supertype argument that isn't binding the subtype equivalent
							//an argument may be bound by more than one predicate, iterates through all:
							binder : for (TTRLabel superArgBinder : supertype.getBinder(superArgumentLabel))
						    {   Matcher superMatcher1 = PROOFTYPE_PATTERN.matcher(supertype.get(superArgBinder).toString());      //then checks itself all its arguments
             				 	
						    	//only checks if it's different to the the predicate currently being checked..
								if (superMatcher1.matches())
								{
									if(superMatcher1.group(0)==superMatcher.group(0))
									{
										logger.debug("IGNORE " + superMatcher1.group(0) + " is same as predicate under inspection");
										continue binder;
									}
									String superPredicate1 = superMatcher1.group(1);
	             				 	
									logger.debug("found another predicate binding this variable" + superPredicate1);
	             				 	boolean unwantedBinder = false;
									
								    for (TTRLabel subArgBinder : subtype.getBinder(subArgumentLabel))
									{   Matcher subMatcher1 = PROOFTYPE_PATTERN.matcher(subArgBinder.toString()); 
								    	
		                                //only checks if different to the subtype's argument already being checked
									       if (subMatcher1.matches())
									       {  
									    	if (subMatcher1.group(0)==subMatcher.group(0))
										     {logger.debug("IGNORE" + subMatcher1.group(0) + "is the same as predicate under inspection");
									    		continue;}
									       
	    								    String subPredicate1 = subMatcher1.group(1);
	    								    logger.debug("found another predicate binding this variable = " + subPredicate1);
	    								    //recursion
	    								   	if (proofTypeEquivalency(superArgBinder, subArgBinder))
	    								   	{
	    								   		logger.debug(superPredicate1 + " and " + subPredicate1 + " are equivalent!");
	    								   		unwantedBinder = false; break;
	    							    	}
	    							    	else {
	    							    	 
	    							    		unwantedBinder = true; continue;
	    							    	}	   
									       }else {logger.debug(subArgBinder.toString() + " is NOT a predicate");}
								    	
									}
								    
								    if (unwantedBinder)
								    {	
								    logger.debug("PROOFTYPE FAIL: unwanted binder of one of the arguments!!");
								    logger.debug("PROOF TYPE EQUIVALENCY FAILED : predicate name test failed for super-sub " + superMatcher.group(0) 
											+ subMatcher.group(0));
								    return false;  
								  	}
								    
										
									}
								
								}
							
						    
					
						
					//}
 					
 		
		     }
 				
			 
			//if we got this far, they've all been checked?? - put appropriate break statements in 	
				logger.debug("checked all arguments: PROOF TYPE MATCH, adding to mapping"); 
				mapping.put(superTypeLabel, subTypeLabel); //add prooftype
				mapping.putAll(candidateArgumentLabels);  //and arguments
				logger.debug("current mapping = " + mapping);
				
				return true; 
			
	}
	
	
	 /** 
     * 
     * @return true iff superType candidate is a supertype of the subtype candidate
     */
    public boolean subTypeRelation() {
    	
    	//logger.debug("SUBTYPE CHECK: checking whether " + subtype + " is a subtype of " + supertype);
    	
        superTypeRecord : for (TTRLabel superTypeLabel : supertype.getLabels())  //if it's a supertype candidate, it makes sense to iterate through this
        {   	
        	Formula superTypeFormula = supertype.get(superTypeLabel);
            logger.debug("\n CHECKING " + superTypeLabel);
        	if (mapping.containsKey(superTypeLabel))
        	{ logger.debug(superTypeLabel + " already passed!, no need to check again");
        		continue superTypeRecord;} //if the corresponding boolean is already true and has been mapped, it's been checked already
        	
            //boolean check = true;  //just for debugging

            //iterates the subtype record to find equivalent field, if none is found, subtype relation fails
            subTypeRecord : for (TTRLabel subTypeLabel : subtype.getLabels())
             {
            	Formula subTypeFormula = subtype.get(subTypeLabel);
             
             	if (subTypeLabel.TTRtypeMatch(superTypeLabel))   //check the types first, won't go further checking unless theyr'e matched for type
             	{ 
             		logger.debug("TYPE SUCCESS: subtype = " + subTypeLabel + " and supertype = " + superTypeLabel + " are of the same type");
             	}
             	else {
             		//check = false; //if no typematch throughout the record, returns false
             		continue subTypeRecord; //carry on trying to find a suitable type
             	}
             	
             	logger.debug("checking whether " + superTypeLabel + " and " + subTypeLabel + " are prooftypes");		
             	if (supertype.isProofType(superTypeLabel)&&subtype.isProofType(subTypeLabel))   //first check if it is a proof type
             	{
             			if (proofTypeEquivalency(superTypeLabel, subTypeLabel))  //the proofTypeEquivalency does the mapping if it can be applied
             			{   			 
             				logger.debug("SUCCESS: equivalent prooftype! " + superTypeLabel);	
             				continue superTypeRecord;
             			} else {logger.debug("not equivalent prooftypes!");}
             				
               } else if (supertype.getBinder(superTypeLabel)==null)   //check to see if it's unbound
               { logger.debug(superTypeLabel + " is unbound");
                           
                        if (subtype.getBinder(subTypeLabel)==null)   //check if the subtype variable checked against is also unbound
                        {  
                        	   logger.debug(subTypeLabel + " subtype is unbound, checking..");   
                        			
                        		if (superTypeFormula.toString().equals(subTypeFormula.toString()))
                        	     {  if (!mapping.containsValue(subTypeLabel))
                        	     	{
                        			mapping.put(superTypeLabel, subTypeLabel); //puts mapping into hashmap if not there already
                        	     	}
                        	     else {
                        	    	 logger.debug("FAIL FOR unbound LABEL " + superTypeLabel + " DOUBLE MAPPING!" + mapping);
                        	    	 mapping.clear();
                        	    	 return false;
                        	     }
                        	     }
                        		continue subTypeRecord;
                        		//else it will not fail, just continue checking rest of subtype
                     			               			
                         } else { //while the iff the supertype variable is unbound but the subtype variable is bound, needs to check whether (one of) the predicates that binds it
                        			//is either not yet present in the supertype 
                        	 		//or amongst the proofs in the supertype a ?canTakeArgument check is applied.... nb the numbArgs problem/saturated..unsaturated etc..
                        			//that is- are there any arguments that could be replaced by the argument under inspection 
                        			
                        			//first check if (one of) the predicate(s) that binds it is not in the supertype yet... but could be
                        			for (TTRLabel argbinder : subtype.getBinder(subTypeLabel))  //possibly only one
                        			{
                        				//check if equivalent proof type exists in supertype that is unsaturated/has arguments that are unmanifest and of right type
                        				for (TTRLabel label : supertype.getLabels())
                        				{
                        					 if (supertype.isProofType(label)) {
	                        					if (proofTypeEquivalency(label, argbinder)){  //it might do it again here
		                        					//there is an equivalent/subtype of proof type in the subtype record that binds the subtype argument under inspection
	                        						//but this proof type does not bind the supertype unbound variable under inspection, check to see if it could..
	                        						
	                        						//so can the current free variable merge with one bound by a proof type already
	                        						for (TTRLabel arg : supertype.getArguments(label))
	                        						{
	                        							if (arg.TTRtypeMatch(superTypeLabel)) {
	                        								if ((supertype.isManifestType(superTypeLabel)&&subTypeFormula.equals(superTypeFormula))
	                        										||(!supertype.isManifestType(superTypeLabel))) {
	                        									
	                        									logger.debug("SUCCESS FOR " + superTypeLabel);
	                        								    mapping.put(superTypeLabel, subTypeLabel);
	                        									continue superTypeRecord;
	                        									 
	                        									
	                        							  }
	                        								
	                        							}
	                        							
	                        						}				
	                        						
	                        					  }else {logger.debug("NOT EQUIV PROOFS "+ label + " and " + argbinder);}
                        					   } 
                        				    }
                        				//if no matching predicate is found in the supertype to compare, then can you just check type and formulae?
                        				//for (TTRLabel arg: subtype.getArguments(argbinder)){  //no need? we know the argument we're checking is of right type
                        				//	if (arg.TTRtypeMatch(superTypeLabel))
                        					//{
                        				            
                        				//	}
                        				//}
                        				
                        				
                        				
                        			 }
                        			
                        			//the simpler check can be used if no predicate equivalency found with mapping
                        			//maybe this time, not allowing double-mapping! Only allowed in case above
                        			if ((supertype.isManifestType(superTypeLabel)&&subTypeFormula.equals(superTypeFormula))
            						||(!supertype.isManifestType(superTypeLabel))) {
                        				if (!mapping.containsValue(subTypeLabel)) {
                        					logger.debug("PASS FOR LABEL " + superTypeLabel);
                        					mapping.put(superTypeLabel, subTypeLabel);	
                        					continue superTypeRecord;
                        					
                        				}else {
                        					logger.debug("FAIL FOR LABEL " + superTypeLabel + " DOUBLE MAPPING!" + mapping);
                        					mapping.clear();
                        					return false;
                        				}
                        					
                        			}
                        			//if we get this far, the label has failed?
                        			
                        			
                           }
                      } 
                     else { //its a bound variable
                        		logger.debug(superTypeLabel + " is bound");
                        		boolean check3 = false;
                        		Vector<TTRLabel> binders = supertype.getBinder(superTypeLabel);
                        		if (!binders.isEmpty()) {
                        			logger.debug("BINDERS TO BE CHECKED ARE: " + binders);
                        			for (TTRLabel binder : binders)
                        			{   logger.debug("checking binder " + binder);
                        				for (TTRLabel label : subtype.getLabels())
                        				{ logger.debug("checking against subtype candidate's " + label);
                        					if (subtype.isProofType(label)) {
	                        					if (proofTypeEquivalency(binder, label))   //this will do the adding of the bound variable
	                        					{
	                        						logger.debug("success with prooftype equivalency!");
	                        						check3 = true;
	                        						break;
	                        					}
	                        					else {check3=false;}
                        					
                        						
                        					}
                        					
                        				}
                        					//each binder has to pass... i.e. find an equivalent, if it doesn't subtype fails
                        				if (!check3) {
                        					//logger.debug("SUBTYPE FAIL for bound variable:" + superTypeLabel);
                        				//	logger.debug("last mapping" + mapping);
                        					mapping.clear();
                        					return false;
                        				}
                        		
                        			}
                        			
                        		}
                        			
                        		
                        		
                        	//check = false;
                            continue subTypeRecord;
                     }
             	
             	     
             	   }
             	  
            if (!mapping.containsKey(superTypeLabel))
            {logger.debug("FAIL TO MAP. No good match for '" + superTypeLabel + "' in subtype candidate. mapping " + mapping);
            mapping.clear();
            return false;
            }
            //else{
             // checks[i] = true;
             // mapping.put(superTypeLabel,subTypeLabel);
            //  continue superTypeRecord;
           // }
        }
    	
    	logger.debug("SUBTYPE SUCCESS!" + mapping); subtypeRelation = true; return true; //if we've got this far
     }
    
    public boolean superTypeRelation() {
    	
    	TTRFormulaMatcher matcher = new TTRFormulaMatcher(this.subtype, this.supertype);
    	if (matcher.subtypeRelation)
    	{	logger.debug("SUPERTYPE CHECK: checking whether " + supertype + "is a subtype of " + subtype);
    		
    		//reverse the mapping..
    		for (TTRLabel keylabel : matcher.getMapping().keySet()) {
    			 mapping.put(matcher.getMapping().get(keylabel), keylabel);
    		}
    	   
    		supertypeRelation = true;
    		return true;	
    		
    	}
    	
    	return false;
    	
    }
    
    public boolean getSuperTypeRelation(){
    	
    	return supertypeRelation;
    }
    
    /** 
     * (apply if in knowledge that subtype check has failed)
     * @return true iff supertype candidate could eventually be a subtype of the supertype candidate
     *  with permissible operations on the supertype's TTRRecord (i.e. unmanifest fields becoming manifest)
     */
    public boolean futureSubTypeRelation() {
    	
    	logger.debug("SUBTYPE CHECK: checking whether " + supertype + " could be a future subtype of " + subtype);
    	
        superTypeRecord : for (TTRLabel superTypeLabel : supertype.getLabels())  //if it's a supertype candidate, it makes sense to iterate through this
        {   	
        	Formula superTypeFormula = supertype.get(superTypeLabel);
           
        	if (mapping.containsKey(superTypeLabel))
        	{continue superTypeRecord;} //if the corresponding boolean is already true and has been mapped, it's been checked already
        	
            //boolean check = true;  //just for debugging

            //iterates the subtype record to find equivalent field, if none is found, subtype relation fails
            subTypeRecord : for (TTRLabel subTypeLabel : subtype.getLabels())
             {
            	Formula subTypeFormula = subtype.get(subTypeLabel);
             
             	if (subTypeLabel.TTRtypeMatch(superTypeLabel))   //check the types first, won't go further checking unless theyr'e matched for type
             	{ 
             		logger.debug("TYPE SUCCESS: subtype = " + subTypeLabel + ", supertype = " + superTypeLabel + " are of the same type");
             	}
             	else {
             		//check = false; //if no typematch throughout the record, returns false
             		continue subTypeRecord; //carry on trying to find a suitable type
             	}
             	
             			
             	if (supertype.isProofType(superTypeLabel)&&subtype.isProofType(subTypeLabel))   //first check if it is a proof type
             	{
             			if (proofTypeEquivalency(superTypeLabel, subTypeLabel))  //the proofTypeEquivalency does the mapping if it can be applied
             			{   			 
             				logger.debug("SUCCESS: equivalent prooftypes!");	
             				continue superTypeRecord;
             			} else if (futureProofTypeEquivalency(superTypeLabel, subTypeLabel))  //the proofTypeEquivalency does the mapping if it can be applied
             			{   			 
             				logger.debug("SUCCESS: equivalent prooftypes!");	
             				continue superTypeRecord;
             			}else {logger.debug("not equivalent prooftypes!");}
             				
               } else if (supertype.getBinder(superTypeLabel)==null)   //check to see if it's unbound
               { logger.debug(superTypeLabel + " is unbound");
                           
                        if (subtype.getBinder(subTypeLabel)==null)   //check if the subtype variable checked against is also unbound
                        {  
                        	   logger.debug(subTypeLabel + " subtype is unbound, checking..");   
                        			
                        		if (superTypeFormula.equals(subTypeFormula))
                        	     {  if (!mapping.containsValue(subTypeLabel))
                        	     	{
                        			mapping.put(superTypeLabel, subTypeLabel); //puts mapping into hashmap if not there already
                        	     	}
                        	     else {
                        	    	 logger.debug("FAIL FOR LABEL " + superTypeLabel + " DOUBLE MAPPING!");
                        	    	 mapping.clear();
                        	    	 return false;
                        	     }
                        	     }
                        		continue subTypeRecord;
                        		//else it will not fail, just continue checking rest of subtype
                     			               			
                         } else { //while the iff the supertype variable is unbound but the subtype variable is bound, needs to check whether (one of) the predicates that binds it
                        			//is either not yet present in the supertype 
                        	 		//or amongst the proofs in the supertype a ?canTakeArgument check is applied.... nb the numbArgs problem/saturated..unsaturated etc..
                        			//that is- are there any arguments that could be replaced by the argument under inspection 
                        			
                        			//first check if (one of) the predicate(s) that binds it is not in the supertype yet... but could be
                        			for (TTRLabel argbinder : subtype.getBinder(subTypeLabel))  //possibly only one
                        			{
                        				//check if equivalent proof type exists in supertype that is unsaturated/has arguments that are unmanifest and of right type
                        				for (TTRLabel label : supertype.getLabels())
                        				{
                        					 if (supertype.isProofType(label)) {
	                        					if (proofTypeEquivalency(label, argbinder)){  //it might do it again here
		                        					//there is an equivalent/subtype of proof type in the subtype record that binds the subtype argument under inspection
	                        						//but this proof type does not bind the supertype unbound variable under inspection, check to see if it could..
	                        						
	                        						//so can the current free variable merge with one bound by a proof type already
	                        						for (TTRLabel arg : supertype.getArguments(label))
	                        						{
	                        							if (arg.TTRtypeMatch(superTypeLabel)) {
	                        								if ((supertype.isManifestType(superTypeLabel)&&subTypeFormula.equals(superTypeFormula))
	                        										||(!supertype.isManifestType(superTypeLabel))) {
	                        									
	                        									logger.debug("CHECKING SUCCESS FOR " + superTypeLabel);
	                        								    mapping.put(superTypeLabel, subTypeLabel);
	                        									continue superTypeRecord;
	                        									 
	                        									
	                        							  }
	                        								
	                        							}
	                        							
	                        						}				
	                        						
	                        					  }
                        					   }
                        				    }
                        				//if no matching predicate is found in the supertype to compare, then can you just check type and formulae?
                        				//for (TTRLabel arg: subtype.getArguments(argbinder)){  //no need? we know the argument we're checking is of right type
                        				//	if (arg.TTRtypeMatch(superTypeLabel))
                        					//{
                        				            
                        				//	}
                        				//}
                        				
                        				
                        				
                        			 }
                        			
                        			//the simpler check can be used if no predicate equivalency found with mapping
                        			//maybe this time, not allowing double-mapping! Only allowed in case above
                        			if ((supertype.isManifestType(superTypeLabel)&&subTypeFormula.equals(superTypeFormula))
            						||(!supertype.isManifestType(superTypeLabel))) {
                        				if (!mapping.containsValue(subTypeLabel)) {
                        					logger.debug("PASS FOR LABEL " + superTypeLabel);
                        					mapping.put(superTypeLabel, subTypeLabel);	
                        					continue superTypeRecord;
                        					
                        				}else {
                        					logger.debug("FAIL FOR LABEL " + superTypeLabel + " DOUBLE MAPPING!");
                        					mapping.clear();
                        					return false;
                        				}
                        					
                        			}
                        			//if we get this far, the label has failed?
                        			
                        			
                           }
                      } 
                     else { //its a bound variable
                        		logger.debug(superTypeLabel + " is bound");
                        		boolean check3 = false;
                        		Vector<TTRLabel> binders = supertype.getBinder(superTypeLabel);
                        		if (!binders.isEmpty()) {
                        			for (TTRLabel binder : binders)
                        			{
                        				for (TTRLabel label : subtype.getLabels())
                        				{
                        					if (subtype.isProofType(label)) {
	                        					if (proofTypeEquivalency(binder, label))   //this will do the adding of the bound variable
	                        					{
	                        						logger.debug("success with prooftype equivalency!");
	                        						check3 = true;
	                        						break;
	                        					}
	                        					else {check3=false;}
                        					
                        						
                        					}
                        					
                        				}
                        					//each binder has to pass... i.e. find an equivalent, if it doesn't subtype fails
                        				if (!check3) {
                        					logger.debug("SUBTYPE FAIL for bound variable");
                        					mapping.clear();
                        					return false;
                        				}
                        		
                        			}
                        			
                        		}
                        			
                        		
                        		
                        	//check = false;
                            continue subTypeRecord;
                     }
             	
             	     
             	   }
             	  
            if (!mapping.containsKey(superTypeLabel))
            {logger.debug("FAIL TO MAP. No good type match for '" + superTypeLabel + "' in subtype candidate");
            mapping.clear();
            return false;
            }
            //else{
             // checks[i] = true;
             // mapping.put(superTypeLabel,subTypeLabel);
            //  continue superTypeRecord;
           // }
        }
    	
    	logger.debug("SUBTYPE SUCCESS!" + mapping);return true; //if we've got this far
     }
    
    public HashMap<TTRLabel,TTRLabel> getMapping(){
    	
    	return mapping;
    }
   
    /**
     * Only useful after boolean <code> subTypeRelation()</code> has been run. Saves running it again 
     * 
     */
    public boolean getSubTypeRelation(){
    	return this.subtypeRelation;
    }

}

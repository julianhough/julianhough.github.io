package qmul.ds.formula;

import java.util.regex.Matcher;

import qmul.ds.type.Type;

/**
 * A lambda abstract X^Formula
 *
 * @author mpurver
 */
public class LambdaAbstract extends Formula {

    protected static final String LAMBDA_FUNCTOR = "^";
    private static final String UNICODE_LAMBDA_FUNCTOR = "\u03BB"; // lambda; also 1D6CC

    private String variable;
    private Formula formula;

    public LambdaAbstract(){

    }
    public LambdaAbstract(String variable, Formula formula) {
        this.variable = variable;
        this.formula = formula;
    }

    /**
     * @param argument
     * @return
     */
    public Formula betaReduce(Formula argument) {
        Formula newCore;
    	TTRFormula ttrA = null;
    	TTRFormula ttrF = null;
    	TTRFormula ttrCore = null;
    	boolean lambda1arg = false;
    	boolean lambda2arg = false;
    	String variable1 = "";
    	String variable2 = "";
     
        if (this.getFormula() instanceof LambdaAbstract && argument instanceof LambdaAbstract)
   	 {  //TODO still not completely finished
   		logger.debug("functor of formula " + this + " is lambda abstract");
   		logger.debug("argument formula " + argument + " is lambda abstract");
   		
   		LambdaAbstract lambdaArgument = new LambdaAbstract(((LambdaAbstract) argument).getVariable(),((LambdaAbstract) argument).getFormula());
   		logger.debug("argument core formula = " + lambdaArgument.getCore());
   		logger.debug("argument's variable = " + lambdaArgument.getVariable());
   		
   		if (lambdaArgument.getCore() instanceof TTRFormula)
   		{
   		logger.debug("argument is TTR!");}
   		
   		//if(this.getCore() instanceof LambdaAbstract) {
   			if(((LambdaAbstract) this.getFormula()) instanceof LambdaAbstract && lambdaArgument.hasVariable(((LambdaAbstract) this.getFormula()).getVariable()))
   				//	&&((LambdaAbstract) getFormula()).numVariables()==2
			//	&&lambdaArgument.hasVariable(((LambdaAbstract)((LambdaAbstract) getCore()).getCore()).getVariable()))
   			// if we've got an X^Y^Z^[y:pred(X,Y,Z] functor and a Z^[x:pred(Z)] argument:
   				{
			//we've got a X^Y^[pred(X,Y)] functor and a x:pred(Y) type case, i.e. shared variable in second position
			argument = lambdaArgument.getFormula();
			lambda2arg = true;
			//variable1 = ((LambdaAbstract) this.getFormula())
			logger.debug("argument has same variable as the first variable of functor's core (which is a 2 place predicate). lambda removed. argument now = " + argument);
			
   			} else if(lambdaArgument.hasVariable(variable))
		{ // if we've got an X^Y^[pred(X,Y] functor and a [x:pred(X)] argument, we need to return Y^X^[pred(X,Y)]
			argument = lambdaArgument.getFormula();
			lambda1arg = true;
			variable1 = lambdaArgument.getVariable();
			logger.debug("argument has same variable as lambda abstract in functor's core, removing lambda term, argument now = " + argument);
			
		} else {logger.debug("variables not matching");}
   		//}
   	 }
        if (argument instanceof TTRFormula) {
        
            ttrA = new TTRFormula((TTRFormula) argument);//}
            ttrF = (TTRFormula) getCore();
            ttrCore = new TTRFormula(ttrF);
            logger.trace("beta-reduce " + this + " with " + ttrA + " core " + ttrCore);
            Formula headOfFunctor = ttrCore.get(ttrCore.getHead());
            TTRLabel headLabelOfArgument = ttrA.getHead();
            logger.trace("check for label " + headLabelOfArgument);
            if (ttrCore.getLabels().contains(headLabelOfArgument)) {
                if(!ttrCore.get(headLabelOfArgument).equals(ttrA.get(headLabelOfArgument)))

                {logger.trace("label present, renaming");
                // TTRLabel labelOfArgumentFormulaInCore = ttrCore.formulaLabel(ttrA.get(headLabelOfArgument));
                // if (labelOfArgumentFormulaInCore != null) {
                // ttrA.relabelAndUpdate(headLabelOfArgument, labelOfArgumentFormulaInCore);
                // headLabelOfArgument = labelOfArgumentFormulaInCore;
                // } else {

                
                TTRLabel newHead = ttrCore.getFreeLabel(headLabelOfArgument);
                ttrA.relabelAndUpdate(headLabelOfArgument, newHead);
                headLabelOfArgument = newHead;
                logger.trace("relabelled " + ttrA);
                // }
                }
                else {logger.debug("TTRLabel and Formula for " + headLabelOfArgument + "already present");}
            }
            logger.trace("before premerge = " + ttrA);
            TTRFormula premerge = ttrCore.preMerge(ttrA);  //changes labels accordingly for merging (relabelling), returns empty if no change needed
            if (!premerge.getLabels().isEmpty())
            {
            headLabelOfArgument = premerge.getHead();
            logger.trace("relabelled premerge = " + premerge);
            
            logger.trace("new head of argument =" + headLabelOfArgument);
            logger.debug("head of functor = " + headOfFunctor);
            
            TTRLabel newHead = ttrCore.getFreeLabel(headLabelOfArgument);
            premerge.relabelAndUpdate(headLabelOfArgument, newHead);
            headLabelOfArgument = newHead;    
            
            Formula betaReduced = headOfFunctor.substitute(variable, headLabelOfArgument);
            logger.trace("beta-reduced " + betaReduced);
            ttrCore.put(ttrCore.getHead(), betaReduced);
            
            //needs to check for other fields that might have the variable in
            for (TTRLabel newlabel: ttrCore.getLabels())
            {
            	Formula newformula = ttrCore.get(newlabel);
            	if (newformula.toString().contains(this.variable)){ //hacky string match
            		Formula betaReducedOther = ttrCore.get(newlabel).substitute(this.variable, headLabelOfArgument);
                    logger.trace("beta-reduced " + betaReducedOther);
                    ttrCore.put(newlabel, betaReducedOther);
            		
            	}
            	
            }
            
            
    
            logger.trace("ttrcoreput " + ttrCore + "with premerge  " + premerge);
            
            ttrCore.mergeAtTop(premerge);//
            logger.trace("ttrmerge " + ttrCore);
            } else
            {  
            	   logger.debug("head of functor = " + headOfFunctor);
                   Formula betaReduced = headOfFunctor.substitute(variable, headLabelOfArgument);
                   logger.trace("beta-reduced " + betaReduced);
                   ttrCore.put(ttrCore.getHead(), betaReduced);
                   logger.trace("ttrcoreput " + ttrCore + "with  " + ttrA);
                   //ttrCore = hackEps(ttrCore);
                   ttrCore.mergeAtTop(ttrA);//

                   logger.trace("ttrmerge " + ttrCore); 
            	
            	
            	
            }
            newCore = ttrCore;
          
           // newCore = hackEps(ttrCore);

            /*
             * // add all argument labels at top, renaming if necessary


             TTRLabel headLabel = ((TTRFormula) newCore).addAtTop(ttrA);

             // then do beta-reduction renaming with the head argument label for (TTRLabel l : ttrF.getLabels()) { //
             if the label is the variable, replace it if (l.toString().equals(variable)) { ((TTRFormula)
         newCore).relabel(l, headLabel); l = headLabel; } // and do any necessary replacement in the body
             ((TTRFormula) newCore).put(l, ((TTRFormula) newCore).get(l) .substitute(variable, headLabel)); }
             */

        } else {
            newCore = getCore().substitute(variable, argument);
        }  
        if (lambda1arg)
        {
           newCore = new LambdaAbstract(variable1, newCore); 	
            	
        }
        return replaceCore(newCore);
    }

    /**
     * @param ttr
     * @return hack to interpet epsilon terms in a sensible way in TTR - replace with equality to first suitable
     *         variable
     */
    private TTRFormula hackEps(TTRFormula ttr) {
        for (TTRLabel label : ttr.getLabels()) {
            Matcher m = Formula.EPSILON_TERM_PATTERN.matcher(ttr.get(label).toString());
            if (m.find()) {
                logger.trace("eps " + ttr.get(label));
                ttr.put(label, Formula.create(label + " = " + ttr.getLabels().get(0)));
            }
        }
        return ttr;
    }

    /**
     * @return the core formula within the lambda operators
     */
    public Formula getCore() {
        if (formula instanceof LambdaAbstract) {
            return ((LambdaAbstract) formula).getCore();
        } else {
            return formula;
        }
    }

    /**
     * @param newFormula
     * @return formula, with core replaced with newFormula
     */
    private Formula replaceCore(Formula newFormula) {
        if (formula instanceof LambdaAbstract) {
            return new LambdaAbstract(((LambdaAbstract) formula).variable, ((LambdaAbstract) formula)
                    .replaceCore(newFormula));
        } else {
            return newFormula;
        }
    }
    
    public static LambdaAbstract getLambdaAbstract(Type t)
    {
    	
    	return null;
    	
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#hashCode()
     */

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((formula == null) ? 0 : formula.hashCode());
        result = prime * result + ((variable == null) ? 0 : variable.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        LambdaAbstract other = (LambdaAbstract) obj;
        if (formula == null) {
            if (other.formula != null)
                return false;
        } else if (!formula.equals(other.formula))
            return false;
        if (variable == null) {
            if (other.variable != null)
                return false;
        } else if (!variable.equals(other.variable))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     *
     * @see qmul.ds.formula.Formula#toUnicodeString()
     */
    @Override
    public String toUnicodeString() {
        // return super.toUnicodeString().replaceAll("(\\w)" +
        // Pattern.quote(LAMBDA_FUNCTOR),
        // UNICODE_LAMBDA_FUNCTOR + "$1.");
        return UNICODE_LAMBDA_FUNCTOR + variable + "." + formula.toUnicodeString();
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return variable + LAMBDA_FUNCTOR + formula;
    }

    public int numVariables() {
        if (!(formula instanceof LambdaAbstract))
            return 1;
        else
            return ((LambdaAbstract) formula).numVariables() + 1;
    }

    public Formula conjoin(Formula f) {
        if (!(f instanceof LambdaAbstract)) {
        	if (this.getFormula() instanceof TTRFormula)
        	{
        		if (f instanceof TTRFormula) {
        		logger.debug("trying to combine a TTR lambaabstract with another ttr formula");
        		TTRFormula thisTTR = (TTRFormula) this.getFormula();
        		thisTTR.mergeAtTop((TTRFormula) f);
        		LambdaAbstract newLambda = new LambdaAbstract(this.getVariable(), thisTTR);
        		return newLambda;
        		
        		
        		}
        	}
            return Formula.create(toString() + CONJUNCTION_OPERATOR + f.toString());
        }
    	
        LambdaAbstract other = (LambdaAbstract) f;
        if (numVariables() != other.numVariables())
            throw new IllegalArgumentException("Tried to conjoin:" + this + " with :" + f
                    + "\nCan only conjoin a Lambda Abstract with another one of the same type.");

        logger.debug("before variable replace" + other);
        LambdaAbstract otherReplaced = other.replaceVariable(this.variable);
        logger.debug("after variable replace" + otherReplaced);
        
        return new LambdaAbstract(this.variable, this.formula.conjoin(otherReplaced.formula));

    }

    public LambdaAbstract replaceVariable(String var) {
        return new LambdaAbstract(var, formula.substitute(variable, var));
    }

    public Formula getFormula() {
        return this.formula;
    }
    
    public String getVariable() {
    	return this.variable;
    }

    public boolean hasVariable(String var) {
        if (this.variable.equals(var)) {
            return true;
        } else if (this.formula instanceof LambdaAbstract) {
            return ((LambdaAbstract) formula).hasVariable(var);
        } else {
            return false;
        }
    }

    public static void main(String a[]) {
        Formula f1 = Formula.create("X^Y^like(X,Y)");
        Formula f2 = Formula.create("Z^U^dislike(U,Z)");

        Formula conjoined = f1.conjoin(f2);
        logger.debug(conjoined);

        TTRFormula f3 = new TTRFormula("e1", "e5");
        f3.add(new TTRLabel("r"), Formula.create("reftime"));
        f3.add(new TTRLabel("p"), Formula.create("e overlap r & r=now"));
        f3.add(new TTRLabel("e"), Formula.create("e = e1"));
        f3.setHead(new TTRLabel("e"));

        logger.debug(f3);

        TTRFormula f4 = new TTRFormula("x2", "add");
        f4.add(new TTRLabel("e1"),Formula.create("e4"));
        f4.add(new TTRLabel("r"),Formula.create("reftime2"));
        f4.add(new TTRLabel("p3"),Formula.create("e overlap r & now<e<r"));
        f4.add(new TTRLabel("e"),Formula.create("e = e1"));
        f4.add(new TTRLabel("x"),Formula.create("add"));
        f4.add(new TTRLabel("p1"),Formula.create("go_to(e,x)"));
        f4.add(new TTRLabel("e2"),Formula.create("e4"));
        f4.add(new TTRLabel("x1"),Formula.create("unknown"));
        f4.add(new TTRLabel("p2"),Formula.create("loc(e1,x1)"));
        f4.add(new TTRLabel("p"),Formula.create("want(Y,x2,p1)"));
        f4.setHead(new TTRLabel("p"));
        LambdaAbstract function = new LambdaAbstract("Y", f4);

        logger.debug("applying betareduction from " + function.toString() + "\n to" + f3.toString());

        Formula reduced = function.betaReduce(f3);

        logger.debug("betaredction result = " + reduced.toString());





    }

}
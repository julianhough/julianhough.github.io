package qmul.ds.formula;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A TTR record type
 *
 * @author mpurver
 */
public class TTRFormula extends Formula {

    public static final String TTR_OPEN = "[";
    public static final String TTR_LABEL_SEPARATOR = ":";
    public static final String TTR_FIELD_SEPARATOR = "|";
    public static final String TTR_CLOSE = "]";
    public static final String TTR_HEAD = "*";
    public static final String TTR_LINE_BREAK = "TTRBR";
    public static Pattern PROOFTYPE_PATTERN = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
    //TODO needs a pattern for event-proof types?
    
    private TTRLabel head;
    private ArrayList<TTRLabel> labels = new ArrayList<TTRLabel>();
    private HashMap<TTRLabel, Formula> record = new HashMap<TTRLabel, Formula>();

    public TTRFormula() {
    }

    /**
     * @param label
     * @param formula
     */
    public TTRFormula(String label, String formula) {
        TTRLabel ttrlabel = new TTRLabel(label);
        Formula ttrformula = (formula == null ? null : Formula.create(formula));
        labels.add(ttrlabel);
        record.put(ttrlabel, ttrformula);
        head = ttrlabel;
    }

    /**
     * @param formula
     */
    public TTRFormula(TTRFormula formula) {
        add(formula);
        head = formula.head;
    }

    /**
     * @return the labels
     */
    public ArrayList<TTRLabel> getLabels() {
        return labels;
    }

    /**
     * @return the record
     */
    public HashMap<TTRLabel, Formula> getRecord() {
        return record;
    }

    public void setHead(TTRLabel h) {
        if (labels.contains(h))
            head = h;
    }

    /**
     * @return the head label
     */
    public TTRLabel getHead() {
        return head;
    }

    /**
     * @param label
     * @return the value associated with label
     */
    public Formula get(TTRLabel label) {
        return record.get(label);
    }

    /**
     * If a mapping for label exists, change its value to formula; if not, add a new mapping label : formula
     *
     * @param label
     * @param formula
     */
    public void put(TTRLabel label, Formula formula) {
        if (!labels.contains(label)) {
            labels.add(label);
        }
        record.put(label, formula);
    }

    /**
     * Change the label for a mapping
     *
     * @param oldLabel
     * @param newLabel
     */
    public void relabel(TTRLabel oldLabel, TTRLabel newLabel) {
        labels.set(labels.indexOf(oldLabel), newLabel);
        record.put(newLabel, record.get(oldLabel));
        record.remove(oldLabel);
        if (head.equals(oldLabel)) {
            head = newLabel;
        }
    }

    /**
     * @param label
     *            e.g. x
     * @return the label x unchanged if it is not used in this record; the next available unused x1,x2 etc otherwise
     */
    public TTRLabel getFreeLabel(TTRLabel label) {
        while (labels.contains(label)) {
            label = label.next();
        }
        return label;
    }

    /**
     * Add (at bottom) this label & formula, renaming label if necessary to avoid clashing with existing labels
     *
     * @param label
     * @param formula
     * @return the new label - same as original label unless renaming happened
     */
    public TTRLabel add(TTRLabel label, Formula formula) {
        return addAt(labels.size(), label, formula);
    }

    /**
     * Add (at top) this label & formula, renaming label if necessary to avoid clashing with existing labels
     *
     * @param label
     * @param formula
     * @return the new label - same as original label unless renaming happened
     */
    public TTRLabel addAtTop(TTRLabel label, Formula formula) {
        return addAt(0, label, formula);
    }

    /**
     * Add (at index) this label & formula, renaming label if necessary to avoid clashing with existing labels
     *
     * @param index
     * @param label
     * @param formula
     * @return the new label - same as original label unless renaming happened
     */
    private TTRLabel addAt(int index, TTRLabel label, Formula formula) {
        TTRLabel newLabel = getFreeLabel(label);
        if (!label.equals(newLabel)) {
            formula = formula.substitute(label, newLabel);
        }
        labels.add(index, newLabel);
        record.put(newLabel, formula);
        return newLabel;
    }

    /**
     * Add (at bottom) the labels & mappings from ttr, renaming labels if necessary to avoid clashing with existing
     * labels
     *
     * @param ttr
     * @return the new label for the old head of ttr - same as original label unless renaming happened
     */
    public TTRLabel add(TTRFormula ttr) {
        TTRLabel headLabel = ttr.getHead();
        for (int i = 0; i < ttr.labels.size(); i++) {
            TTRLabel label = ttr.labels.get(i);
            TTRLabel newLabel = add(label, ttr.record.get(label));
            if (!newLabel.equals(label)) {
                for (int j = i + 1; j < ttr.labels.size(); j++) {
                    ttr.put(ttr.labels.get(j), ttr.get(ttr.labels.get(j)).substitute(label, newLabel));
                }
                if (label.equals(headLabel)) {
                    headLabel = newLabel;
                }
            }
        }
        return headLabel;
    }
    
  public void simpleAdd(TTRLabel label, Formula formula) {
	  labels.add(labels.size(),label);
	  record.put(label, formula);
	  
  }
    

    /**
     * Add (at top) the labels & mappings from ttr, renaming labels if necessary to avoid clashing with existing labels
     *
     * @param ttr
     * @return the new label for the old head of ttr - same as original label unless renaming happened
     */
    public TTRLabel addAtTop(TTRFormula ttrA) {
        TTRFormula ttr = new TTRFormula(ttrA);
        TTRLabel headLabel = ttr.getHead();
        for (int i = 0; i < ttr.labels.size(); i++) {
            TTRLabel label = ttr.labels.get(i);
            TTRLabel newLabel = addAt(i, label, ttr.record.get(label));
            if (!newLabel.equals(label)) {
                for (int j = i + 1; j < ttr.labels.size(); j++) {
                    ttr.put(ttr.labels.get(j), ttr.get(ttr.labels.get(j)).substitute(label, newLabel));
                }
                if (label.equals(headLabel)) {
                    headLabel = newLabel;
                }
            }
        }
        return headLabel;
    }

    /**
     * Merge (at bottom) the labels & mappings from ttr, with no renaming: add only those labels which don't already
     * exist in this TTR formula
     *
     * @param ttr
     * @return the label for the old head of ttr
     */
    public void merge(TTRFormula ttr) {

        logger.debug("merging \n" + this + "\nwith\n" + ttr);

        TTRFormula ttrF = new TTRFormula(ttr);
        for (int i = 0; i < ttrF.labels.size(); i++) {
            TTRLabel label = ttrF.labels.get(i);

            if (!labels.contains(label)) {
                Formula mapped = ttrF.get(label);
                TTRLabel labelOfFormulaInMe = formulaLabel(mapped);

                if (labelOfFormulaInMe != null) {
                    ttrF.relabelAndUpdate(label, labelOfFormulaInMe);

                } else
                    add(label, ttrF.record.get(label));
            } else {
            	//check to see if formula are the same
                Formula f1 = record.get(label);
                Formula f2 = ttrF.record.get(label);
                if (!f1.equals(f2)) {
                    TTRLabel l = ttrF.getFreeLabel(label);
                    ttrF.relabelAndUpdate(label, l);
                    add(l, f2);

                } else {
                	boolean headness = false;
                    if (ttrF.get(label).equals(ttrF.getHead())&&label.toString().contains("p"))
                    {headness = true;
                    logger.info("headness true for " + ttrF.get(label)); 
                    TTRLabel l = ttrF.getFreeLabel(label);
                    ttrF.relabelAndUpdate(label, l);
                    add(l, f2);}
                	
                }
            }
        }

    }

    public TTRLabel formulaLabel(Formula f) {
        for (TTRLabel l : record.keySet()) {
            if (f.equals(record.get(l)))
                return l;
        }
        return null;
    }

    /*
     * (non-Javadoc)
     *
     * @see qmul.ds.formula.Formula#conjoin(qmul.ds.formula.Formula)
     */
    @Override
    public Formula conjoin(Formula f) {
        if (f instanceof TTRFormula) {
            TTRFormula me = new TTRFormula(this);
            logger.debug("conjoining " + this + " with " + f);
            
           //TODO //preserve the head in a conjoin iff it is type p- why? needs to be more principled than that.
            
            
            //needs to do a common elements check??
            me.merge((TTRFormula) f);
            //((TTRFormula) f).merge(me);
            //should change to mergeAtTop here
            logger.debug("returning "+me+" as new formula");
            return me;
        } else {
            return super.conjoin(f);
        }
    }

    public void relabelAndUpdate(TTRLabel oldLabel, TTRLabel newLabel) {
        logger.debug("relabel " + oldLabel + " to " + newLabel + " in \n" + this);
        if (!labels.contains(oldLabel) || !record.keySet().contains(oldLabel) || oldLabel.equals(newLabel))
            return;
        boolean oldLabelheadness = false;   //think about whether sensible to have head or not...
        if (head.equals(oldLabel)) { 
        	logger.trace("oldLabel " + oldLabel + " is head");
        	oldLabelheadness = true;
        }else {logger.trace("oldLabel " + oldLabel + "is not head");}

        if (labels.contains(newLabel)) {
        	
        	boolean newLabelheadness = false;
            if (head.equals(newLabel)) { 
            	logger.trace("newLabel " + newLabel + " is head");
            	newLabelheadness = true;
            }else {logger.trace("newLabel " + newLabel + " is not head");}
            
            int i = labels.indexOf(newLabel);
            TTRLabel free = getFreeLabel(newLabel);
            record.put(free, record.get(newLabel));
            record.remove(newLabel);
            labels.remove(newLabel);
            labels.add(i, free);
            if (newLabelheadness){
            	this.setHead(free);
            }
            for (TTRLabel l : record.keySet()) {
                Formula mapped = record.get(l);
                Formula newMapped = mapped.substitute(newLabel, free);
                put(l, newMapped);
            }

        }
        record.put(newLabel, record.get(oldLabel));
        record.remove(oldLabel);
        int indexOfOldLabel = labels.indexOf(oldLabel);
        labels.remove(oldLabel);
        labels.add(indexOfOldLabel, newLabel);
        for (TTRLabel l : record.keySet()) {
            Formula mapped = record.get(l);
            Formula newMapped = mapped.substitute(oldLabel, newLabel);
            put(l, newMapped);
        }
        if (oldLabelheadness) {
            head = newLabel;
        }
        logger.debug("relabelling result = " + this);
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#hashCode()
     */

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((labels == null) ? 0 : labels.hashCode());
        result = prime * result + ((record == null) ? 0 : record.hashCode());
        result = prime * result + ((head == null) ? 0 : head.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TTRFormula other = (TTRFormula) obj;
        if (labels == null) {
            if (other.labels != null)
                return false;
        } else if (!labels.equals(other.labels))
            return false;
        if (record == null) {
            if (other.record != null)
                return false;
        } else if (!record.equals(other.record))
            return false;
        if (head == null) {
            if (other.head != null)
                return false;
        } else if (!head.equals(other.head))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        String s = TTR_OPEN;
        for (TTRLabel label : labels) {
            s += (label.equals(head) ? TTR_HEAD + label : label) + " " + TTR_LABEL_SEPARATOR + " " + record.get(label)
                    + ", ";
        }
        //logger.info(s);
        try {
        return s.substring(0, s.length() - 2) + TTR_CLOSE;
        }catch (Exception e) {
        	logger.info("PROBLEM WITH  " + s);
        }
        return s + TTR_CLOSE;

    }

    /*
     * (non-Javadoc)
     *
     * @see qmul.ds.formula.Formula#toUnicodeString()
     */
    @Override
    public String toUnicodeString() {
        String s = TTR_OPEN;
        for (TTRLabel label : labels) {
            s += (label.equals(head) ? TTR_HEAD + label : label) + " " + TTR_LABEL_SEPARATOR + " "
                    + record.get(label).toUnicodeString() + TTR_LINE_BREAK;
        }
        return s.substring(0, s.length() - TTR_LINE_BREAK.length()) + TTR_CLOSE;
    }

    public static void main(String a[]) {
        TTRFormula f1 = new TTRFormula("p", "eee");
        //f1.add(new TTRLabel("x"), Formula.create("speaker"));
        //f1.add(new TTRLabel("r"), Formula.create("null"));
        //f1.add(new TTRLabel("p1"), Formula.create("null(r,es)"));
        //f1.add(new TTRLabel("e"), Formula.create("eps(p1)"));
        //f1.add(new TTRLabel("p"), Formula.create("go(e,x)"));
        f1.setHead(new TTRLabel("p"));
        TTRFormula f2 = new TTRFormula("p", "eee");
        //f2.add(new TTRLabel("es"), Formula.create("e5"));
        //f2.add(new TTRLabel("r"), Formula.create("reftime"));
        //f2.add(new TTRLabel("p1"), Formula.create("present(r,es)"));
        //f2.add(new TTRLabel("x"), Formula.create("speaker"));
        //f2.add(new TTRLabel("p"), Formula.create("go(e,x)"));
        //f2.add(new TTRLabel("a"), Formula.create("hello"));
        
       /* f2.add(new TTRLabel("x1"), Formula.create("null"));
        f2.add(new TTRLabel("p2"), Formula.create("from_location(e,x1)"));
        f2.add(new TTRLabel("x2"), Formula.create("null"));
        f2.add(new TTRLabel("p3"), Formula.create("to_location(e,x2)"));
        f2.add(new TTRLabel("x3"), Formula.create("null"));
        f2.add(new TTRLabel("p4"), Formula.create("on_date(e,x3)"));*/
        f2.setHead(new TTRLabel("p"));
        
    	
        //String mary = new String ("likes(p1,y1)");
        //Matcher m = PROOFTYPE_PATTERN.matcher(mary);
		/*if (!m.matches()) {
		throw new RuntimeException("NOT PROOF TYPE " + mary + "\n");
		}else {logger.debug(mary + "is proof type");
		for (int i=0; i<=m.groupCount(); i++)
			{if (m.group(i)!=null)
				{logger.debug("group " + i + "= " + m.group(i));}
			else {break;}
			}
		}*/
		
        logger.info(System.currentTimeMillis());
        boolean sub = f2.isSubtypeOf(f1);
        logger.info(System.currentTimeMillis());
        logger.info(sub);
       
//        TTRFormula f3 = new TTRFormula("e", "eps(p1)");
//        f3.setHead(new TTRLabel("e")); 
//        Vector<TTRLabel> args = new Vector<TTRLabel>();
//        
//         args = f3.getArguments(new TTRLabel("x"));
//         logger.info(args);
        
         //logger.trace("before relabelling:\n"+f1); f1.relabelAndUpdate(new TTRLabel("x1"), new TTRLabel("x"));
         //logger.trace("after relabelling:\n"+f1);
         
        
        
        
        /*f2.merge(f1);
        //logger.debug("Merged:\n" + f2);
        logger.debug(f1);
        logger.debug(f2);
        boolean subtype = f1.isSubtypeOf(f2);
        logger.debug("subtype = " + subtype);
        boolean match = f1.equals(f2);
        logger.debug("match = " + match);
        */
    

    }
    
    /**
     * Method for doing labelling before merging, to avoid bounded formulae not being updated through addAtTop method
     * @param ttr
     * @return 
     */
    public TTRFormula preMerge(TTRFormula ttr) {

        TTRFormula ttrF = new TTRFormula(ttr);
        TTRFormula ttrNewF = new TTRFormula();

        for (int i = ttrF.labels.size() - 1; i >= 0; i--) {  //iterating through the ttr record to be merged from bottom

            TTRLabel label = ttrF.labels.get(i);

            if (!labels.contains(label)) {

            } else { //also for relabelling bound formulaes after beta reduction?
                Formula f1 = record.get(label);
                Formula f2 = ttrF.record.get(label);

                if (!f1.equals(f2)) {

                    TTRLabel l = this.getFreeLabel(label);
                    logger.debug("RELABEL AND UPDATE");
                    /*boolean headness = false;
                    if (ttrF.get(label).equals(ttrF.getHead()))
                    {headness = true;
                    logger.debug("headness true for " + ttrF.get(label));} */
                    
                    ttrF.relabelAndUpdate(label, l);
                    //logger.debug("mergeatTop result at stage " + i+ " = " + this.toString());
                   }else {
                	   logger.debug("no need to change");
                }
            }
        }

        if (!ttrF.getLabels().isEmpty()){

        	ttrNewF= ttrF;
                    logger.debug("ttrFooPreMerge " + ttrNewF);
                    return ttrNewF;

            } else {
                logger.debug("ttrFooPreMerge is empty!");
            }
        return ttrNewF;
    }

    public void mergeAtTop(TTRFormula ttr) {

        TTRFormula ttrF = new TTRFormula(ttr);
        TTRFormula ttrNewF = new TTRFormula();
        //given that proof/predicate types rely on the variable names of their arguments,
        //shouldn't these be added first or atleast the same time?
        for (int i = ttrF.labels.size() - 1; i >= 0; i--) {  //iterating through the ttr record to be merged
        //for (int i = 0 ; i <= ttrF.labels.size() - 1; i++) {
            TTRLabel label = ttrF.labels.get(i);

            if (!labels.contains(label)) {
                // Formula mapped = ttrF.get(label);
                // TTRLabel labelOfFormulaInMe = formulaLabel(mapped);
                //
                // if (labelOfFormulaInMe != null) {
                // ttrF.relabelAndUpdate(label, labelOfFormulaInMe);
                //
                // } else
                ttrNewF = ttrF;
                //addAtTop(label, ttrF.record.get(label));

            } else { //also for relabelling bound formulaes after beta reduction?
                Formula f1 = record.get(label);
                Formula f2 = ttrF.record.get(label);
                // if (!f1.equals(f2)) {
                // HACK TODOf2.toString().matches("(event)")
                if (!f1.equals(f2)) {

                    TTRLabel l = this.getFreeLabel(label);
                    logger.debug("RELABEL AND UPDATE");
                    ttrF.relabelAndUpdate(label, l);
                    ttrNewF = ttrF;
                /*    for (TTRLabel thislabel : this.getLabels()){
                    	Formula thisFormula = this.get(thislabel);
    
                    }*/
                    	
                    //addAtTop(l, f2);

                    logger.debug("mergeatTop result at stage " + i+ " = " + this.toString());
                }else {
                    logger.debug("no need to add");

                }
            }



        }

        if (!ttrNewF.getLabels().isEmpty()){


                    logger.debug("ttrFoo " + ttrNewF);

                    for (int j = ttrNewF.labels.size() - 1; j >= 0; j--) {
                    //for (TTRLabel label : ttrNewF.getLabels())
                    //{
                        TTRLabel label = ttrNewF.labels.get(j);

                        addAtTop(label, ttrNewF.get(label));

                    }


            } else {
                logger.debug("ttrFoo is empty!");
            }
    }

    /** 
     * @param other
     * 
     * @return true if every manifest field in 
     * OTHER is present in this TTRRecord TODO needs to do more than this, allowing for different names
     */
    public boolean isSubtypeOf(TTRFormula other){
    	//logger.info("SUBTYPE CHECK: checking whether " + this + " is a subtype of " + other);
    	
    	TTRFormulaMatcher matcher = new TTRFormulaMatcher(other, this);
    	//logger.debug("super head = " + other.getHead() + ",subhead = "+ this.getHead());
    	if (matcher.subTypeRelation())
    	{
    		logger.trace("SUBTYPE PASS!");
    		return true;
    	}
    	//logger.info("SUBTYPE FAIL!");
    	return false;

    }
   
    /**
     * 
     * @param label
     * @return the label(s) in this TTR formula that bind(s) the label being checked. 
     * If it doesn't have one, returns null, and this should mean it's unbound/free
     */
    public Vector<TTRLabel> getBinder(TTRLabel label)
    {	Pattern prooftype = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
        if (!this.getRecord().containsKey(label))
        {throw new RuntimeException(this + " does not contain label : " + label);}
    	
	    Vector<TTRLabel> predicateLabel = new Vector<TTRLabel>();;
	    
	    for (TTRLabel predicateCandidateLabel : getLabels())
	    	{
	    	  
	    		Formula formula = this.get(predicateCandidateLabel);
	    		
	    	   if (formula.toString() == null) {
	    			logger.debug("\"" + formula.toString() + "\"" + "NO FORMULA");
	    			continue;
	    		}
	    		Matcher m = prooftype.matcher(formula.toString());
	    		
	    		if (!m.matches()) {		
	    			logger.debug("NOT PROOF TYPE " + predicateCandidateLabel + ":" + formula);
	    		} else {
	    			logger.debug(formula + "is proof type");
		    		    for (int i=0; i<=m.groupCount(); i++)
						{  if (m.group(i)!=null)
						   {
							//logger.debug("group " + i + "= " + m.group(i));
								if (m.group(i).equals(label.toString()))
								{ predicateLabel.add(predicateCandidateLabel);
								logger.debug("successful candidate found = " + predicateCandidateLabel);
								}
						    }
						    else {break;}  //we've got to the end of the regex groups
						}
	    		}
	    	}
    		
	    if (predicateLabel.isEmpty())
	    {  logger.debug("NO SUITABLE BINDERS FOUND!");
	    	return null;}
	    
    	return predicateLabel;
    }
    
    public boolean isProofType(TTRLabel label)
    {
    	Pattern proofType = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
    	if (!this.getRecord().containsKey(label))
        {logger.error(this + " does not contain label : " + label); return false;}
    	
    	Formula formula = this.get(label);
    	logger.debug("trying to match pattern:" + formula);
    	
			Matcher m = proofType.matcher(formula.toString());		
			if (!m.matches()) {		
				logger.debug("NOT PROOF TYPE " + label);
				return false;
			}
    	return true;
    		
    }
    
    public Vector<TTRLabel> getArguments(TTRLabel label){
    	Pattern proofType = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
    	Vector<TTRLabel> args = new Vector<TTRLabel>();
    	if (!this.getRecord().containsKey(label))
        {throw new RuntimeException(this + " does not contain label : " + label);}
    	Formula formula = this.get(label);
    	Matcher m = proofType.matcher(formula.toString());		
		if (!m.matches()) {		
			logger.error("NOT PROOF TYPE " + label);
			return null;
		} else {
		    for (int i=2; i<=m.groupCount(); i++)
			{  if (m.group(i)!=null)
			   {logger.debug("arg " + i + "= " + m.group(i));
			   args.add(new TTRLabel(m.group(i)));}
			   else {break;}  //we've got to the end of the regex groups
			   
			  
		    }	   
			}
			return args;
			
		}
    	
    	
    
    
    /**
     * Simple string match that checks whether a prooftype can take a particular argument through future operations
     * @param prooflabel
     * @param argument
     * @return
     */
    public boolean canTakeArgument(TTRLabel prooflabel, TTRLabel argument) {
    	Pattern proofType = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
    	Formula proof = this.get(prooflabel);
    	Matcher m = proofType.matcher(proof.toString());		
		if (!m.matches()) {		
			logger.error(proof + " is not proof type");
			return false;
		} else {
    		    for (int i=0; i<=m.groupCount(); i++)
				{  if (m.group(i)!=null)
				   {logger.debug("checking group " + i + "= " + m.group(i));}
				   else {break;}  //we've got to the end of the regex groups
				   TTRLabel proofArgument = new TTRLabel(m.group(i));
				   if (isManifestType(proofArgument)) {
					   logger.debug("fail for this argument candidate");
				   } else {if ((proofArgument.TTRtypeMatch(argument))){
						  logger.debug(proof + " can take argument " + argument); 
						  return true;
				   }   
				   }	   
				}
		}
		logger.debug(proof + " cannot take argument");
    	return false;
    }
    
    /**
     * @param label
     * @return true if formula corresponding to label has a value, false iff null value/placeholder
     */
    public boolean isManifestType(TTRLabel label)
    {
    	Pattern proofType = Pattern.compile("(\\w+)\\Q(\\E(\\w+\\d*)\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\,*(\\w+\\d*)*\\Q)\\E");
    	if (isProofType(label))
    	{
    		Formula formula = this.get(label);
    		Matcher m = proofType.matcher(formula.toString());
    		if (m.matches()) {
    		if (!m.group(1).contains("null"))
    		{
    			return true;
    		}	}
    	}
    	if(this.get(label).toString()!=null&&!this.get(label).toString().contains("null")) {
    		return true;
    	}
    	return false;
    }
    
    
    /** 
     * @param other
     * 
     * @return true if every field in OTHER is present in this TTRRecord and vice-versa
     */
    public boolean equals(TTRFormula other){
           if (this.isSubtypeOf(other)&&other.isSubtypeOf(this))
           {return true;}
           return false;
        }
}



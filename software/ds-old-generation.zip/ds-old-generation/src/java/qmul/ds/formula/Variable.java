/*******************************************************************************
 * Copyright (c) 2001, 2010 Matthew Purver
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "LICENSE" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *******************************************************************************/
package qmul.ds.formula;

import java.util.ArrayList;

import qmul.ds.action.meta.MetaFormula;

/**
 * A (bound) variable within a {@link Formula}
 * 
 * @author mpurver
 */
public class Variable extends BasicFormula {

	private static final String ENTITY_VARIABLE_ROOT = "x";
	private static final String EVENT_VARIABLE_ROOT = "e";
	private static final String PROPOSITION_VARIABLE_ROOT = "p";

	private static ArrayList<Variable> entityPool = new ArrayList<Variable>();
	private static ArrayList<Variable> eventPool = new ArrayList<Variable>();
	private static ArrayList<Variable> propositionPool = new ArrayList<Variable>();

	/**
	 * A fresh entity variable x1, x2 etc
	 */
	public static Variable getFreshEntityVariable() {
		Variable v = new Variable(Variable.ENTITY_VARIABLE_ROOT + (entityPool.size() + 1));
		entityPool.add(v);
		return v;
	}

	/**
	 * A fresh event variable e1, e2 etc
	 */
	public static Variable getFreshEventVariable() {
		Variable v = new Variable(Variable.EVENT_VARIABLE_ROOT + (eventPool.size() + 1));
		eventPool.add(v);
		return v;
	}

	/**
	 * A fresh proposition variable p1, p2 etc
	 */
	public static Variable getFreshPropositionVariable() {
		Variable v = new Variable(Variable.PROPOSITION_VARIABLE_ROOT + (propositionPool.size() + 1));
		propositionPool.add(v);
		return v;
	}

	/**
	 * @param formula
	 */
	public Variable(String formula) {

		super(formula);
	}

	public boolean equals(Object o) {

		if (o == null)
			return false;
		if (this == o)
			return true;

		if (o instanceof Variable) {
			Variable other = (Variable) o;
			return formula.equals(other.formula);

		} else if (o instanceof MetaFormula) {
			MetaFormula other = (MetaFormula) o;
			return other.equals(this);
		} else {
			// System.out.println("we're here");
			return false;
		}
	}

}
